---
name: General topic
about: Neither a bug report nor a feature request
title: ''
labels: ''
assignees: ''

---

**Describe your intention**
A clear and concise description of your idea

