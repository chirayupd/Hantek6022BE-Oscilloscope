// SPDX-License-Identifier: GPL-2.0+

#pragma once

// spacing between the individual entries of the docks
const int DOCK_LAYOUT_SPACING = 1;
