// SPDX-License-Identifier: GPL-2.0+

#pragma once

typedef unsigned RecordLengthID;
typedef unsigned ChannelID;
