// SPDX-License-Identifier: GPL-2.0+

#include "exporterinterface.h"

ExporterInterface::~ExporterInterface() {}
