#!/bin/sh

flash_firmware_from_hex.py build/dso6022bl-firmware.hex
