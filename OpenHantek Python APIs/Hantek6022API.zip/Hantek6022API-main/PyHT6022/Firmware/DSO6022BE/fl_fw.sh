#!/bin/sh

../../../examples/upload_6022_firmware_from_hex.py dso6022be-firmware.hex

