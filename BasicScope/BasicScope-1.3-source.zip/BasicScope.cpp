﻿// BasicScope is distributed under the terms of the GNU GPLv3,
// which may be found at https://www.gnu.org/licenses/gpl-3.0.en.html
//
// BasicScope.cpp : This is the main program.
// The idea of BasicScope is to work with the Hantek 6022BE USB
// oscilloscope and provide basic functionality, plus a few features
// which I consider important.  Hopefully, I can avoid creeping features,
// perhaps assigning these to plugins that other people can write and
// install.
// (imo) Weaknesses of the hardware, and other software solutions:
// 1) Scope hardware cannot reliably trigger.  Can't fix in software.
// 2) When scope does trigger, the display does not always show the trigger
//    point, or the same offset from the trigger point.
// 3) No easy way to export a PNG file of the display.  Must screen capture.
// 4) No easy way to zoom in on part of a trace.
// 5) (Hantek stock software) Panning implementation is not practical.
// Version 0.1	Do basic waveform capture at fixed manual settings.
// Version 0.2	Starting to work on user interface elements.  All controls inert.
// Version 0.3	Begin basic trace collection.  Triggering, scaling, panning, zooming not implemented.
// Version 0.4	Display re-scales if voltage or time setting changed on captured trace.
// Version 0.5	Horizontal scroll bar for display window. Drag-Pan of display.
// Version 0.6	Add legend area at bottom of display window.  Markers not implemented, yet.
// Version 0.7	Toolbar buttons saved in registry. Status window change to edit control.
// Version 0.8	Replace .label TCHAR* fields with doubles.  Markers in progress.
// Version 0.9	Markers working
// Version 0.10	Save display to PNG file
// Version 0.11	Warn if taking trace out of range.  Software trigger in progress.
// Version 0.12 Software trigger working, including find first and next trigger.
// Version 0.13 First release for Beta Testing
// Version 0.14 Check for clipping when trace stops. Tooltip warning if trigger
//				exceeds clipping level.  Add tooltips to most controls.
//				Use own ClientToPng.lib instead of libpng.  Ability to write csv file.
// Version 0.15 Fix initial setting of voltage after install on both channels, was invalid value.
//				Added NSIS installer/uninstaller.
// Version 0.16 Add support for 6022BL: custom routine to detect whether connected
//				device is a BE or BL, then dynamically load appropriate HTMarch.dll
// Version 0.17 Drew icons for some buttons that were just a Duck, previously.
// Version 0.18 No changes other than to request execution as Admin in linker settings
// Version 0.19 Add trigger and time indices to CSV output
// Version 1.0	Larger markers.  First "production" release.
// Version 1.1	Restore window state (maximized, normal, minimized, etc.) upon startup.
//				DejaVu Sans Font now installed by FontReg.exe program, plain NSIS
//				was unable to modify the font keys in the registry for Win7.
// Version 1.2	Changed font installation to handle a corner case in Win XP.
// Version 1.3	Added mode to auto save each capture to a file, if that file does not exist.
//				Purpose is for a cheap and not very good data acquisition system.

//#pragma comment(linker,"\"/manifestdependency:type='win32' name='Microsoft.Windows.Common-Controls' version='6.0.0.0' processorArchitecture='x86' publicKeyToken='6595b64144ccf1df' language='*'\"")

#include "StdAfx.h"
#include "BasicScope.h"
#include "HTDisplayDll.h"
#include "ClientToPng.h"

#define MAX_LOADSTRING 100

// Global Variables:
HINSTANCE hInst;								// current instance
//TCHAR szTitle[MAX_LOADSTRING];					// The title bar text
//TCHAR szWindowClass[MAX_LOADSTRING];			// the main window class name

// Forward declarations of functions included in this code module:
bool				InitInstance(HINSTANCE);
LRESULT CALLBACK	MainWndProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK	DisplayWndProc(HWND, UINT, WPARAM, LPARAM);
INT_PTR CALLBACK	About(HWND, UINT, WPARAM, LPARAM);
void				DisplayPaint(HWND);
DWORD WINAPI		AcquisitionThread(LPVOID);
void				DetermineControlVisibility();
void				RecalcTrigger();

int APIENTRY _tWinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPTSTR    lpCmdLine,
                     int       nCmdShow)
{
	UNREFERENCED_PARAMETER(hPrevInstance);
	UNREFERENCED_PARAMETER(lpCmdLine);

	MSG msg;
	HACCEL hAccelTable;

	// Initialize global strings
//	LoadString(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING);
//	LoadString(hInstance, IDC_MAINWINDOW, szWindowClass, MAX_LOADSTRING);

	// Perform application initialization:
	if (!InitInstance (hInstance))
	{
		return false;
	}

	hAccelTable = LoadAccelerators(hInstance, MAKEINTRESOURCE(IDC_MAINWINDOW));

	// Main message loop:
	while (GetMessage(&msg, NULL, 0, 0))
	{
		if (!TranslateAccelerator(msg.hwnd, hAccelTable, &msg))
		{
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
	}

	return (int) msg.wParam;
}

// Load settings from registry.
// There is no return value because this function cannot fail - if the registry
// does not provide the value, a default is used.  The default values are set
// in the global declarations of the variables in BasicScope.h
// This also initializes the scope hardware to match the settings.
// This does NOT set any UI elements, such as sliders, which may not exist at
// the time this is invoked.
// Parameters:
//	Rect : OUT rect for main window
VOID LoadSettings(RECT *pRect)
{
	HKEY hKey;
	LONG status;
	DWORD len;

	pRect -> left = 0;
	pRect -> top = 0;
	pRect -> right = 640;
	pRect -> bottom = 480;
	nToolbarButtons = nButtons;  // default is to load all buttons
	for (i=0; i < (int)nButtons; i++)
		ToolbarButtons[i] = i;

	status = RegOpenKey(HKEY_LOCAL_MACHINE, TEXT("Software\\BasicScope"), &hKey);

	if (status == NO_ERROR) {
		len = sizeof(pRect -> left);
		status = RegQueryValueEx(hKey, BASICSCOPE_WINDOWLEFT, NULL, NULL, (LPBYTE) &(pRect -> left), &len);
		len = sizeof(pRect -> top);
		status = RegQueryValueEx(hKey, BASICSCOPE_WINDOWTOP, NULL, NULL, (LPBYTE) &(pRect -> top), &len);
		len = sizeof(pRect -> right);
		status = RegQueryValueEx(hKey, BASICSCOPE_WINDOWRIGHT, NULL, NULL, (LPBYTE) &(pRect -> right), &len);
		len = sizeof(pRect -> bottom);
		status = RegQueryValueEx(hKey, BASICSCOPE_WINDOWBOTTOM, NULL, NULL, (LPBYTE) &(pRect -> bottom), &len);
		// c'mon at least have kinda reasonable window size
		if ((pRect->right - pRect->left) <= 100 || (pRect->bottom - pRect->top) <= 100) {
			pRect -> left = 0;
			pRect -> top = 0;
			pRect -> right = 640;
			pRect -> bottom = 480;
		}		
		len = sizeof(WindowState);  // boolean settings
		RegQueryValueEx(hKey, BASICSCOPE_WINDOWSTATE, NULL, NULL, (LPBYTE) &WindowState, &len);
		len = sizeof(Ena1Checked);
		RegQueryValueEx(hKey, BASICSCOPE_ENA1, NULL, NULL, (LPBYTE) &Ena1Checked, &len);
		len = sizeof(TrigEna1Checked);
		RegQueryValueEx(hKey, BASICSCOPE_TRIGENA1, NULL, NULL, (LPBYTE) &TrigEna1Checked, &len);
		len = sizeof(Ena2Checked);
		RegQueryValueEx(hKey, BASICSCOPE_ENA2, NULL, NULL, (LPBYTE) &Ena2Checked, &len);
		len = sizeof(TrigEna2Checked);
		RegQueryValueEx(hKey, BASICSCOPE_TRIGENA2, NULL, NULL, (LPBYTE) &TrigEna2Checked, &len);
		len = sizeof(EnaExtraInfo);
		RegQueryValueEx(hKey, BASICSCOPE_ENAEXTRAINFO, NULL, NULL, (LPBYTE) &EnaExtraInfo, &len);
		len = sizeof(EnaMarkers);
		RegQueryValueEx(hKey, BASICSCOPE_ENAMARKERS, NULL, NULL, (LPBYTE) &EnaMarkers, &len);
		len = sizeof(EnaSwTrig);
		RegQueryValueEx(hKey, BASICSCOPE_ENASWTRIG, NULL, NULL, (LPBYTE) &EnaSwTrig, &len);
		len = sizeof(EnaDaMode);
		RegQueryValueEx(hKey, BASICSCOPE_ENADAMODE, NULL, NULL, (LPBYTE) &EnaDaMode, &len);

		len = sizeof(Volt1);  // integer settings
		RegQueryValueEx(hKey, BASICSCOPE_VOLT1, NULL, NULL, (LPBYTE) &Volt1, &len);
		len = sizeof(Zero1);
		RegQueryValueEx(hKey, BASICSCOPE_ZERO1, NULL, NULL, (LPBYTE) &Zero1, &len);
		len = sizeof(Trig1);
		RegQueryValueEx(hKey, BASICSCOPE_TRIG1, NULL, NULL, (LPBYTE) &Trig1, &len);
		len = sizeof(Slope1);
		RegQueryValueEx(hKey, BASICSCOPE_SLOPE1, NULL, NULL, (LPBYTE) &Slope1, &len);
		len = sizeof(Aten1);
		RegQueryValueEx(hKey, BASICSCOPE_ATEN1, NULL, NULL, (LPBYTE) &Aten1, &len);
		if (Aten1 != 1) Aten1 = 10;
		len = sizeof(Volt2);
		RegQueryValueEx(hKey, BASICSCOPE_VOLT2, NULL, NULL, (LPBYTE) &Volt2, &len);
		len = sizeof(Zero2);
		RegQueryValueEx(hKey, BASICSCOPE_ZERO2, NULL, NULL, (LPBYTE) &Zero2, &len);
		len = sizeof(Trig2);
		RegQueryValueEx(hKey, BASICSCOPE_TRIG2, NULL, NULL, (LPBYTE) &Trig2, &len);
		len = sizeof(Slope2);
		RegQueryValueEx(hKey, BASICSCOPE_SLOPE2, NULL, NULL, (LPBYTE) &Slope2, &len);
		len = sizeof(Aten2);
		RegQueryValueEx(hKey, BASICSCOPE_ATEN2, NULL, NULL, (LPBYTE) &Aten2, &len);
		if (Aten2 != 1) Aten2 = 10;
		len = sizeof(TimeDiv);
		RegQueryValueEx(hKey, BASICSCOPE_TIMEDIV, NULL, NULL, (LPBYTE) &TimeDiv, &len);

		// String settings
		len = sizeof(DataAcqfilename);
		RegQueryValueEx(hKey, BASICSCOPE_DACQFILENAME, NULL, NULL, (LPBYTE) DataAcqfilename, &len);

		// Get the toolbar buttons, if any
		len = 0;  // because just reading size
		if (NO_ERROR == RegQueryValueEx(hKey, BASICSCOPE_TOOLBARBUTTONS, NULL, NULL, NULL, &len)) {
			nToolbarButtons = len;
			// avoid possibility that registry has more buttons than app can provide
			if (nToolbarButtons > nButtons) nToolbarButtons = nButtons;
			// The following will fail if the read length does not exactly match the
			// size of the registry entry.  If that happens, so be it.
			RegQueryValueEx(hKey, BASICSCOPE_TOOLBARBUTTONS, NULL, NULL, (LPBYTE) ToolbarButtons, (DWORD *) &nToolbarButtons);
		}

		RegCloseKey(hKey);
	}
	// These are derived values from control settings
	TrigVolt1 = Trig1 * VoltParms[Volt1].VoltsPerDiv / 32.0;  // VoltsPerCount = VoltsPerDiv / 32
	TrigVolt2 = Trig2 * VoltParms[Volt2].VoltsPerDiv / 32.0;

	RecalcTrigger();  // set trigger parms based on which trigger is enabled

	// initialize scope hardware
	dsoGetCalLevel(DeviceIndex, CalData, CALDATA_LEN);
	dsoSetVoltDIV(DeviceIndex, CH1, VoltParms[Volt1].Volt);
	dsoSetVoltDIV(DeviceIndex, CH2, VoltParms[Volt2].Volt);
	dsoSetTimeDIV(DeviceIndex, TimeParms[TimeDiv].TimeDiv);
}

// Save all settings to the registry if possible
VOID SaveSettings(HWND hWnd)
{
	HKEY hKey;
	LONG status;
	static DWORD len;  // static to prevent optimizer from deleting
	RECT Rect;
	DWORD Version = MAKELONG(BS_MINORVERSION,BS_MAJORVERSION);

	status = RegCreateKey(HKEY_LOCAL_MACHINE, BASICSCOPE_ROOT_KEY, &hKey);
	
	if (status==NO_ERROR) {

		status = RegSetValueEx(hKey, BASICSCOPE_VERSION,  0, REG_DWORD, (LPBYTE) &Version, sizeof(Version));
		// only check writing once, and advise user
		if (status != ERROR_SUCCESS) {
			MessageBox(hWndMain, TEXT("Unable to save settings.  You may need to\nrun BasicScope as administrator."), TEXT("Unable to write registry"), MB_ICONINFORMATION | MB_OK);
		}

		if (GetWindowRect(hWnd, &Rect)) {
			RegSetValueEx(hKey, BASICSCOPE_WINDOWLEFT,  0, REG_DWORD, (LPBYTE) &Rect.left, sizeof(Rect.left));
			RegSetValueEx(hKey, BASICSCOPE_WINDOWTOP,  0, REG_DWORD, (LPBYTE) &Rect.top, sizeof(Rect.top));
			RegSetValueEx(hKey, BASICSCOPE_WINDOWRIGHT,  0, REG_DWORD, (LPBYTE) &Rect.right, sizeof(Rect.right));
			RegSetValueEx(hKey, BASICSCOPE_WINDOWBOTTOM,  0, REG_DWORD, (LPBYTE) &Rect.bottom, sizeof(Rect.bottom));
		}

		GetWindowPlacement(hWndMain, &wpl);
		WindowState = wpl.showCmd;
		RegSetValueEx(hKey, BASICSCOPE_WINDOWSTATE,  0, REG_BINARY, (LPBYTE) &WindowState, sizeof(WindowState));

		RegSetValueEx(hKey, BASICSCOPE_ENA1,  0, REG_BINARY, (LPBYTE) &Ena1Checked, sizeof(Ena1Checked));
		RegSetValueEx(hKey, BASICSCOPE_TRIGENA1,  0, REG_BINARY, (LPBYTE) &TrigEna1Checked, sizeof(TrigEna1Checked));
		RegSetValueEx(hKey, BASICSCOPE_ENA2,  0, REG_BINARY, (LPBYTE) &Ena2Checked, sizeof(Ena2Checked));
		RegSetValueEx(hKey, BASICSCOPE_TRIGENA2,  0, REG_BINARY, (LPBYTE) &TrigEna2Checked, sizeof(TrigEna2Checked));
		RegSetValueEx(hKey, BASICSCOPE_ENAEXTRAINFO,  0, REG_BINARY, (LPBYTE) &EnaExtraInfo, sizeof(EnaExtraInfo));
		RegSetValueEx(hKey, BASICSCOPE_ENAMARKERS,  0, REG_BINARY, (LPBYTE) &EnaMarkers, sizeof(EnaMarkers));
		RegSetValueEx(hKey, BASICSCOPE_ENASWTRIG,  0, REG_BINARY, (LPBYTE) &EnaSwTrig, sizeof(EnaSwTrig));
		RegSetValueEx(hKey, BASICSCOPE_ENADAMODE,  0, REG_BINARY, (LPBYTE) &EnaDaMode, sizeof(EnaDaMode));

		RegSetValueEx(hKey, BASICSCOPE_VOLT1,  0, REG_BINARY, (LPBYTE) &Volt1, sizeof(Volt1));
		RegSetValueEx(hKey, BASICSCOPE_ZERO1,  0, REG_BINARY, (LPBYTE) &Zero1, sizeof(Zero1));
		RegSetValueEx(hKey, BASICSCOPE_TRIG1,  0, REG_BINARY, (LPBYTE) &Trig1, sizeof(Trig1));
		RegSetValueEx(hKey, BASICSCOPE_SLOPE1, 0, REG_DWORD, (LPBYTE) &Slope1, sizeof(Slope1));
		RegSetValueEx(hKey, BASICSCOPE_ATEN1,  0, REG_BINARY, (LPBYTE) &Aten1, sizeof(Aten1));
		RegSetValueEx(hKey, BASICSCOPE_VOLT2,  0, REG_BINARY, (LPBYTE) &Volt2, sizeof(Volt2));
		RegSetValueEx(hKey, BASICSCOPE_ZERO2,  0, REG_BINARY, (LPBYTE) &Zero2, sizeof(Zero2));
		RegSetValueEx(hKey, BASICSCOPE_TRIG2,  0, REG_BINARY, (LPBYTE) &Trig2, sizeof(Trig2));
		RegSetValueEx(hKey, BASICSCOPE_SLOPE2, 0, REG_DWORD, (LPBYTE) &Slope2, sizeof(Slope2));
		RegSetValueEx(hKey, BASICSCOPE_ATEN2,  0, REG_BINARY, (LPBYTE) &Aten2, sizeof(Aten2));

		RegSetValueEx(hKey, BASICSCOPE_TIMEDIV,  0, REG_BINARY, (LPBYTE) &TimeDiv, sizeof(TimeDiv));

		len = (_tcslen(DataAcqfilename) + 1) * sizeof(TCHAR);  // +1 to size for terminating null
		RegSetValueEx(hKey, BASICSCOPE_DACQFILENAME, 0, REG_SZ, (LPBYTE) DataAcqfilename, len);

		// Save any buttons on the toolbar, in their present order
		nToolbarButtons = SendMessage(hWndToolbar, TB_BUTTONCOUNT, 0, 0);
		for (i=0; i<nToolbarButtons; i++) {
			TBBUTTON tb;
			SendMessage(hWndToolbar, TB_GETBUTTON, i, (LPARAM) &tb);
			ToolbarButtons[i] = (unsigned char) tb.dwData;
		}
		RegSetValueEx(hKey, BASICSCOPE_TOOLBARBUTTONS,  0, REG_BINARY, (LPBYTE) ToolbarButtons, nToolbarButtons);

		RegCloseKey(hKey);
	} else {
		// RegCreateKey() failed
		MessageBox(hWndMain, TEXT("Unable to save settings.  You may need to\nrun BasicScope as administrator."), TEXT("Unable to write registry"), MB_ICONINFORMATION | MB_OK);
	}
}
// Print a double-precision floating point number to a buffer in engineering-like format.
// Does NOT round to nearest value in some cases, simply truncates additional precision
// when an integer print is being done.  This is good enough for the application, which
// doesn't really have a full 3rd significant figure, anyway.
// Numbers with absolute value less than 1e-9 will print as 0
// Numbers greater than absolute value 1 will print as units (i.e., no kilo, Mega, etc. provided)
// Parameters:
//   a IN double  The number, less than absolute value 1e-9 will print as 9
//   u IN TCHAR*  Units to be appended to the output (generally Volts or Seconds)
void EngSprint(TCHAR *buf, int len, double a, TCHAR *u) {
	if (a == 0.0)
		_stprintf_s(buf, len, TEXT("0 %s"), u);  // 0 SS
	else if (-1e-6 < a && a < 1e-6)
		_stprintf_s(buf, len, TEXT("%d n%s"), (int)(a * 1e9), u);  // -123 nS
	else if (-1e-5 < a && a < 1e-5)
		_stprintf_s(buf, len, TEXT("%.2f μ%s"), (a * 1e6), u);  // -1.23 μS
	else if (-1e-4 < a && a < 1e-4)
		_stprintf_s(buf, len, TEXT("%.1f μ%s"), (a * 1e6), u);  // -12.3 μS
	else if (-1e-3 < a && a < 1e-3)
		_stprintf_s(buf, len, TEXT("%d μ%s"), (int)(a * 1e6), u);  // -123 μS
	else if (-1e-2 < a && a < 1e-2)
		_stprintf_s(buf, len, TEXT("%.2f m%s"), (a * 1e3), u);  // -1.23 mS
	else if (-1e-1 < a && a < 1e-1)
		_stprintf_s(buf, len, TEXT("%.1f m%s"), (a * 1e3), u);  // -12.3 mS
	else if (-1.0 < a && a < 1.0)
		_stprintf_s(buf, len, TEXT("%d m%s"), (int)(a * 1e3), u);  // -123 mS
	else if (-10.0 < a && a < 10.0)
		_stprintf_s(buf, len, TEXT("%.2f %s"), (a), u);  // -1.23 S
	else if (-100.0 < a && a < 100.0)
		_stprintf_s(buf, len, TEXT("%.1f %s"), (a), u);  // -12.3 S
	else if (-1e3 < a && a < 1e3)
		_stprintf_s(buf, len, TEXT("%d %s"), (int)(a), u);  // -123 S
	else if (-1e4 < a && a < 1e4)
		_stprintf_s(buf, len, TEXT("%.2f k%s"), (a * 1e-3), u);  // -1.23 kHz
	else if (-1e5 < a && a < 1e5)
		_stprintf_s(buf, len, TEXT("%.1f k%s"), (a * 1e-3), u);  // -12.3 μkHz
	else if (-1e6 < a && a < 1e6)
		_stprintf_s(buf, len, TEXT("%d k%s"), (int)(a * 1e-3), u);  // -123 μkHz
	else if (-1e7 < a && a < 1e7)
		_stprintf_s(buf, len, TEXT("%.2f M%s"), (a * 1e-6), u);  // -1.23 MHz
	else if (-1e8 < a && a < 1e8)
		_stprintf_s(buf, len, TEXT("%.1f M%s"), (a * 1e-6), u);  // -12.3 MHz
	else
		_stprintf_s(buf, len, TEXT("%d M%s"), (int)(a * 1e-6), u);  // -123 MHz
}

// Find trigger event within a buffer.
// This extends the trigger detection of the Hantek dsoReadHardData()
// The Hantek algorithm is to return the index of the sample just BEFORE
// the trigger level is crossed.  It makes more sense to me to return
// the index of the sample after the trigger occurs, but I will follow
// their paradigm.
// Lots of if-then and pointers for speed, in case compiler doesn't optimize well.
// Will scan for trigger from index ScanStart to ScanStop, inclusive.
// Returns 2 if trigger found, with index of trigger in *TrigPoint.  Else, returns 1, with *TrigPoint unaltered.
// These return values are meant to mimic dsoReadHardData()
// Could add other types of triggering to this, such as level sensitive instead of edge
short FindTrig(short *buf, unsigned long ScanStart, unsigned long ScanStop, short TrigLevel, short slope, long *TrigPoint){
	short *bufptr = &(buf[ScanStart]);
	unsigned long i = ScanStart;

	if (slope==PosEdg) {  // rising slope
		for ( ; i <= ScanStop; i++) {  // look for below trigger
			if (*bufptr++ < TrigLevel) break;
		}
		findabove:
		i++;
		for ( ; i <= ScanStop; i++) {  // look for at or above trigger
			if (*bufptr++ >= TrigLevel) {
				*TrigPoint = i - 1;  // subtract 1 to match Hantek
				return 2;
			}
		}
	} else if (slope==NegEdg) {  // falling slope
		for ( ; i <= ScanStop; i++) {  // look for above trigger
			if (*bufptr++ > TrigLevel) break;
		}
		findbelow:
		i++;
		for ( ; i <= ScanStop; i++) {  // look for at or below trigger
			if (*bufptr++ <= TrigLevel) {
				*TrigPoint = i - 1;  // subtract 1 to match Hantek
				return 2;
			}
		}
	} else if (slope==BothEdg) {  // either slope trigger
		for ( ; i <= ScanStop; i++) {  // look for above or below trigger
			if (*bufptr != TrigLevel) {
				if (*bufptr < TrigLevel) {
					bufptr++;
					goto findabove;
				} else { // *bufptr > TrigLevel
					bufptr++;
					goto findbelow;
				}
			}
		}
	}
	// Trig not found
	return 1;
}

// Append some text to the status window
// The status window will be used like a console, both during debugging,
// and in released code.
void AppendToStatus(TCHAR *buffer) {
	int existinglen = GetWindowTextLength(hWndStatus);
	int limit = SendMessage(hWndStatus, EM_GETLIMITTEXT, 0, 0);
	int buflen = _tcsnlen(buffer, limit);

	// check that there is enough room for the new message
	// if there isn't try to make room for the message
	// if room cannot be made, don't post the message
	// This is probably an unnecessary check, and the default
	// text limit is huge compared to what is likely to be
	// posted, but good programming practice.
	if (buflen >= limit) {
		MessageBox(hWndMain, TEXT("AppendToStatus() overflowed"), TEXT("Debug"), MB_ICONWARNING);
		return;
	} else if (existinglen + buflen >= limit) {
		SendMessage(hWndStatus, EM_SETSEL, 0, (LPARAM) buflen);  // not buflen-1
		SendMessage(hWndStatus, EM_REPLACESEL, 0, (LPARAM) TEXT(""));
	}

	SendMessage(hWndStatus, EM_SETSEL, (WPARAM) existinglen, (LPARAM) existinglen);
	SendMessage(hWndStatus, EM_REPLACESEL, 0, (LPARAM) buffer);
}

// Whenever the pan or zoom of the display window changes, this is called.
// Recompute the Screen coordinates of the markers from the Measure coordinates.
// If the Screen coordinates would place the marker off-screen, then the marker
// if forced to the closest on-screen edge.  Measure coordinates are unaltered.
void RecalcMarkerPositions() {
	for (i=0; i<=3; i++) {
		Marker[i].ScreenX = (int) (
			(Marker[i].MeasureX - DelayTicks)  * DisplayWidth / TimeParms[TimeDiv].TicksPerSample / (TimeParms[TimeDiv].DisLen)
			+ DisplayWidth/2);
		if (Marker[i].ScreenX < 0)
			Marker[i].ScreenX = 0;
		if (Marker[i].ScreenX > DisplayWidth)
			Marker[i].ScreenX = DisplayWidth;

		Marker[i].ScreenY = (int) (
			(*(Marker[i].Zslider) - Marker[i].MeasureY * 32.0 / VoltParms[*(Marker[i].Vslider)].VoltsPerDiv)
			* WaveformHeight / 256.0
			+ 0.5);  // only concerned with positive rounding, negative values rejected below
		if (Marker[i].ScreenY < 0)
			Marker[i].ScreenY = 0;
		if (Marker[i].ScreenY > WaveformHeight)
			Marker[i].ScreenY = WaveformHeight;
	}
}
// Global resources that stay until program shuts down
void CreateResources() {
	Ch1Brush = CreateSolidBrush(ch1Color);
	Ch2Brush = CreateSolidBrush(ch2Color);
	TimeBrush = CreateSolidBrush(TimeColor);
	Font1 = (HFONT) GetStockObject(ANSI_VAR_FONT);
	Font2 = CreateFont(
		14, //nHeight,
		0, //nWidth,
		0, //nEscapement,
		0, //nOrientation,
		FW_NORMAL, //fnWeight,
		false, //fdwItalic,
		false, //fdwUnderline,
		false, //fdwStrikeOut,
		ANSI_CHARSET, //fdwCharSet,
		OUT_DEFAULT_PRECIS, //fdwOutputPrecision,
		CLIP_DEFAULT_PRECIS, //fdwClipPrecision,
		PROOF_QUALITY, //fdwQuality,
		VARIABLE_PITCH, //fdwPitchAndFamily,
		TEXT("DejaVu Sans") //lpszFace - want DejaVu because it has the square with cross char
);
	Font3 = CreateFont(
		28, //nHeight,
		0, //nWidth,
		0, //nEscapement,
		0, //nOrientation,
		FW_NORMAL, //fnWeight,
		false, //fdwItalic,
		false, //fdwUnderline,
		false, //fdwStrikeOut,
		ANSI_CHARSET, //fdwCharSet,
		OUT_DEFAULT_PRECIS, //fdwOutputPrecision,
		CLIP_DEFAULT_PRECIS, //fdwClipPrecision,
		PROOF_QUALITY, //fdwQuality,
		VARIABLE_PITCH, //fdwPitchAndFamily,
		TEXT("DejaVu Sans") //lpszFace - want DejaVu because it has the square with cross char
);
}

// Return global resources
void FreeResources() {
	DeleteObject(Ch1Brush);
	DeleteObject(Ch2Brush);
	DeleteObject(TimeBrush);
//	DeleteObject(Font1);  // stock font need not be deleted
	DeleteObject(Font2);
	DeleteObject(Font3);
	FreeLibrary(hLibMarch);
}

// Load all the bitmaps for buttons in toolbar, then load the buttons, themselves
// Could also just load an imagelist from a single very wide image, but
// less flexible during development
void LoadToolbarButtons() {
	debugInt = SendMessage(hWndToolbar, TB_BUTTONSTRUCTSIZE, sizeof(TBBUTTON), 0);  // must send before anything
	debugInt = SendMessage(hWndToolbar, TB_SETBITMAPSIZE, (WPARAM)0, (LPARAM)MAKELONG(48,48));

	DWORD backgroundColor = GetSysColor(COLOR_BTNFACE);
	COLORMAP colorMap;
	colorMap.from = RGB(0, 0, 0);
	colorMap.to = backgroundColor;
	HBITMAP hbm;
	TBADDBITMAP tb;
	tb.hInst = NULL;

	// Add the button images
	for (i=IDB_FIRSTBITMAP; i<=IDB_LASTBITMAP; i++) {
		hbm = CreateMappedBitmap(hInst, i, 0, &colorMap, 1);
		tb.nID = (UINT_PTR)hbm;
		SendMessage (hWndToolbar, TB_ADDBITMAP, 0, (LPARAM)&tb);
	}

	// Add the buttons
	for (i=0; i < nToolbarButtons; i++) {
		debugInt = SendMessage(hWndToolbar, TB_ADDBUTTONS, 1, (LPARAM)&tbButtonList[ToolbarButtons[i]]);
	}

	debugInt = SendMessage(hWndToolbar, TB_AUTOSIZE, 0, 0);
}

// Stop scope, and pop the Run Norm and Run Once buttons
// also check the trace, if there is one, for clipping
// note that this check is not performed on every trace,
// just once when the scope is stopped
void StopScope() {
	scope_stopped = true;
	SendMessage(hWndToolbar, TB_CHECKBUTTON, IDM_RUNNORM, false);
	SendMessage(hWndToolbar, TB_CHECKBUTTON, IDM_RUNONCE, false);
	// if there is a valid trace, check it for clipping
	if (buffer[1-BufToFill].valid) {
		short *bufptr;
		int buflen = TimeParms[buffer[1-BufToFill].timediv].ReadLen;
		if (Ena1Checked) {
			bufptr = buffer[1-BufToFill].data[CH1];
			for (i=0; i<buflen; i++) {
				if (*bufptr <= -160 || *bufptr >= 160) {
					AppendToStatus(TEXT("\r\nChannel 1 waveform is clipped"));
					break;
				} else {
					bufptr++;
				}
			}
		}
		if (Ena2Checked) {
			bufptr = buffer[1-BufToFill].data[CH2];
			for (i=0; i<buflen; i++) {
				if (*bufptr <= -160 || *bufptr >= 160) {
					AppendToStatus(TEXT("\r\nChannel 2 waveform is clipped"));
					break;
				} else {
					bufptr++;
				}
			}
		}
	}
}

// Save the valid trace to a binary file.
void SaveTrace() {
	time_t rawtime;
	tm bt;

	StopScope();  // stop gathering data in order to save

	// default file name is a time stamp
	time(&rawtime);
	localtime_s(&bt, &rawtime);
	_stprintf_s(filename, FILENAME_LEN, TEXT("%04d-%02d-%02d_%02d%02d%02d"), bt.tm_year+1900, bt.tm_mon+1, bt.tm_mday,
		bt.tm_hour, bt.tm_min, bt.tm_sec);

	memset(&ofn, 0, sizeof(ofn));  // null pointers for uninitialized choices
	ofn.lStructSize = sizeof(OPENFILENAME);
	ofn.hwndOwner = hWndMain;  // must specify owner, or dialog will not be modal
	ofn.lpstrFilter = TEXT("Binary Files (*.bin)\0*.bin\0All Files (*.*)\0*.*\0");
	ofn.lpstrFile = filename;
	ofn.nMaxFile = FILENAME_LEN;
	ofn.Flags = OFN_EXPLORER | OFN_HIDEREADONLY;
	ofn.lpstrDefExt = TEXT("bin");
	if (GetSaveFileName(&ofn)) {
		FileHandle = CreateFile(filename,
			GENERIC_WRITE,  // access GENERIC_READ or GENERIC_WRITE
			0,				// 0 = no share (exclusive)
			NULL,			// security descriptor
			CREATE_ALWAYS,	// open and overwrite if existing, create if not
			FILE_ATTRIBUTE_NORMAL,	// not hidden, system, temporary, etc.
			NULL);			// no template
		if (FileHandle != INVALID_HANDLE_VALUE) {
			// write the entire displayed buffer out
			if (buffer[1-BufToFill].valid) {
				if (!WriteFile(FileHandle, &buffer[1-BufToFill], sizeof(TRACE), (DWORD *)&debugInt2, NULL)) {
					// write failed
					MessageBox(hWndMain, TEXT("File write failed"), TEXT("Error"), MB_ICONERROR);
				} else {
					// write additional variables that might be useful for diagnosis
					// these are not retrieved by BasicScope itself under normal conditions
					debugInt = BS_MAJORVERSION;
					WriteFile(FileHandle, &debugInt, sizeof(debugInt), (DWORD *)&debugInt2, NULL);
					debugInt = BS_MINORVERSION;
					WriteFile(FileHandle, &debugInt, sizeof(debugInt), (DWORD *)&debugInt2, NULL);
					WriteFile(FileHandle, &TrigPoint, sizeof(TrigPoint), (DWORD *)&debugInt2, NULL);
					WriteFile(FileHandle, &TrigSrc, sizeof(TrigSrc), (DWORD *)&debugInt2, NULL);
					WriteFile(FileHandle, &TrigLevel, sizeof(TrigLevel), (DWORD *)&debugInt2, NULL);
					WriteFile(FileHandle, &TrigSlope, sizeof(TrigSlope), (DWORD *)&debugInt2, NULL);
					WriteFile(FileHandle, &DelayTicks, sizeof(DelayTicks), (DWORD *)&debugInt2, NULL);
					WriteFile(FileHandle, &DelaySamples, sizeof(DelaySamples), (DWORD *)&debugInt2, NULL);
					WriteFile(FileHandle, &TrigScanStart, sizeof(TrigScanStart), (DWORD *)&debugInt2, NULL);
					WriteFile(FileHandle, &TrigScanEnd, sizeof(TrigScanEnd), (DWORD *)&debugInt2, NULL);
					WriteFile(FileHandle, &Ena1Checked, sizeof(Ena1Checked), (DWORD *)&debugInt2, NULL);
					WriteFile(FileHandle, &Ena2Checked, sizeof(Ena2Checked), (DWORD *)&debugInt2, NULL);
					WriteFile(FileHandle, &TrigEna1Checked, sizeof(TrigEna1Checked), (DWORD *)&debugInt2, NULL);
					WriteFile(FileHandle, &TrigEna2Checked, sizeof(TrigEna2Checked), (DWORD *)&debugInt2, NULL);
					WriteFile(FileHandle, &Slope1, sizeof(Slope1), (DWORD *)&debugInt2, NULL);
					WriteFile(FileHandle, &Slope2, sizeof(Slope2), (DWORD *)&debugInt2, NULL);
					WriteFile(FileHandle, &Volt1, sizeof(Volt1), (DWORD *)&debugInt2, NULL);
					WriteFile(FileHandle, &Volt2, sizeof(Volt2), (DWORD *)&debugInt2, NULL);
					WriteFile(FileHandle, &Zero1, sizeof(Zero1), (DWORD *)&debugInt2, NULL);
					WriteFile(FileHandle, &Zero2, sizeof(Zero2), (DWORD *)&debugInt2, NULL);
					WriteFile(FileHandle, &Trig1, sizeof(Trig1), (DWORD *)&debugInt2, NULL);
					WriteFile(FileHandle, &Trig2, sizeof(Trig2), (DWORD *)&debugInt2, NULL);
					WriteFile(FileHandle, &Aten1, sizeof(Aten1), (DWORD *)&debugInt2, NULL);
					WriteFile(FileHandle, &Aten2, sizeof(Aten2), (DWORD *)&debugInt2, NULL);
					WriteFile(FileHandle, &TrigVolt1, sizeof(TrigVolt1), (DWORD *)&debugInt2, NULL);
					WriteFile(FileHandle, &TrigVolt2, sizeof(TrigVolt2), (DWORD *)&debugInt2, NULL);
					WriteFile(FileHandle, &TimeDiv, sizeof(TimeDiv), (DWORD *)&debugInt2, NULL);
					WriteFile(FileHandle, &DisplayTimeDiv, sizeof(DisplayTimeDiv), (DWORD *)&debugInt2, NULL);
					WriteFile(FileHandle, &EnaSwTrig, sizeof(EnaSwTrig), (DWORD *)&debugInt2, NULL);
					WriteFile(FileHandle, &EnaExtraInfo, sizeof(EnaExtraInfo), (DWORD *)&debugInt2, NULL);
					WriteFile(FileHandle, &EnaDaMode, sizeof(EnaDaMode), (DWORD *)&debugInt2, NULL);
					WriteFile(FileHandle, &Marker, sizeof(Marker), (DWORD *)&debugInt2, NULL);
					WriteFile(FileHandle, &BufToFill, sizeof(BufToFill), (DWORD *)&debugInt2, NULL);
					WriteFile(FileHandle, &scope_stopped, sizeof(scope_stopped), (DWORD *)&debugInt2, NULL);
					WriteFile(FileHandle, &scope_oneshot, sizeof(scope_oneshot), (DWORD *)&debugInt2, NULL);
					WriteFile(FileHandle, &RecentTrigger, sizeof(RecentTrigger), (DWORD *)&debugInt2, NULL);
					WriteFile(FileHandle, &MainWindowIsSizing, sizeof(MainWindowIsSizing), (DWORD *)&debugInt2, NULL);
					WriteFile(FileHandle, &WindowState, sizeof(WindowState), (DWORD *)&debugInt2, NULL);
				}
			} else {
				MessageBox(hWndMain, TEXT("nothing to save"), TEXT("Invalid Buffer"), MB_ICONINFORMATION);
			}
			CloseHandle(FileHandle);
		} else {
			// fail on file open
			FormatMessage(FORMAT_MESSAGE_FROM_SYSTEM, NULL, GetLastError(), 0, OutString1, OUTSTR_LEN, NULL);
			MessageBox(hWndMain, OutString1, TEXT("File Opening Error"), MB_ICONINFORMATION);
		}
	} else {
		// fail on file name
		debugInt = CommDlgExtendedError();
		if (debugInt != 0) {
			_stprintf_s(OutString1, OUTSTR_LEN, TEXT("CommDlgExtendedError %08lx"), debugInt);
			MessageBox(hWndMain, OutString1, TEXT("File Name Error"), MB_ICONINFORMATION);
		}
	}
}

// restore saved trace to diplayed buffer
void LoadTrace() {
	StopScope();  // stop gathering data in order to load
	filename[0] = 0;  // null out the name to start
	memset(&ofn, 0, sizeof(ofn));  // null pointers for uninitialized choices
	ofn.lStructSize = sizeof(OPENFILENAME);
	ofn.hwndOwner = hWndMain;  // must specify owner, or dialog will not be modal
	ofn.lpstrFilter = TEXT("Binary Files (*.bin)\0*.bin\0All Files (*.*)\0*.*\0");
	ofn.lpstrFile = filename;
	ofn.nMaxFile = FILENAME_LEN;
	ofn.Flags = OFN_EXPLORER;
	ofn.lpstrDefExt = TEXT("bin");
	if (GetOpenFileName(&ofn)) {
		FileHandle = CreateFile(filename,
			GENERIC_READ,   // access GENERIC_READ or GENERIC_WRITE
			0,				// 0 = no share (exclusive)
			NULL,			// security descriptor
			OPEN_EXISTING,	// file must exist
			FILE_ATTRIBUTE_NORMAL,	// not hidden, system, temporary, etc.
			NULL);			// no template
		if (FileHandle != INVALID_HANDLE_VALUE) {
			// read into displayed buffer
			if (!ReadFile(FileHandle, &buffer[1-BufToFill], sizeof(TRACE), (DWORD *)&debugInt2, NULL)) {
				// read failed
				MessageBox(hWndMain, TEXT("File read failed"), TEXT("Error"), MB_ICONERROR);
			}
			CloseHandle(FileHandle);

			DelaySamples = 0;  // Display at zero offset from trigger
			InvalidateRect(hWndDisplay, NULL, false);  // Show the newly loaded data
		} else {
			// fail on file open
			FormatMessage(FORMAT_MESSAGE_FROM_SYSTEM, NULL, GetLastError(), 0, OutString1, OUTSTR_LEN, NULL);
			MessageBox(hWndMain, OutString1, TEXT("File Opening Error"), MB_ICONINFORMATION);
		}
	} else {
		// fail on file name
		debugInt = CommDlgExtendedError();
		if (debugInt != 0) {
			_stprintf_s(OutString1, OUTSTR_LEN, TEXT("CommDlgExtendedError %08lx"), debugInt);
			MessageBox(hWndMain, OutString1, TEXT("File Name Error"), MB_ICONINFORMATION);
		}
	}
}

// Write contents of trace buffer to a file in comma separated value format
// This writes an ASCII file with 8-bit characters, NOT Unicode.
// Parameter FileHandle must be handle of a valid open file
void WriteCsv(HANDLE FileHandle, short WhichBuf) {
	time_t rawtime;
	tm bt;
	DWORD len, lenwritten;
	char OutStringS[OUTSTR_LEN];
	long nSamples = TimeParms[buffer[WhichBuf].timediv].ReadLen;
	double Ch1Scale = buffer[WhichBuf].aten1 * VoltParms[buffer[WhichBuf].volt1].VoltsPerDiv/32.0;
	double Ch2Scale = buffer[WhichBuf].aten2 * VoltParms[buffer[WhichBuf].volt2].VoltsPerDiv/32.0;

	// time stamp for data set
	time(&rawtime);
	localtime_s(&bt, &rawtime);

	// Intentionally force sprintf_s() instead of _stprintf_s()
	// This makes it possible to write a plain ASCII file
	// However, the strings normally used elsewhere in the program
	// must be avoided
	len = sprintf_s(OutStringS, OUTSTR_LEN, "Date,%04d-%02d-%02d %02d:%02d:%02d,\r\n", bt.tm_year+1900, bt.tm_mon+1, bt.tm_mday,
		bt.tm_hour, bt.tm_min, bt.tm_sec);
	if (!WriteFile(FileHandle, OutStringS, len, &lenwritten, NULL)) goto WriteCsvFail;
	len = sprintf_s(OutStringS, OUTSTR_LEN, "Samples per Second,%ld,\r\n", 48000000L/TimeParms[buffer[WhichBuf].timediv].TicksPerSample);
	if (!WriteFile(FileHandle, OutStringS, len, &lenwritten, NULL)) goto WriteCsvFail;
	len = sprintf_s(OutStringS, OUTSTR_LEN, "Number of Samples,%ld,\r\n", nSamples);
	if (!WriteFile(FileHandle, OutStringS, len, &lenwritten, NULL)) goto WriteCsvFail;
	len = sprintf_s(OutStringS, OUTSTR_LEN, "Trigger source,");
	if (!WriteFile(FileHandle, OutStringS, len, &lenwritten, NULL)) goto WriteCsvFail;
	if (TrigEna1Checked) {
		len = sprintf_s(OutStringS, OUTSTR_LEN, "Channel 1\r\n");
		if (!WriteFile(FileHandle, OutStringS, len, &lenwritten, NULL)) goto WriteCsvFail;
		len = sprintf_s(OutStringS, OUTSTR_LEN, "Trigger edge,");
		if (!WriteFile(FileHandle, OutStringS, len, &lenwritten, NULL)) goto WriteCsvFail;
		if (Slope1==PosEdg) {
			len = sprintf_s(OutStringS, OUTSTR_LEN, "Rising\r\n");
			if (!WriteFile(FileHandle, OutStringS, len, &lenwritten, NULL)) goto WriteCsvFail;
		} else if (Slope1==NegEdg) {
			len = sprintf_s(OutStringS, OUTSTR_LEN, "Falling\r\n");
			if (!WriteFile(FileHandle, OutStringS, len, &lenwritten, NULL)) goto WriteCsvFail;
		} else if (Slope1==BothEdg) {
			len = sprintf_s(OutStringS, OUTSTR_LEN, "Both\r\n");
			if (!WriteFile(FileHandle, OutStringS, len, &lenwritten, NULL)) goto WriteCsvFail;
		}
		len = sprintf_s(OutStringS, OUTSTR_LEN, "Trigger level (volts),%f\r\n", Trig1 * Aten1 * VoltParms[Volt1].VoltsPerDiv / 32.0);
		if (!WriteFile(FileHandle, OutStringS, len, &lenwritten, NULL)) goto WriteCsvFail;
	} else if (TrigEna2Checked) {
		len = sprintf_s(OutStringS, OUTSTR_LEN, "Channel 2\r\n");
		if (!WriteFile(FileHandle, OutStringS, len, &lenwritten, NULL)) goto WriteCsvFail;
		len = sprintf_s(OutStringS, OUTSTR_LEN, "Trigger edge,");
		if (!WriteFile(FileHandle, OutStringS, len, &lenwritten, NULL)) goto WriteCsvFail;
		if (Slope2==PosEdg) {
			len = sprintf_s(OutStringS, OUTSTR_LEN, "Rising\r\n");
			if (!WriteFile(FileHandle, OutStringS, len, &lenwritten, NULL)) goto WriteCsvFail;
		} else if (Slope2==NegEdg) {
			len = sprintf_s(OutStringS, OUTSTR_LEN, "Falling\r\n");
			if (!WriteFile(FileHandle, OutStringS, len, &lenwritten, NULL)) goto WriteCsvFail;
		} else if (Slope2==BothEdg) {
			len = sprintf_s(OutStringS, OUTSTR_LEN, "Both\r\n");
			if (!WriteFile(FileHandle, OutStringS, len, &lenwritten, NULL)) goto WriteCsvFail;
		}
		len = sprintf_s(OutStringS, OUTSTR_LEN, "Trigger level (volts),%f\r\n", Trig2 * Aten2 * VoltParms[Volt2].VoltsPerDiv / 32.0);
		if (!WriteFile(FileHandle, OutStringS, len, &lenwritten, NULL)) goto WriteCsvFail;
	} else {
		len = sprintf_s(OutStringS, OUTSTR_LEN, "none\r\n");
		if (!WriteFile(FileHandle, OutStringS, len, &lenwritten, NULL)) goto WriteCsvFail;
	}
	len = sprintf_s(OutStringS, OUTSTR_LEN, "\r\nTime (seconds),Channel 1 (volts),Channel 2 (volts)\r\n");
	if (!WriteFile(FileHandle, OutStringS, len, &lenwritten, NULL)) goto WriteCsvFail;
	for (i=0; i < nSamples; i++) {
		len = sprintf_s(OutStringS, OUTSTR_LEN, "%.6g,%.3g,%.3g\r\n", 
			TimeParms[buffer[WhichBuf].timediv].TicksPerSample * (i - buffer[WhichBuf].trigpoint) / 48e6,
			Ch1Scale * buffer[WhichBuf].data[0][i],
			Ch2Scale * buffer[WhichBuf].data[1][i]);
		if (!WriteFile(FileHandle, OutStringS, len, &lenwritten, NULL)) goto WriteCsvFail;
	}
	return;  // successful return
WriteCsvFail:
	MessageBox(hWndMain, TEXT("File write failed"), TEXT("Error"), MB_ICONERROR);
}

// Save the valid trace to a comma-separated-value file.
// This writes an ASCII file with 8-bit characters, NOT Unicode.
void SaveCsv() {
	time_t rawtime;
	tm bt;

	// If there is no valid buffer displayed, nothing to save
	if (buffer[1-BufToFill].valid) {
		StopScope();  // stop gathering data in order to save

		// default file name is a time stamp
		time(&rawtime);
		localtime_s(&bt, &rawtime);
		_stprintf_s(filename, FILENAME_LEN, TEXT("%04d-%02d-%02d_%02d%02d%02d"), bt.tm_year+1900, bt.tm_mon+1, bt.tm_mday,
			bt.tm_hour, bt.tm_min, bt.tm_sec);

		memset(&ofn, 0, sizeof(ofn));  // null pointers for uninitialized choices
		ofn.lStructSize = sizeof(OPENFILENAME);
		ofn.hwndOwner = hWndMain;  // must specify owner, or dialog will not be modal
		ofn.lpstrFilter = TEXT("Comma Separated Value Files (*.csv)\0*.csv\0All Files (*.*)\0*.*\0");
		ofn.lpstrFile = filename;
		ofn.nMaxFile = FILENAME_LEN;
		ofn.Flags = OFN_EXPLORER | OFN_HIDEREADONLY;
		ofn.lpstrDefExt = TEXT("csv");
		if (GetSaveFileName(&ofn)) {
			// First, attempt to delete old file.  Otherwise a long file might just get overwritten
			// in the first part with shorter data.  There is no file opening mode to open and truncate,
			// that will also create if necessary.
			DeleteFile(filename);  // if this call fails, don't care.
			FileHandle = CreateFile(filename,
				GENERIC_WRITE,  // access GENERIC_READ or GENERIC_WRITE
				0,				// 0 = no share (exclusive)
				NULL,			// security descriptor
				CREATE_NEW,	// open and overwrite if existing, create if not
				FILE_ATTRIBUTE_NORMAL,	// not hidden, system, temporary, etc.
				NULL);			// no template
			if (FileHandle != INVALID_HANDLE_VALUE) {
				// write the entire displayed buffer out
				WriteCsv(FileHandle, 1-BufToFill);
				CloseHandle(FileHandle);
			} else {
				// fail on file open
				FormatMessage(FORMAT_MESSAGE_FROM_SYSTEM, NULL, GetLastError(), 0, OutString1, OUTSTR_LEN, NULL);
				MessageBox(hWndMain, OutString1, TEXT("File Opening Error"), MB_ICONINFORMATION);
			}
		} else {
			// fail on file name
			debugInt = CommDlgExtendedError();
			if (debugInt != 0) {
				_stprintf_s(OutString1, OUTSTR_LEN, TEXT("CommDlgExtendedError %08lx"), debugInt);
				MessageBox(hWndMain, OutString1, TEXT("File Name Error"), MB_ICONINFORMATION);
			}
		}
		} else {
		MessageBox(hWndMain, TEXT("nothing to save"), TEXT("No trace exists"), MB_ICONINFORMATION);
	}

}

// save contents of Display Window to a PNG file
long SaveDisplay(HWND hWnd) {
	time_t rawtime;
	tm bt;
	long code = 0;

	StopScope();  // stop gathering data in order to save

	// default file name is a time stamp
	time(&rawtime);
	localtime_s(&bt, &rawtime);
	_stprintf_s(filename, FILENAME_LEN, TEXT("%04d-%02d-%02d_%02d%02d%02d"), bt.tm_year+1900, bt.tm_mon+1, bt.tm_mday,
		bt.tm_hour, bt.tm_min, bt.tm_sec);

	memset(&ofn, 0, sizeof(ofn));  // null pointers for uninitialized choices
	ofn.lStructSize = sizeof(OPENFILENAME);
	ofn.hwndOwner = hWndMain;  // must specify owner, or dialog will not be modal
	ofn.lpstrFilter = TEXT("PNG files (*.png)\0*.png\0All Files (*.*)\0*.*\0");
	ofn.lpstrFile = filename;
	ofn.nMaxFile = FILENAME_LEN;
	ofn.Flags = OFN_EXPLORER | OFN_HIDEREADONLY;
	ofn.lpstrDefExt = TEXT("png");
	if (GetSaveFileName(&ofn)) {
		// force repaint now, in case file selection dialog is
		// still blocking out part of display window
		SendMessage(hWndDisplay, WM_PAINT, 0, 0);
		code = SaveClientAreaToPng(hWndDisplay, filename);
	} else {
		// fail on file name
		code = CommDlgExtendedError();
		if (code != 0) {
			//_stprintf_s(OutString1, OUTSTR_LEN, TEXT("CommDlgExtendedError %08lx"), code);
			//MessageBox(hWndMain, OutString1, TEXT("File Name Error"), MB_ICONINFORMATION);
			code = ERROR_INVALID_NAME;  // translate into errno
		}
	}
	return code;
}

// Recalculate trigger parameters for dsoReadHardData()
// based on UI settings.  Also, validate whether software
// trigger is enabled if trigger on both edges is selected.
void RecalcTrigger() {
	if (TrigEna1Checked) {
		TrigSrc = CH1;
		TrigLevel = Trig1;
		if (Slope1==NegEdg)	TrigSlope = NegEdg;
		else if (Slope1==PosEdg) TrigSlope = PosEdg;
		else { // slope==BothEdg trigger on both edges
			TrigSlope = PosEdg;  // hardware does not accept both edges
			if (!EnaSwTrig) {
				AppendToStatus(TEXT("\r\nSoftware trigger required for both edges. Enabling."));
				EnaSwTrig = true;
				DetermineControlVisibility();  // to refresh the button
			}
		}
	} else if (TrigEna2Checked) {
		TrigSrc = CH2;
		TrigLevel = Trig2;
		if (Slope2==NegEdg)	TrigSlope = NegEdg;
		else if (Slope2==PosEdg) TrigSlope = PosEdg;
		else { // slope==BothEdg trigger on both edges
			TrigSlope = PosEdg;  // hardware does not accept both edges
			if (!EnaSwTrig) {
				AppendToStatus(TEXT("\r\nSoftware trigger required for both edges. Enabling."));
				EnaSwTrig = true;
				DetermineControlVisibility();  // to refresh the button
			}
		}
	} else { // nothing checked = no trigger
		TrigSrc = CH1;
		TrigLevel = 999;  // set impossible trigger so hardware won't find one
		TrigSlope = PosEdg;
	}
}

// Set the time division on the scope
// Also, set the TimeDiv trackbar to match
// Parameters:
//  position IN slider position for TimeDiv control
void SetTimeDiv(int position) {
	TimeDiv = position;  // set the global
	dsoSetTimeDIV(DeviceIndex, TimeParms[TimeDiv].TimeDiv);  // set scope
	SendMessage(hWndTimeDiv, TBM_SETPOS, (WPARAM) true, (LPARAM) TimeDiv);  // set trackbar
	DisplayTimeDiv = TimeDiv;  // for the sake of recomputing marker positions
	DisplayTimeDiv = -1;  // set this to force recompute of scroll bar on DisplayPaint()
}

// Create the main window, and all controls
// Return: true if successful, false if not
// Note: a return of false is very bad, the program should probably abort
bool CreateAllWindows(RECT *pRect)
{
	WNDCLASSEX wcex = {sizeof(WNDCLASSEX)};

	HDC hdc;  // just to get font metrics

	INITCOMMONCONTROLSEX DesiredControl = {sizeof(INITCOMMONCONTROLSEX)};

	TOOLINFO ti = {sizeof(TOOLINFO)};  // for tooltip use

	// Register Window classes.  Main window first.

	wcex.style			= CS_HREDRAW | CS_VREDRAW;
	wcex.lpfnWndProc	= MainWndProc;
	wcex.cbClsExtra		= 0;
	wcex.cbWndExtra		= 0;
	wcex.hInstance		= hInst;
	wcex.hIcon			= LoadIcon(hInst, MAKEINTRESOURCE(IDI_BASICSCOPE));
	wcex.hCursor		= LoadCursor(NULL, IDC_ARROW);
	wcex.hbrBackground	= (HBRUSH)(COLOR_WINDOW+1);
	wcex.lpszMenuName	= MAKEINTRESOURCE(IDC_MAINWINDOW);
	wcex.lpszClassName	= TEXT("MAINWINDOWCLASS");
	wcex.hIconSm		= LoadIcon(hInst, MAKEINTRESOURCE(IDI_BASICSCOPE));

	if (!RegisterClassEx(&wcex))
		return false;

	// class for the display window
	wcex.lpfnWndProc	= DisplayWndProc;
	wcex.lpszMenuName	= NULL;
	wcex.lpszClassName	= TEXT("DISPLAYWINDOWCLASS");

	if (!RegisterClassEx(&wcex))
		return false;

	// Get Window metrics and store for later use
	CaptionHeight = GetSystemMetrics(SM_CYCAPTION);
	MenuHeight = GetSystemMetrics(SM_CYMENU);
	FrameHeight = GetSystemMetrics(SM_CYFRAME);
	TrackbarLeadin = 3*FrameHeight;  // no solid metric, must take a guess
	ScrollHeight = GetSystemMetrics(SM_CYHSCROLL);

	// Finally, start creating windows and controls
	hWndMain = CreateWindow(TEXT("MAINWINDOWCLASS"), TEXT("BasicScope"), WS_OVERLAPPEDWINDOW,
		pRect->left, pRect->top, pRect->right - pRect->left, pRect->bottom - pRect->top, NULL, NULL, hInst, NULL);
	if (!hWndMain) return false;

	// Determine average character width after main window is created
	hdc = GetDC(hWndMain);
	if (hdc && GetTextMetrics(hdc, &txm))  // rely on left-to-right checking here
		AveCharWidth = txm.tmAveCharWidth;
	else
		AveCharWidth = 10;

	SliderWidth1 = 6*AveCharWidth;  // wide enough so that tics on both sides show
	SliderWidth2 = 3*AveCharWidth;
	ButtonWidth1 = SliderWidth1 + FrameHeight + SliderWidth2;
	ButtonWidth2 = 7*AveCharWidth;  // trigger enable - wide enough for label
	DisplayMargin = FrameHeight + ButtonWidth1 + ButtonWidth2;
	StatusHeight = 3*ScrollHeight;
	ToolbarHeight = 3*ScrollHeight;
	ToolbarHeight = 74;  // debug: what if we do this?

	// Size is arbitrary, will be properly sized with
	// next WM_SIZE command to main window.
	hWndDisplay = CreateWindow(TEXT("DISPLAYWINDOWCLASS"), TEXT(""), WS_HSCROLL | WS_CHILD,
      DisplayMargin, FrameHeight+2*CaptionHeight+TrackbarLeadin, 0, 0, hWndMain, NULL, hInst, NULL);
	if (!hWndDisplay) return false;
	
	// We will be using some common controls, must initialize classes
	DesiredControl.dwICC = ICC_BAR_CLASSES | ICC_PAGESCROLLER_CLASS;
	InitCommonControlsEx(&DesiredControl);

	// Time per Division slider - size is arbitrary, set upon window resize
	hWndTimeDiv = CreateWindow(TRACKBAR_CLASS, TEXT("tDiv"), WS_VISIBLE | WS_CHILD | TBS_TOOLTIPS | TBS_HORZ | TBS_DOWNISLEFT | TBS_BOTH | TBS_AUTOTICKS,
      FrameHeight+DisplayMargin, FrameHeight, 0, 0, hWndMain, (HMENU) ID_TIMEDIV, hInst, NULL);
	if (!hWndTimeDiv) return false;
    SendMessage(hWndTimeDiv, TBM_SETRANGE, (WPARAM) true, (LPARAM) MAKELONG(0, nTimeParms-1));  // min & max positions

	// Channel 1 Enable Checkbox
	hWndEna1 = CreateWindow(WC_BUTTON, TEXT("Ch1"), BS_AUTOCHECKBOX | WS_CHILD | WS_VISIBLE,
      FrameHeight, FrameHeight, ButtonWidth1, CaptionHeight, hWndMain, (HMENU) ID_ENA1, hInst, NULL);
	if (!hWndEna1) return false;
	// Trigger 1 Enable Checkbox
	hWndTrigEna1 = CreateWindow(WC_BUTTON, TEXT("Trg"), BS_AUTOCHECKBOX | WS_CHILD,
      FrameHeight+ButtonWidth1, FrameHeight, ButtonWidth2, CaptionHeight, hWndMain, (HMENU) ID_TRIGENA1, hInst, NULL);
	if (!hWndTrigEna1) return false;
	// Channel 1 slider labels
	hWndVlabel1 = CreateWindow(WC_STATIC, TEXT("V/div"), SS_CENTER | WS_CHILD,
      FrameHeight, FrameHeight+CaptionHeight, SliderWidth1, CaptionHeight, hWndMain, (HMENU) ID_VLABEL1, hInst, NULL);
	if (!hWndVlabel1) return false;
	hWndZlabel1 = CreateWindow(WC_STATIC, TEXT("↕"), SS_CENTER | WS_CHILD,
      FrameHeight+SliderWidth1+FrameHeight, FrameHeight+CaptionHeight, SliderWidth2, CaptionHeight, hWndMain, (HMENU) ID_ZLABEL1, hInst, NULL);
	if (!hWndZlabel1) return false;

	// Trigger slope 1 combobox
	hWndSlope1 = CreateWindow(WC_COMBOBOX, NULL, 
      CBS_DROPDOWNLIST | CBS_HASSTRINGS | WS_CHILD | WS_OVERLAPPED,
      FrameHeight+ButtonWidth1, FrameHeight+CaptionHeight, ButtonWidth2, 5*CaptionHeight, hWndMain, (HMENU) ID_SLOPE1, hInst, NULL);
	if (!hWndSlope1) return false;
	for (i=0; i < NUM_SLOPES; i++) {
		SendMessage(hWndSlope1, (UINT) CB_ADDSTRING,(WPARAM) 0,(LPARAM) SlopeName[i]);
	}
	// Channel 1 volts/div - height is arbitrary
	hWndVolt1 = CreateWindow(TRACKBAR_CLASS, NULL, WS_CHILD | TBS_TOOLTIPS | TBS_VERT | TBS_DOWNISLEFT | TBS_BOTH | TBS_AUTOTICKS,
      FrameHeight, FrameHeight+2*CaptionHeight, 0, 0, hWndMain, (HMENU) ID_VOLT1, hInst, NULL);
	if (!hWndVolt1) return false;
    SendMessage(hWndVolt1, TBM_SETRANGE, (WPARAM) true, (LPARAM) MAKELONG(0, nVoltParms-1));  // min & max positions
	// Channel 1 position - height is arbitrary
	hWndZero1 = CreateWindow(TRACKBAR_CLASS, NULL, WS_CHILD | TBS_TOOLTIPS | TBS_VERT | TBS_NOTICKS,
      2*FrameHeight+SliderWidth1, FrameHeight+2*CaptionHeight, 0, 0, hWndMain, (HMENU) ID_ZERO1, hInst, NULL);
	if (!hWndZero1) return false;
    SendMessage(hWndZero1, TBM_SETRANGE, (WPARAM) true, (LPARAM) MAKELONG(0, 255));  // min & max positions
	// Channel 1 trigger - height is arbitrary
	hWndTrig1 = CreateWindow(TRACKBAR_CLASS, NULL, WS_CHILD | TBS_TOOLTIPS | TBS_VERT | TBS_NOTICKS,
      DisplayMargin-SliderWidth2, FrameHeight+2*CaptionHeight, 0, 0, hWndMain, (HMENU) ID_TRIG1, hInst, NULL);
	if (!hWndTrig1) return false;
    SendMessage(hWndTrig1, TBM_SETRANGE, (WPARAM) true, (LPARAM) MAKELONG(0, 255));  // min & max positions
	// Channel 1 attenuation - position arbitrary
	hWndX1Aten1 = CreateWindow(WC_BUTTON, TEXT("x1"), BS_AUTORADIOBUTTON | WS_CHILD,
      0, 0, SliderWidth1, CaptionHeight, hWndMain, (HMENU)ID_BUTTONX1ATEN1, hInst, NULL);
	if (!hWndX1Aten1) return false;
	hWndX10Aten1 = CreateWindow(WC_BUTTON, TEXT("x10"), WS_GROUP | BS_AUTORADIOBUTTON | WS_CHILD,
      0, 0, SliderWidth1, CaptionHeight, hWndMain, (HMENU) ID_BUTTONX10ATEN1, hInst, NULL);
	if (!hWndX10Aten1) return false;

	// Channel 2 Enable Checkbox - position is arbitrary
	hWndEna2 = CreateWindow(WC_BUTTON, TEXT("Ch2"), BS_AUTOCHECKBOX | WS_CHILD | WS_VISIBLE,
      0, 0, ButtonWidth1, CaptionHeight, hWndMain, (HMENU) ID_ENA2, hInst, NULL);
	if (!hWndEna2) return false;
	// Trigger 2 Enable Checkbox - position is arbitrary
	hWndTrigEna2 = CreateWindow(WC_BUTTON, TEXT("Trg"), BS_AUTOCHECKBOX | WS_CHILD,
      0, 0, ButtonWidth2, CaptionHeight, hWndMain, (HMENU) ID_TRIGENA2, hInst, NULL);
	if (!hWndTrigEna2) return false;
	// Channel 2 slider labels - position arbitrary
	hWndZlabel2 = CreateWindow(WC_STATIC, TEXT("↕"), SS_CENTER | WS_CHILD,
      0, 0, SliderWidth2, CaptionHeight, hWndMain, (HMENU) ID_VLABEL2, hInst, NULL);
	if (!hWndZlabel2) return false;
	hWndVlabel2 = CreateWindow(WC_STATIC, TEXT("V/div"), SS_CENTER | WS_CHILD,
      0, 0, SliderWidth1, CaptionHeight, hWndMain, (HMENU) ID_ZLABEL2, hInst, NULL);
	if (!hWndVlabel2) return false;

	// Trigger slope 2 combobox
	hWndSlope2 = CreateWindow(WC_COMBOBOX, NULL, 
      CBS_DROPDOWNLIST | CBS_HASSTRINGS | WS_CHILD | WS_OVERLAPPED,
      0, 0, ButtonWidth2, 5*CaptionHeight, hWndMain, (HMENU) ID_SLOPE2, hInst, NULL);
	if (!hWndSlope2) return false;
	for (i=0; i < NUM_SLOPES; i++) {
		SendMessage(hWndSlope2, (UINT) CB_ADDSTRING,(WPARAM) 0,(LPARAM) SlopeName[i]);
	}
	// Channel 2 volts/div - height and postion are arbitrary
	hWndVolt2 = CreateWindow(TRACKBAR_CLASS, NULL, WS_CHILD | TBS_TOOLTIPS | TBS_VERT | TBS_DOWNISLEFT | TBS_BOTH | TBS_AUTOTICKS,
      0, 0, 0, 0, hWndMain, (HMENU) ID_VOLT2, hInst, NULL);
	if (!hWndVolt2) return false;
    SendMessage(hWndVolt2, TBM_SETRANGE, (WPARAM) true, (LPARAM) MAKELONG(0, nVoltParms-1));  // min & max positions
	// Channel 2 position - height and postion are arbitrary, set upon resize
	hWndZero2 = CreateWindow(TRACKBAR_CLASS, NULL, WS_CHILD | TBS_TOOLTIPS | TBS_VERT | TBS_LEFT | TBS_NOTICKS,
      0, 0, 0, 0, hWndMain, (HMENU) ID_ZERO2, hInst, NULL);
	if (!hWndZero2) return false;
    SendMessage(hWndZero2, TBM_SETRANGE, (WPARAM) true, (LPARAM) MAKELONG(0, 255));  // min & max positions
	// Channel 2 trigger - height and postion are arbitrary, set upon resize
	hWndTrig2 = CreateWindow(TRACKBAR_CLASS, NULL, WS_CHILD | TBS_TOOLTIPS | TBS_VERT | TBS_LEFT | TBS_NOTICKS,
      0, 0, 0, 0, hWndMain, (HMENU) ID_TRIG2, hInst, NULL);
	if (!hWndTrig2) return false;
    SendMessage(hWndTrig2, TBM_SETRANGE, (WPARAM) true, (LPARAM) MAKELONG(0, 255));  // min & max positions
	// Channel 2 attenuation - position arbitrary
	hWndX1Aten2 = CreateWindow(WC_BUTTON, TEXT("x1"), BS_AUTORADIOBUTTON | WS_CHILD,
      0, 0, SliderWidth1, CaptionHeight, hWndMain, (HMENU)ID_BUTTONX1ATEN2, hInst, NULL);
	if (!hWndX1Aten2) return false;
	hWndX10Aten2 = CreateWindow(WC_BUTTON, TEXT("x10"), WS_GROUP | BS_AUTORADIOBUTTON | WS_CHILD,
      0, 0, SliderWidth1, CaptionHeight, hWndMain, (HMENU) ID_BUTTONX10ATEN2, hInst, NULL);
	if (!hWndX10Aten2) return false;

	// Status display - size and position arbitrary
	hWndStatus = CreateWindow(WC_EDIT, NULL, WS_VISIBLE | WS_CHILD | WS_VSCROLL | WS_HSCROLL | ES_LEFT | ES_MULTILINE | ES_AUTOVSCROLL | ES_READONLY,
      0, 0, 0, 0, hWndMain, (HMENU) ID_STATUS, hInst, NULL);
	if (!hWndStatus) return false;

	// Toolbar in a Pager - size and position arbitrary
	hWndPager = CreateWindow(WC_PAGESCROLLER, NULL, WS_VISIBLE | WS_CHILD | PGS_DRAGNDROP | PGS_HORZ,
	  0, 0, 0, 0, hWndMain, (HMENU) ID_PAGER, hInst, NULL);
	if (!hWndPager) return false;
	hWndToolbar = CreateWindowEx(0, TOOLBARCLASSNAME, TEXT("This is the toolbar"), WS_VISIBLE | WS_CHILD | CCS_NORESIZE | CCS_ADJUSTABLE,
      0, 0, 0, 0, hWndPager, (HMENU) ID_TOOLBAR, hInst, NULL);
	if (!hWndToolbar) return false;
	// load bitmaps to be used for buttons
	LoadToolbarButtons();

	// Notify the pager that it contains the toolbar
	SendMessage(hWndPager, PGM_SETCHILD , 0, (LPARAM) hWndToolbar);

	// This tooltip is responsible for identifying all the controls.
	// This activates on hover.
	hWndIdToolTip = CreateWindowEx(WS_EX_TOPMOST, TOOLTIPS_CLASS, NULL, WS_POPUP | TTS_NOPREFIX | TTS_ALWAYSTIP,
		CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, hWndMain, NULL, hInst, NULL);
	if (!hWndIdToolTip) return false;
	SetWindowPos(hWndIdToolTip, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);  // must be on top
	ti.uFlags = TTF_IDISHWND | TTF_SUBCLASS;
	ti.hwnd = hWndMain;
	ti.uId = (UINT_PTR) hWndEna1;
	ti.hinst = hInst;
	ti.lpszText = LPSTR_TEXTCALLBACK;
    debugInt = SendMessage(hWndIdToolTip, TTM_ADDTOOL, 0, (LPARAM) &ti);  // return TRUE if successful
	ti.uId = (UINT_PTR) hWndEna2;
    SendMessage(hWndIdToolTip, TTM_ADDTOOL, 0, (LPARAM) &ti);
	ti.uId = (UINT_PTR) hWndTrigEna1;
    SendMessage(hWndIdToolTip, TTM_ADDTOOL, 0, (LPARAM) &ti);
	ti.uId = (UINT_PTR) hWndTrigEna2;
    SendMessage(hWndIdToolTip, TTM_ADDTOOL, 0, (LPARAM) &ti);
	ti.uId = (UINT_PTR) hWndSlope1;
    SendMessage(hWndIdToolTip, TTM_ADDTOOL, 0, (LPARAM) &ti);
	ti.uId = (UINT_PTR) hWndSlope2;
    SendMessage(hWndIdToolTip, TTM_ADDTOOL, 0, (LPARAM) &ti);
	ti.uId = (UINT_PTR) hWndTimeDiv;
    SendMessage(hWndIdToolTip, TTM_ADDTOOL, 0, (LPARAM) &ti);
	ti.uId = (UINT_PTR) hWndX1Aten1;
    SendMessage(hWndIdToolTip, TTM_ADDTOOL, 0, (LPARAM) &ti);
	ti.uId = (UINT_PTR) hWndX10Aten1;
    SendMessage(hWndIdToolTip, TTM_ADDTOOL, 0, (LPARAM) &ti);
	ti.uId = (UINT_PTR) hWndX1Aten2;
    SendMessage(hWndIdToolTip, TTM_ADDTOOL, 0, (LPARAM) &ti);
	ti.uId = (UINT_PTR) hWndX10Aten2;
    SendMessage(hWndIdToolTip, TTM_ADDTOOL, 0, (LPARAM) &ti);
	ti.uId = (UINT_PTR) hWndZero1;
    SendMessage(hWndIdToolTip, TTM_ADDTOOL, 0, (LPARAM) &ti);
	ti.uId = (UINT_PTR) hWndZero2;
    SendMessage(hWndIdToolTip, TTM_ADDTOOL, 0, (LPARAM) &ti);
	ti.uId = (UINT_PTR) hWndVolt1;
    SendMessage(hWndIdToolTip, TTM_ADDTOOL, 0, (LPARAM) &ti);
	ti.uId = (UINT_PTR) hWndVolt2;
    SendMessage(hWndIdToolTip, TTM_ADDTOOL, 0, (LPARAM) &ti);
	ti.uId = (UINT_PTR) hWndTrig1;
    SendMessage(hWndIdToolTip, TTM_ADDTOOL, 0, (LPARAM) &ti);
	ti.uId = (UINT_PTR) hWndTrig2;
    SendMessage(hWndIdToolTip, TTM_ADDTOOL, 0, (LPARAM) &ti);

	SendMessage(hWndIdToolTip, TTM_ACTIVATE, true, 0);  // no return value

	// Set fonts for controls
	PostMessage(hWndEna1, WM_SETFONT, (WPARAM) Font2, false);
	PostMessage(hWndTrigEna1, WM_SETFONT, (WPARAM) Font2, false);
	PostMessage(hWndVlabel1, WM_SETFONT, (WPARAM) Font2, false);
	PostMessage(hWndZlabel1, WM_SETFONT, (WPARAM) Font2, false);
	PostMessage(hWndSlope1, WM_SETFONT, (WPARAM) Font2, false);
	PostMessage(hWndX1Aten1, WM_SETFONT, (WPARAM) Font2, false);
	PostMessage(hWndX10Aten1, WM_SETFONT, (WPARAM) Font2, false);

	PostMessage(hWndEna2, WM_SETFONT, (WPARAM) Font2, false);
	PostMessage(hWndTrigEna2, WM_SETFONT, (WPARAM) Font2, false);
	PostMessage(hWndVlabel2, WM_SETFONT, (WPARAM) Font2, false);
	PostMessage(hWndZlabel2, WM_SETFONT, (WPARAM) Font2, false);
	PostMessage(hWndSlope2, WM_SETFONT, (WPARAM) Font2, false);
	PostMessage(hWndX1Aten2, WM_SETFONT, (WPARAM) Font2, false);
	PostMessage(hWndX10Aten2, WM_SETFONT, (WPARAM) Font2, false);

	PostMessage(hWndStatus, WM_SETFONT, (WPARAM) Font2, false);
	PostMessage(hWndToolbar, WM_SETFONT, (WPARAM) Font1, false);  // prefer tiny font here
	
	return true;
}
// Display all controls in their proper state (except Display Windows's scroll bar)
// Based on settings in globals:
//   Determine which controls should be displayed or hidden
//   Set check boxes or radio buttons appropriately
//   Set trackbar sliders to the proper position
//   Set state of toolbar buttons (for those buttons that are push-on/push-off
//   Recalculate height of legend area in display window
// This should only be called rarely, usually in response to a user action,
// so efficiency is not a concern.  Everything is redone from scratch.
void DetermineControlVisibility()
{
	LegendHeight = 2 + LegendLineHeight;  // always at least one line for timediv in legend

	if (Ena1Checked) {
		LegendHeight += LegendLineHeight;  // a line for ch1 info
		CheckDlgButton(hWndMain, ID_ENA1, BST_CHECKED);
		SendMessage(hWndVolt1, TBM_SETPOS, (WPARAM) true, (LPARAM) Volt1);
		SendMessage(hWndZero1, TBM_SETPOS, (WPARAM) true, (LPARAM) Zero1);
		SendMessage(hWndTrig1, TBM_SETPOS, (WPARAM) true, (LPARAM) Zero1-Trig1);
		if (Aten1==1) CheckDlgButton(hWndMain, ID_BUTTONX1ATEN1, BST_CHECKED);
		else CheckDlgButton(hWndMain, ID_BUTTONX10ATEN1, BST_CHECKED);
		ShowWindow(hWndTrigEna1, SW_SHOW);
		ShowWindow(hWndVlabel1, SW_SHOW);
		ShowWindow(hWndZlabel1, SW_SHOW);
		ShowWindow(hWndZero1, SW_SHOW);
		ShowWindow(hWndVolt1, SW_SHOW);
		ShowWindow(hWndX1Aten1, SW_SHOW);
		ShowWindow(hWndX10Aten1, SW_SHOW);
		if (TrigEna1Checked) {
			CheckDlgButton(hWndMain, ID_TRIGENA1, BST_CHECKED);
			SendMessage(hWndSlope1, CB_SETCURSEL, (WPARAM)Slope1, (LPARAM)0);
			ShowWindow(hWndSlope1, SW_SHOW);
			ShowWindow(hWndTrig1, SW_SHOW);
		} else {
			CheckDlgButton(hWndMain, ID_TRIGENA1, BST_UNCHECKED);
			ShowWindow(hWndSlope1, SW_HIDE);
			ShowWindow(hWndTrig1, SW_HIDE);
		}
	} else {
		CheckDlgButton(hWndMain, ID_ENA1, BST_UNCHECKED);
		ShowWindow(hWndTrigEna1, SW_HIDE);
		ShowWindow(hWndVlabel1, SW_HIDE);
		ShowWindow(hWndZlabel1, SW_HIDE);
		ShowWindow(hWndZero1, SW_HIDE);
		ShowWindow(hWndVolt1, SW_HIDE);
		ShowWindow(hWndX1Aten1, SW_HIDE);
		ShowWindow(hWndX10Aten1, SW_HIDE);
		ShowWindow(hWndSlope1, SW_HIDE);
		ShowWindow(hWndTrig1, SW_HIDE);
	}

	if (Ena2Checked) {
		LegendHeight += LegendLineHeight;  // a line for ch2 info
		CheckDlgButton(hWndMain, ID_ENA2, BST_CHECKED);
		SendMessage(hWndVolt2, TBM_SETPOS, (WPARAM) true, (LPARAM) Volt2);
		SendMessage(hWndZero2, TBM_SETPOS, (WPARAM) true, (LPARAM) Zero2);
		SendMessage(hWndTrig2, TBM_SETPOS, (WPARAM) true, (LPARAM) Zero2-Trig2);
		if (Aten2==1) CheckDlgButton(hWndMain, ID_BUTTONX1ATEN2, BST_CHECKED);
		else CheckDlgButton(hWndMain, ID_BUTTONX10ATEN2, BST_CHECKED);
		ShowWindow(hWndTrigEna2, SW_SHOW);
		ShowWindow(hWndVlabel2, SW_SHOW);
		ShowWindow(hWndZlabel2, SW_SHOW);
		ShowWindow(hWndZero2, SW_SHOW);
		ShowWindow(hWndVolt2, SW_SHOW);
		ShowWindow(hWndX1Aten2, SW_SHOW);
		ShowWindow(hWndX10Aten2, SW_SHOW);
		if (TrigEna2Checked) {
			CheckDlgButton(hWndMain, ID_TRIGENA2, BST_CHECKED);
			SendMessage(hWndSlope2, CB_SETCURSEL, (WPARAM)Slope2, (LPARAM)0);
			ShowWindow(hWndSlope2, SW_SHOW);
			ShowWindow(hWndTrig2, SW_SHOW);
		} else {
			CheckDlgButton(hWndMain, ID_TRIGENA2, BST_UNCHECKED);
			ShowWindow(hWndSlope2, SW_HIDE);
			ShowWindow(hWndTrig2, SW_HIDE);
		}
	} else {
		CheckDlgButton(hWndMain, ID_ENA2, BST_UNCHECKED);
		ShowWindow(hWndTrigEna2, SW_HIDE);
		ShowWindow(hWndVlabel2, SW_HIDE);
		ShowWindow(hWndZlabel2, SW_HIDE);
		ShowWindow(hWndZero2, SW_HIDE);
		ShowWindow(hWndVolt2, SW_HIDE);
		ShowWindow(hWndX1Aten2, SW_HIDE);
		ShowWindow(hWndX10Aten2, SW_HIDE);
		ShowWindow(hWndSlope2, SW_HIDE);
		ShowWindow(hWndTrig2, SW_HIDE);
	}

	SendMessage(hWndTimeDiv, TBM_SETPOS, (WPARAM) true, (LPARAM) TimeDiv);

	// Toolbar buttons
	if (EnaExtraInfo) {
		LegendHeight += LegendLineHeight;  // a line for extra info
		SendMessage(hWndToolbar, TB_SETSTATE, IDM_EXTRAINFO, TBSTATE_ENABLED | TBSTATE_CHECKED);
	} else
		SendMessage(hWndToolbar, TB_SETSTATE, IDM_EXTRAINFO, TBSTATE_ENABLED);
	if (EnaMarkers)
		SendMessage(hWndToolbar, TB_SETSTATE, IDM_MARKERS, TBSTATE_ENABLED | TBSTATE_CHECKED);
	else
		SendMessage(hWndToolbar, TB_SETSTATE, IDM_MARKERS, TBSTATE_ENABLED);
	if (EnaSwTrig)
		SendMessage(hWndToolbar, TB_SETSTATE, IDM_SWTRIG, TBSTATE_ENABLED | TBSTATE_CHECKED);
	else
		SendMessage(hWndToolbar, TB_SETSTATE, IDM_SWTRIG, TBSTATE_ENABLED);
	if (EnaDaMode)
		SendMessage(hWndToolbar, TB_SETSTATE, IDM_DAMODE, TBSTATE_ENABLED | TBSTATE_CHECKED);
	else
		SendMessage(hWndToolbar, TB_SETSTATE, IDM_DAMODE, TBSTATE_ENABLED);

}

// Load appropriate HTMarch library for the Hantek device
// Parameters:
//  DevType IN: 1 = 6022BE, 0 = 6022BL, -1 = unknown
// Return value:
//  true if successful, false if unsuccessful
//  false should be considered fatal, as it could result in calling
//  an undefined section of memory.
bool LoadHantekLibrary(short DevType) {

	FreeLibrary(hLibMarch);	// just in case this is a reconnect
	if (DevType == 1) {
		// 6022BE
		hLibMarch = LoadLibrary(TEXT("HTMarchBE.dll"));
	} else if (DevType == 0) {
		// 6022BL
		hLibMarch = LoadLibrary(TEXT("HTMarchBL.dll"));
	} else {
		// no scope connected, try default library
		hLibMarch = LoadLibrary(TEXT("HTMarch.dll"));
	}
	// Now load individual functions
	if (hLibMarch != NULL) {
		if (!(dsoSetVoltDIV = (dsoSetVoltDIV_t) GetProcAddress(hLibMarch, "dsoSetVoltDIV"))) return false;
		if (!(dsoSetTimeDIV = (dsoSetTimeDIV_t) GetProcAddress(hLibMarch, "dsoSetTimeDIV"))) return false;
		if (!(dsoReadHardData = (dsoReadHardData_t) GetProcAddress(hLibMarch, "dsoReadHardData"))) return false;
		if (!(dsoGetCalLevel = (dsoGetCalLevel_t) GetProcAddress(hLibMarch, "dsoGetCalLevel"))) return false;
		if (!(dsoCalibrate = (dsoCalibrate_t) GetProcAddress(hLibMarch, "dsoCalibrate"))) return false;
		if (!(dsoSetCalLevel = (dsoSetCalLevel_t) GetProcAddress(hLibMarch, "dsoSetCalLevel"))) return false;
		if (DevType==0) {
			// One additional step for 6022BL - select oscilloscope section
			if (!(dsoChooseDevice = (dsoChooseDevice_t) GetProcAddress(hLibMarch, "dsoChooseDevice"))) return false;
			dsoChooseDevice(DeviceIndex, 1);
		}
		return true;
	}
	return false;
}

// This is based on RichardK's open source code
// Return value: 1 == 6022BE, 0 = 6022BL, -1 = unknown
//#define HANTEK_ID_6022BE "\\\\.\\d6022-%d"
//#define HANTEK_ID_6022BL "\\\\.\\d602a-%d"
short GetDeviceType(WORD DeviceIndex) {
	HANDLE Hnd;

	//Append device number to create Device Identifier for 6022BE
	_stprintf_s(filename, FILENAME_LEN, TEXT("\\\\.\\d6022-%d"), DeviceIndex);
	//Check for it
	Hnd = CreateFile(filename, GENERIC_WRITE, FILE_SHARE_WRITE, NULL, OPEN_EXISTING, NULL, NULL);
	if (Hnd != INVALID_HANDLE_VALUE) {
		CloseHandle(Hnd);
		return 1;			//Device is 6022BE
	}

	//Create Device Identifier for 6022BL
	_stprintf_s(filename, FILENAME_LEN, TEXT("\\\\.\\d602a-%d"), DeviceIndex);
	//Check for it
	Hnd = CreateFile(filename, GENERIC_WRITE, FILE_SHARE_WRITE, NULL, OPEN_EXISTING, NULL, NULL);
	if (Hnd != INVALID_HANDLE_VALUE) {
		CloseHandle(Hnd);
		return 0;			//Device is 6022BL
	}

	// Neither found
	return -1;
}

// Try to connect to Hantek 6022BE or 6022BL
// Avoid the dsoOpenDevice() call, because we have not yet loaded the Hantek library
// Do not make calls to AppendToStatus(), windoww may not have been created yet
void ConnectScope() {

Retry:
	for (DeviceIndex=0; DeviceIndex<=255; DeviceIndex++) {
		DeviceType = GetDeviceType(DeviceIndex);
		if (DeviceType==1 || DeviceType==0) return;
	}
	if (MessageBox(hWndMain,
		TEXT("BasicScope couldn't find the 6022.\nPlease check connections first\nbefore clicking Retry button."),
		TEXT("Connection Failure"), MB_ICONQUESTION | MB_RETRYCANCEL | MB_DEFBUTTON1)
		== IDRETRY) goto Retry;

	return;
}
//
//   FUNCTION: InitInstance(HINSTANCE, int)
//
//   PURPOSE: Saves instance handle and creates main window
//
//   COMMENTS:
//
//        In this function, we save the instance handle in a global variable and
//        create and display the main program window.
//
bool InitInstance(HINSTANCE hInstance)
{
	RECT Rect;

	hInst = hInstance; // Store instance handle in our global variable

	// Do not allow a second copy to run
	hMutexRunning = CreateMutex(NULL, true, TEXT("BasicScopeRunning"));
	if (ERROR_ALREADY_EXISTS == GetLastError()) {
		MessageBox(hWndMain, TEXT("Sorry, only one BasicScope can run at a time."), TEXT("Warning"), MB_ICONWARNING);
		return false;
	}

	// connect scope and load appropriate library
	// this should be called before just about anything else
	// as LoadSettings() makes Hantek calls, and so does DisplayPaint()
	ConnectScope();
	// Global DeviceType was set by ConnectScope
	if (!LoadHantekLibrary(DeviceType)) {
		MessageBox(hWndMain,
			TEXT("BasicScope couldn't load one of HTMarchBE.dll\nHTMarchBL.dl, or HTMarch.dll\nTry reinstalling."),
			TEXT("Library load failure"), MB_ICONWARNING | MB_OK);
		return false;  // unrecoverable error
	}
			
	// Initialize settings, by loading previous ones from registry if possible
	LoadSettings(&Rect);

	CreateResources();

	// Create all windows and controls, including the main one
	if (!CreateAllWindows(&Rect)) return false;

	// Most controls were hidden up until this point.
	// Un-hide as directed by checkboxes.
	DetermineControlVisibility();

	// Had to wait until here to inform user, windows had to be created
	if (DeviceType==1)
		AppendToStatus(TEXT("6022BE connected"));
	else if (DeviceType==0)
		AppendToStatus(TEXT("6022BL connected"));
	else
		AppendToStatus(TEXT("Hantek 6022 not found - please check connections."));

	// Show the main window.  This generates a WM_SIZE that causes all child
	// windows and controls to be sized and positioned appropriately.
	ShowWindow(hWndMain, WindowState);
//	UpdateWindow(hWnd);  // no need for now.  Main window does not paint

	return true;
}

// Calculate dimensions of display window, based on various system globals
// The only reason this is made into a function here is so that the same
// code can be used consistently in multiple places.  If the compiler in-lines
// this code, fine.
void CalcDisplayDimensions(short nWidth, short nHeight) {
	DisplayHeight = nHeight-(4*FrameHeight+2*CaptionHeight+TrackbarLeadin+StatusHeight+ToolbarHeight);
	DisplayWidth = nWidth-(2*DisplayMargin);
}

// Resize all child windows and controls, given new size of client rect
// for main window.
void ResizeEverything(short nWidth, short nHeight)
{
	// The main display window doesn't move, only sizes.
	// x and y parameters set to 0 to save calculation (compiler will just set to 0 and push)
	CalcDisplayDimensions(nWidth, nHeight);
	SetWindowPos(hWndDisplay, NULL, 0, 0,
		DisplayWidth, DisplayHeight, SWP_DEFERERASE | SWP_NOMOVE | SWP_SHOWWINDOW | SWP_NOSENDCHANGING);
	SetWindowPos(hWndTimeDiv, NULL, 0, 0,
		nWidth-2*(FrameHeight+DisplayMargin), SliderWidth1, SWP_NOMOVE | SWP_SHOWWINDOW | SWP_NOSENDCHANGING);

	// These controls neither move nor size
//	SetWindowPos(hWndEna1, NULL, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOSENDCHANGING);
//	SetWindowPos(hWndTrigEna1, NULL, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOSENDCHANGING);
//	SetWindowPos(hWndVlabel1, NULL, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOSENDCHANGING);
//	SetWindowPos(hWndZlabel1, NULL, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOSENDCHANGING);
//	SetWindowPos(hWndSlope1, NULL, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOSENDCHANGING);
	SliderHeight = nHeight-(2*CaptionHeight+4*FrameHeight+LegendHeight+ScrollHeight+StatusHeight+ToolbarHeight)+TrackbarLeadin;
	WaveformHeight = SliderHeight - 2*TrackbarLeadin;

	// These sliders don't move, only size.
	SetWindowPos(hWndVolt1, NULL, 0, 0,
		SliderWidth1, SliderHeight, SWP_NOMOVE | SWP_NOSENDCHANGING);
	SetWindowPos(hWndZero1, NULL, 0, 0,
		SliderWidth2, SliderHeight, SWP_NOMOVE | SWP_NOSENDCHANGING);
	SetWindowPos(hWndTrig1, NULL, 0, 0,
		SliderWidth2, SliderHeight, SWP_NOMOVE | SWP_NOSENDCHANGING);

	// These controls move but don't size.  Unused parameters set to 0.
	SetWindowPos(hWndEna2, NULL, nWidth-DisplayMargin+ButtonWidth2, FrameHeight,
		0, 0, SWP_NOSIZE | SWP_SHOWWINDOW | SWP_NOSENDCHANGING);
	SetWindowPos(hWndTrigEna2, NULL, nWidth-DisplayMargin, FrameHeight,
		0, 0, SWP_NOSIZE | SWP_NOSENDCHANGING);
	SetWindowPos(hWndZlabel2, NULL, nWidth-DisplayMargin+ButtonWidth2, FrameHeight+CaptionHeight,
		0, 0, SWP_NOSIZE | SWP_NOSENDCHANGING);
	SetWindowPos(hWndVlabel2, NULL, nWidth-DisplayMargin+ButtonWidth2+SliderWidth2+FrameHeight, FrameHeight+CaptionHeight,
		0, 0, SWP_NOSIZE | SWP_NOSENDCHANGING);
	SetWindowPos(hWndSlope2, NULL, nWidth-DisplayMargin, FrameHeight+CaptionHeight,
		0, 0, SWP_NOSIZE | SWP_NOSENDCHANGING);
	SetWindowPos(hWndX1Aten1, NULL, FrameHeight, FrameHeight+2*CaptionHeight+SliderHeight,
		0, 0, SWP_NOSIZE | SWP_NOSENDCHANGING);
	SetWindowPos(hWndX10Aten1, NULL, FrameHeight, FrameHeight+3*CaptionHeight+SliderHeight,
		0, 0, SWP_NOSIZE | SWP_NOSENDCHANGING);
	InvalidateRect(hWndX10Aten1, NULL, false);  // one of the few controls that needs repaint
	SetWindowPos(hWndX1Aten2, NULL, nWidth-DisplayMargin+ButtonWidth2+SliderWidth2+FrameHeight, FrameHeight+2*CaptionHeight+SliderHeight,
		0, 0, SWP_NOSIZE | SWP_NOSENDCHANGING);
	SetWindowPos(hWndX10Aten2, NULL, nWidth-DisplayMargin+ButtonWidth2+SliderWidth2+FrameHeight, FrameHeight+3*CaptionHeight+SliderHeight,
		0, 0, SWP_NOSIZE | SWP_NOSENDCHANGING);
	InvalidateRect(hWndX10Aten2, NULL, false);  // one of the few controls that needs repaint

	// These move and size
	SetWindowPos(hWndTrig2, NULL, nWidth-DisplayMargin, FrameHeight+2*CaptionHeight,
		SliderWidth2, SliderHeight, SWP_NOSENDCHANGING);
	SetWindowPos(hWndZero2, NULL, nWidth-DisplayMargin+ButtonWidth2, FrameHeight+2*CaptionHeight,
		SliderWidth2, SliderHeight, SWP_NOSENDCHANGING);
	SetWindowPos(hWndVolt2, NULL, nWidth-DisplayMargin+ButtonWidth2+SliderWidth2+FrameHeight, FrameHeight+2*CaptionHeight,
		SliderWidth1, SliderHeight, SWP_NOSENDCHANGING);
	SetWindowPos(hWndStatus, NULL, 2*FrameHeight+SliderWidth1, nHeight-(2*FrameHeight+StatusHeight+ToolbarHeight),
		nWidth-4*FrameHeight-2*SliderWidth1, StatusHeight, SWP_SHOWWINDOW | SWP_NOSENDCHANGING);
	SetWindowPos(hWndPager, NULL, FrameHeight, nHeight-(FrameHeight+ToolbarHeight),
		nWidth-2*FrameHeight, ToolbarHeight, SWP_SHOWWINDOW | SWP_NOSENDCHANGING);

	RecalcMarkerPositions();  // Markers may have moved on a resize
}

// Put markers on screen in known location
// intersections of grid lines near top left
void ParkMarkers() {
	Marker[0].MeasureX = DelayTicks
		- (4*DisplayWidth/10)
		* TimeParms[TimeDiv].TicksPerSample * TimeParms[TimeDiv].DisLen / DisplayWidth;
	Marker[2].MeasureX = Marker[0].MeasureX;
	Marker[0].MeasureY = 
		(Zero1 - 32) * VoltParms[Volt1].VoltsPerDiv / 32.0;
	Marker[1].MeasureY = Marker[0].MeasureY;
	Marker[1].MeasureX = DelayTicks
		- (3*DisplayWidth/10)
		* TimeParms[TimeDiv].TicksPerSample * TimeParms[TimeDiv].DisLen / DisplayWidth;
	Marker[3].MeasureX = Marker[1].MeasureX;
	Marker[2].MeasureY = 
		(Zero2 - 64) * VoltParms[Volt2].VoltsPerDiv / 32.0;
	Marker[3].MeasureY = Marker[2].MeasureY;
}

// Find the closest displayed marker to point (x,y), and return its index
// If all markers are further than a maximum distance, return -1
// Distance is measured in screen coordinates
// Search is done in terms of distance^2 to avoid square root
// Preference given to higher marker index, under assumption that lower
// index might already be placed right
int ClosestMarker(int x, int y) {
	int DistSquared;
	int ClosestDistSquared = (SpriteOffset - 1) * (SpriteOffset - 1);
	int ClosestIndex = -1;

	if (Ena1Checked) {
		for (i=0; i <= 1; i++) {
			DistSquared = (Marker[i].ScreenX - x) * (Marker[i].ScreenX - x) + (Marker[i].ScreenY - y) * (Marker[i].ScreenY - y);
			if (DistSquared <= ClosestDistSquared) {
				ClosestDistSquared = DistSquared;
				ClosestIndex = i;
			}
		}
	}
	if (Ena2Checked) {
		for (i=2; i <= 3; i++) {
			DistSquared = (Marker[i].ScreenX - x) * (Marker[i].ScreenX - x) + (Marker[i].ScreenY - y) * (Marker[i].ScreenY - y);
			if (DistSquared <= ClosestDistSquared) {
				ClosestDistSquared = DistSquared;
				ClosestIndex = i;
			}
		}
	}
	return ClosestIndex;
}

// Check whether a trace could be displayed given the current settings.
// A trace is displayable if the delay from the trigger lies within the
// bounds of the capture buffer.
// Return true if can make such a capture.
bool CaptureInRange() {
	// Do not use DelaySamples directly, that preserves the position
	// of the presently displayed trace.  Instead, recompute what
	// DelaySamples would have been at the new TimeDiv setting
	long TempDelaySamples;

	// compute region in which to search for trigger
	TrigScanStart = 0;
	TrigScanEnd = TimeParms[TimeDiv].ReadLen - 1;
	TempDelaySamples = DelayTicks / TimeParms[TimeDiv].TicksPerSample;
	if (TempDelaySamples < 0) TrigScanStart -= TempDelaySamples;
	if (TempDelaySamples > 0) TrigScanEnd -= TempDelaySamples;

	if (TrigScanStart > TrigScanEnd) {
		StopScope();  // prevent ongoing captures, if any
		EngSprint(OutString1, OUTSTR_LEN, TimeParms[TimeDiv].TicksPerSample * TimeParms[TimeDiv].ReadLen / 48e6, TEXT("S"));
		_stprintf_s(OutString2, OUTSTR_LEN, TEXT("\r\nCannot capture at this sample rate and delay.\r\nEither scroll to within %s of trigger,\r\nor increase the time per division setting."), OutString1);
		AppendToStatus(OutString2);
		MessageBox(hWndMain, OutString2, TEXT("Out of Range"), MB_ICONWARNING);
		return false;
	} else {
		return true;
	}
}

//
//  FUNCTION: MainWndProc(HWND, UINT, WPARAM, LPARAM)
//
//  PURPOSE:  Processes messages for the main window.
//
//  WM_COMMAND	- process the application menu
//  WM_PAINT	- Paint the main window
//  WM_DESTROY	- post a quit message and return
//
//
LRESULT CALLBACK MainWndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	int wmId, wmEvent;

	switch (message)
	{
	case WM_CREATE:
		hThreadAcquisition = CreateThread(
			NULL,  // default security
			0,  // default stack size
			AcquisitionThread,
			&hWnd,
			0,  // default creation flags
			NULL  // don't care about thread ID
			);
		break;
	case WM_COMMAND:
		wmId    = LOWORD(wParam);
		wmEvent = HIWORD(wParam);
		// Parse the menu selections:
		switch (wmId)
		{
		case ID_ENA1:
			if (wmEvent==BN_CLICKED) {
				Ena1Checked = (BST_CHECKED == IsDlgButtonChecked(hWnd, ID_ENA1));
				DetermineControlVisibility();
				ResizeEverything(MainClientWidth, MainClientHeight);  // because height of scroll bars changes
				// so that background color will be updated
				InvalidateRect(hWndEna1, NULL, false);
				// so that trace will be added to/removed from display, legend resized
				InvalidateRect(hWndDisplay, NULL, false);
			}
			break;
		case ID_ENA2:
			if (wmEvent==BN_CLICKED) {
				Ena2Checked = (BST_CHECKED == IsDlgButtonChecked(hWnd, ID_ENA2));
				DetermineControlVisibility();
				ResizeEverything(MainClientWidth, MainClientHeight);  // because height of scroll bars changes
				// so that background color will be updated
				InvalidateRect(hWndEna2, NULL, false);
				// so that trace will be added to/removed from display, legend resized
				InvalidateRect(hWndDisplay, NULL, false);
			}
			break;
		case ID_TRIGENA1:
			if (wmEvent==BN_CLICKED) {
				TrigEna1Checked = (BST_CHECKED == IsDlgButtonChecked(hWnd, ID_TRIGENA1));
				if (TrigEna1Checked) {
					TrigEna2Checked = false;
					CheckDlgButton(hWnd, ID_TRIGENA2, BST_UNCHECKED);
					InvalidateRect(hWndTrigEna2, NULL, false);  // redraw in case leftover red text
				} else
					InvalidateRect(hWndTrigEna1, NULL, false);  // in case leftover red text
				RecalcTrigger();
				DetermineControlVisibility();
				InvalidateRect(hWndDisplay, NULL, false);
			}
			break;
		case ID_TRIGENA2:
			if (wmEvent==BN_CLICKED) {
				TrigEna2Checked = (BST_CHECKED == IsDlgButtonChecked(hWnd, ID_TRIGENA2));
				if (TrigEna2Checked) {
					TrigEna1Checked = false;
					CheckDlgButton(hWnd, ID_TRIGENA1, BST_UNCHECKED);
					InvalidateRect(hWndTrigEna1, NULL, false);  // in case leftover red text
				} else
					InvalidateRect(hWndTrigEna2, NULL, false);  // in case leftover red text
				RecalcTrigger();
				DetermineControlVisibility();
				InvalidateRect(hWndDisplay, NULL, false);
			}
			break;
		case ID_BUTTONX1ATEN1:
			if (wmEvent==BN_CLICKED) Aten1 = 1;
			RecalcMarkerPositions();
			InvalidateRect(hWndDisplay, NULL, false);  // to update legend on display
			break;
		case ID_BUTTONX10ATEN1:
			if (wmEvent==BN_CLICKED) Aten1 = 10;
			RecalcMarkerPositions();
			InvalidateRect(hWndDisplay, NULL, false);
			break;
		case ID_BUTTONX1ATEN2:
			if (wmEvent==BN_CLICKED) Aten2 = 1;
			RecalcMarkerPositions();
			InvalidateRect(hWndDisplay, NULL, false);
			break;
		case ID_BUTTONX10ATEN2:
			if (wmEvent==BN_CLICKED) Aten2 = 10;
			RecalcMarkerPositions();
			InvalidateRect(hWndDisplay, NULL, false);
			break;
		case ID_SLOPE1:
			if (wmEvent==CBN_SELCHANGE) {
				Slope1 = (SLOPETYPE) SendMessage(hWndSlope1, CB_GETCURSEL, (WPARAM)0, (LPARAM)0);
				RecalcTrigger();
				InvalidateRect(hWndDisplay, NULL, false);  // so legend updated
			}
			break;
		case ID_SLOPE2:
			if (wmEvent==CBN_SELCHANGE) {
				Slope2 = (SLOPETYPE) SendMessage(hWndSlope2, CB_GETCURSEL, (WPARAM)0, (LPARAM)0);
				RecalcTrigger();
				InvalidateRect(hWndDisplay, NULL, false);  // so legend updated
			}
			break;
		case IDM_ABOUT:
			DialogBox(hInst, MAKEINTRESOURCE(IDD_ABOUTBOX), hWnd, About);
			break;
		case IDM_EDITBUTTONS:
			SendMessage(hWndToolbar, TB_CUSTOMIZE, 0, 0);
			break;
		case IDM_CALIBRATE:
			if (MessageBox(hWndMain, TEXT("Calibration is almost never required.\nBOTH SCOPE CHANNELS MUST HAVE THEIR PROBES GROUNDED BEFORE PROCEEDING.\nCalibrate?"),
				TEXT("Calibrate"), MB_YESNO | MB_DEFBUTTON2 | MB_ICONQUESTION)==IDYES) {
				if (dsoCalibrate(DeviceIndex, TimeDiv, Volt1, Volt2, CalData)==0) {
					// successful calibration, store result
					dsoSetCalLevel(DeviceIndex, CalData, CALDATA_LEN);
				} else {
					// restore last saved calibration
					dsoGetCalLevel(DeviceIndex, CalData, CALDATA_LEN);
				}
			}
			break;
		case IDM_EXTRAINFO:
			EnaExtraInfo = (SendMessage(hWndToolbar, TB_ISBUTTONCHECKED, IDM_EXTRAINFO, 0) != 0);
			DetermineControlVisibility();
			ResizeEverything(MainClientWidth, MainClientHeight);  // to update WaveformHeight
			InvalidateRect(hWndDisplay, NULL, false);
			break;
		case IDM_MARKERS:
			EnaMarkers = (SendMessage(hWndToolbar, TB_ISBUTTONCHECKED, IDM_MARKERS, 0) != 0);
			InvalidateRect(hWndDisplay, NULL, false);
			break;
		case IDM_SWTRIG:
			EnaSwTrig = (SendMessage(hWndToolbar, TB_ISBUTTONCHECKED, IDM_SWTRIG, 0) != 0);
			// Disallow disable of software trig if both edge triggering is selected
			if (!EnaSwTrig && ((TrigEna1Checked && Slope1==BothEdg) || (TrigEna2Checked && Slope2==BothEdg))) {
				AppendToStatus(TEXT("\r\nTrigger on both edges requires software trig. Cannot disable."));
				EnaSwTrig = true;
				DetermineControlVisibility();  // overkill to just update one button
			}
			break;
		case IDM_FIRSTTRIG:
			// if there is a valid trace being displayed, stop the scope and look for a trigger
			if (buffer[1-BufToFill].valid) {
				short status;
				if (!scope_stopped) StopScope();
				if (!TrigEna1Checked && !TrigEna2Checked) {
					// case of null trigger (trigger on anything)
					buffer[1-BufToFill].trigpoint = 0;
				} else {
					status = FindTrig(buffer[1-BufToFill].data[TrigEna1Checked ? 0 : 1],
						0, TimeParms[DisplayTimeDiv].ReadLen-1, TrigLevel,
						TrigEna1Checked ? Slope1 : Slope2, &(buffer[1-BufToFill].trigpoint));
					if (status==1) AppendToStatus(TEXT("\r\nNo trigger found."));
					DelaySamples = 0;
					DelayTicks = 0;
				}
				InvalidateRect(hWndDisplay, NULL, false);
			}
			break;
		case IDM_NEXTTRIG:
			// This code is identical to that for IDM_FIRSTTRIG, except
			// for the starting point of the search, and handling of
			// null trigger case
			if (buffer[1-BufToFill].valid) {
				short status;
				if (!scope_stopped) StopScope();
				if (!TrigEna1Checked && !TrigEna2Checked) {
					// case of null trigger, just increment to next sample, if any
					if (buffer[1-BufToFill].trigpoint < TimeParms[DisplayTimeDiv].ReadLen-1) {
						buffer[1-BufToFill].trigpoint++;
					}
				} else {
					// search, starting with first sample after present trigger point
					status = FindTrig(buffer[1-BufToFill].data[TrigEna1Checked ? 0 : 1],
						buffer[1-BufToFill].trigpoint + 1, TimeParms[DisplayTimeDiv].ReadLen - 1, TrigLevel,
						TrigEna1Checked ? Slope1 : Slope2, &(buffer[1-BufToFill].trigpoint));
					if (status==1) AppendToStatus(TEXT("\r\nNo more triggers found."));
					DelaySamples = 0;
					DelayTicks = 0;
				}
				InvalidateRect(hWndDisplay, NULL, false);
			}
			break;
		case IDM_PARKMARKERS:
			ParkMarkers();
			RecalcMarkerPositions();
			// don't bother refreshing if the markers are invisible, anyway
			if (EnaMarkers) InvalidateRect(hWndDisplay, NULL, false);
			break;
		case IDM_RUNNORM:
			if (SendMessage(hWndToolbar, TB_ISBUTTONCHECKED, IDM_RUNNORM, 0) != 0) {
				scope_oneshot = false;
				SendMessage(hWndToolbar, TB_CHECKBUTTON, IDM_RUNONCE, false);  // pop other button
				if (CaptureInRange()) {
					buffer[0].valid = false;
					buffer[1].valid = false;
					scope_stopped = false;
					InvalidateRect(hWndDisplay, NULL, false);  // to clear display
				}
			} else {
				//scope_stopped = true;
				StopScope();
			}
			break;
		case IDM_RUNONCE:
			if (SendMessage(hWndToolbar, TB_ISBUTTONCHECKED, IDM_RUNONCE, 0) != 0) {
				scope_oneshot = true;
				SendMessage(hWndToolbar, TB_CHECKBUTTON, IDM_RUNNORM, false);  // pop other button
				if (CaptureInRange()) {
					buffer[0].valid = false;
					buffer[1].valid = false;
					scope_stopped = false;
					InvalidateRect(hWndDisplay, NULL, false);  // to clear display
				}
			} else {
				StopScope();
			}
			break;
		case IDM_SAVEBIN:
			SaveTrace();
			break;
		case IDM_LOADBIN:
			LoadTrace();
			break;
		case IDM_SAVEDISPLAY:
			DWORD status;

			status = SaveDisplay(hWndDisplay);
			if (status != NO_ERROR) {
				FormatMessage(FORMAT_MESSAGE_FROM_SYSTEM, NULL, status, 0, OutString1, OUTSTR_LEN, NULL);
				AppendToStatus(TEXT("\r\nSorry: "));
				AppendToStatus(OutString1);
				MessageBox(hWndMain, OutString1, TEXT("Error"), MB_ICONINFORMATION);
			}
			break;
		case IDM_SAVECSV:
			SaveCsv();
			break;
		case IDM_DAFILENAME:
			// Set filename for data acquisition
			memset(&ofn, 0, sizeof(ofn));  // null pointers for uninitialized choices
			ofn.lStructSize = sizeof(OPENFILENAME);
			ofn.hwndOwner = hWndMain;  // must specify owner, or dialog will not be modal
			ofn.lpstrFilter = TEXT("Comma Separated Value Files (*.csv)\0*.csv\0All Files (*.*)\0*.*\0");
			ofn.lpstrFile = DataAcqfilename;
			ofn.nMaxFile = FILENAME_LEN;
			ofn.Flags = OFN_EXPLORER | OFN_HIDEREADONLY;
			ofn.lpstrDefExt = TEXT("csv");
			if (!GetSaveFileName(&ofn)) {
				// fail on file name
				debugInt = CommDlgExtendedError();
				if (debugInt != 0) {
					_stprintf_s(OutString1, OUTSTR_LEN, TEXT("CommDlgExtendedError %08lx"), debugInt);
					MessageBox(hWndMain, OutString1, TEXT("File Name Error"), MB_ICONINFORMATION);
				}
			}
			break;
		case IDM_DAMODE:
			// Set or unset data acquisition mode
			// Button is sticky, push-on / push-off
			EnaDaMode = (SendMessage(hWndToolbar, TB_ISBUTTONCHECKED, IDM_DAMODE, 0) != 0);
			break;
		case IDM_TEST1:
			//AppendToStatus(TEXT("\r\n-----"));
			if (EnaDaMode){
				AppendToStatus(TEXT("\r\nData Acquisition Mode is enabled."));
			} else {
				AppendToStatus(TEXT("\r\nData Acquisition Mode is disabled."));
			}
			break;
		case IDM_TEST2:
			AppendToStatus(TEXT("\r\nbuild: ")TEXT(__DATE__)TEXT(" ")TEXT(__TIME__));
			break;
		case IDM_TEST3:
			LoadHantekLibrary(1);
			break;
		case IDM_DBGBREAK:
			debugInt = (int) hWndDisplay;
			debugInt1 = MainClientHeight;
			debugInt2 = MainClientWidth;
			debugInt2 = TrigLevel;
			break;
		case IDM_TEST6:
			break;
		case IDM_TEST7:
			break;
		case IDM_UNZOOM:
			// Reset zoom.  Restore time and voltage settings under which
			// trace was originally captured.
			if (buffer[1-BufToFill].valid) {
				TimeDiv = buffer[1-BufToFill].timediv;
				SetTimeDiv(TimeDiv);
				Volt1 = buffer[1-BufToFill].volt1;
				debugInt = dsoSetVoltDIV(DeviceIndex, CH1, VoltParms[Volt1].Volt);
				Volt2 = buffer[1-BufToFill].volt2;
				debugInt = dsoSetVoltDIV(DeviceIndex, CH2, VoltParms[Volt2].Volt);
				// Triggers remain constant, but adjust sliders to match new voltage ranges
				Trig1 = (short) (32.0 * TrigVolt1 / VoltParms[Volt1].VoltsPerDiv);
				Trig2 = (short) (32.0 * TrigVolt2 / VoltParms[Volt2].VoltsPerDiv);
				RecalcTrigger();
				SendMessage(hWndTrig1, TBM_SETPOS, (WPARAM) true, (LPARAM) Zero1 - Trig1);
				SendMessage(hWndTrig2, TBM_SETPOS, (WPARAM) true, (LPARAM) Zero2 - Trig2);
				RecalcMarkerPositions();
 				InvalidateRect(hWndDisplay, NULL, false);
			}
			break;
		case IDM_TEST9:
			// Reset pan
			if (buffer[1-BufToFill].valid) {
				DelayTicks = 0;
				DelaySamples = 0;
				si.nPos = 0;
				si.fMask = SIF_DISABLENOSCROLL | SIF_POS;
				SetScrollInfo(hWndDisplay, SB_HORZ, &si, true);
				RecalcMarkerPositions();
 				InvalidateRect(hWndDisplay, NULL, false);
			}
			break;
		case IDM_EXIT:
			DestroyWindow(hWnd);
			break;
		default:
			return DefWindowProc(hWnd, message, wParam, lParam);
		}
		break;
	case WM_SIZING:
		// this message comes in as the window is being dragged to size
		MainWindowIsSizing = true;  // this makes DisplayPaint show dimensions
		InvalidateRect(hWndDisplay, NULL, false);  // invoke DisplayPaint at leisure
		// return (LRESULT) true; ok to return false, have not altered RECT
		break;
	case WM_SIZE:
		MainClientWidth = (short) LOWORD(lParam);
		MainClientHeight = (short) HIWORD(lParam);
		ResizeEverything(MainClientWidth, MainClientHeight);
		InvalidateRect(hWndDisplay, NULL, false);  // should be unnecessary
		break;

	//case WM_PAINT:
	//	MainPaint(hWnd);
	//	break;

	// It's one of the trackbars trying to set something
	case WM_VSCROLL:
		int ReqType, position;

		ReqType = LOWORD(wParam);
		if (ReqType == TB_THUMBTRACK) {
			// Must process TB_THUMBTRACK to give visual dragline
			// Only zero and trig generate dragline, not volt
			position = HIWORD(wParam);
			switch (GetDlgCtrlID((HWND) lParam)) {
				case ID_VOLT1:
					Volt1 = position;
					debugInt = dsoSetVoltDIV(DeviceIndex, CH1, VoltParms[Volt1].Volt);
					// Trigger remains constant, but adjust slider to match new voltage range
					Trig1 = (short) (32.0 * TrigVolt1 / VoltParms[Volt1].VoltsPerDiv);
					RecalcTrigger();
					SendMessage(hWndTrig1, TBM_SETPOS, (WPARAM) true, (LPARAM) Zero1 - Trig1);
					RecalcMarkerPositions();
					break;
				case ID_ZERO1:
					Zero1 = position;
					// Adjust Trigger trackbar to maintain same level
					SendMessage(hWndTrig1, TBM_SETPOS, (WPARAM) true, (LPARAM) Zero1 - Trig1);
					// Scale dragline to window height.  The scope has a resolution
					// of 8 bits, which means full scale is 256 levels.
					// Can also just shift right by 8 bits
					//HorizDragLineAt = position * WaveformHeight / 256;
					HorizDragLineAt = (position * WaveformHeight) >>8;
					RecalcMarkerPositions();
					break;
				case ID_TRIG1:
					Trig1 = Zero1 - position;  // the signed offset from the zero point
					TrigVolt1 = Trig1 * VoltParms[Volt1].VoltsPerDiv / 32.0;
					RecalcTrigger();
					HorizDragLineAt = (position * WaveformHeight) >>8;
					break;
				case ID_VOLT2:
					Volt2 = position;
					debugInt = dsoSetVoltDIV(DeviceIndex, CH2, VoltParms[Volt2].Volt);
					// Trigger remains constant, but adjust slider to match new voltage range
					Trig2 = (short) (32.0 * TrigVolt2 / VoltParms[Volt2].VoltsPerDiv);
					RecalcTrigger();
					SendMessage(hWndTrig2, TBM_SETPOS, (WPARAM) true, (LPARAM) Zero2 - Trig2);
					RecalcMarkerPositions();
					break;
				case ID_ZERO2:
					Zero2 = position;
					SendMessage(hWndTrig2, TBM_SETPOS, (WPARAM) true, (LPARAM) Zero2 - Trig2);
					HorizDragLineAt = (position * WaveformHeight) >>8;
					RecalcMarkerPositions();
					break;
				case ID_TRIG2:
					Trig2 = Zero2 - position;
					TrigVolt2 = Trig2 * VoltParms[Volt2].VoltsPerDiv / 32.0;
					RecalcTrigger();
					HorizDragLineAt = (position * WaveformHeight) >>8;
					break;
				default:
					break;
			}
		} else {
			// process all other positioning messages
			// including TB_LINELEFT, TB_LINERIGHT, TB_PAGELEFT, TB_PAGERIGHT
			// in the case of ReqType == TB_THUMBPOSITION, the position
			// could have been retrieved from wParam, but the
			// code is simpler to just do everything one way
			// no dragline for this kind of movement

			//position = GetScrollPos((HWND) lParam, SB_CTL);  // only works for actual scrollbars, not trackbars
			position = SendMessage((HWND) lParam, TBM_GETPOS, (WPARAM) 0, (LPARAM) 0);
			switch (GetDlgCtrlID((HWND) lParam)) {
				case ID_VOLT1:
					Volt1 = position;
					debugInt = dsoSetVoltDIV(DeviceIndex, CH1, VoltParms[Volt1].Volt);
					// Trigger remains constant, but adjust slider to match new voltage range
					Trig1 = (short) (32.0 * TrigVolt1 / VoltParms[Volt1].VoltsPerDiv);
					SendMessage(hWndTrig1, TBM_SETPOS, (WPARAM) true, (LPARAM) Zero1 - Trig1);
					RecalcMarkerPositions();
					break;
				case ID_ZERO1:
					Zero1 = position;
					SendMessage(hWndTrig1, TBM_SETPOS, (WPARAM) true, (LPARAM) Zero1 - Trig1);
					RecalcMarkerPositions();
					break;
				case ID_TRIG1:
					Trig1 = Zero1 - position;  // the signed offset from the zero point
					TrigVolt1 = Trig1 * VoltParms[Volt1].VoltsPerDiv / 32.0;
					RecalcTrigger();
					break;
				case ID_VOLT2:
					Volt2 = position;
					debugInt = dsoSetVoltDIV(DeviceIndex, CH2, VoltParms[Volt2].Volt);
					// Trigger remains constant, but adjust slider to match new voltage range
					Trig2 = (short) (32.0 * TrigVolt2 / VoltParms[Volt2].VoltsPerDiv);
					SendMessage(hWndTrig2, TBM_SETPOS, (WPARAM) true, (LPARAM) Zero2 - Trig2);
					RecalcMarkerPositions();
					break;
				case ID_ZERO2:
					Zero2 = position;
					SendMessage(hWndTrig2, TBM_SETPOS, (WPARAM) true, (LPARAM) Zero2 - Trig2);
					RecalcMarkerPositions();
					break;
				case ID_TRIG2:
					Trig2 = Zero2 - position;
					TrigVolt2 = Trig2 * VoltParms[Volt2].VoltsPerDiv / 32.0;
					RecalcTrigger();
					break;
				default:
					break;
			}
			HorizDragLineAt = -1;  // cancel draglines
			VertDragLineAt = -1;
		}
		InvalidateRect(hWndDisplay, NULL, false);
		break;

	// There is only one control, the TimeDiv trackbar.
	// This code is simple, but somewhat wasteful, in
	// that it processes every message the same way.
	// Fortunately, changing the time slider is neither
	// a frequent nor performance-sensitive operation.
	case WM_HSCROLL:
		if (GetDlgCtrlID((HWND) lParam) == ID_TIMEDIV) {
			position = SendMessage((HWND) lParam, TBM_GETPOS, (WPARAM) 0, (LPARAM) 0);
			SetTimeDiv(position);
			RecalcMarkerPositions();
 			InvalidateRect(hWndDisplay, NULL, false);
			// Don't allow out-of-range capture to continue
			if (!scope_stopped) CaptureInRange();
		}
		break;
	case WM_NOTIFY:
		switch( ((LPNMHDR)lParam )->code) {
			case PGN_CALCSIZE:
				// ideally should check which control generated this, but
				// I know that I only have one pager in the program
				// Match the pager scrolling size to the toolbar
				LPNMPGCALCSIZE pCS;
				SIZE tbSize;				
				pCS = (LPNMPGCALCSIZE)lParam;
				switch( pCS->dwFlag ){
					case PGF_CALCHEIGHT:
						if (SendMessage(hWndToolbar, TB_GETIDEALSIZE, true, (LPARAM) &tbSize))
							pCS->iHeight = tbSize.cy;
						break;
					case PGF_CALCWIDTH:
						if (SendMessage(hWndToolbar, TB_GETIDEALSIZE, false, (LPARAM) &tbSize))
							pCS->iWidth = tbSize.cx;
						break;
					default:
						break;
				}
				break;
			case TBN_TOOLBARCHANGE:
				// Make sure buttons have proper appearance of checked (pressed) or not
				DetermineControlVisibility();  // overkill, but not a performance issue
				// Recalculate size in case scroll bar needs to appear or disappear
				PostMessage(hWndPager, PGM_RECALCSIZE, 0, 0);
				break;
			case TBN_GETBUTTONINFO:
                LPTBNOTIFY lpTbNotify;
				lpTbNotify = (LPTBNOTIFY)lParam;
                // Pass the next button from the array. There is no need to filter out buttons
                // that are already used—they will be ignored.
                if (lpTbNotify->iItem < nButtons) {
                    lpTbNotify->tbButton = tbButtonList[lpTbNotify->iItem];
                    return TRUE;
                } else {
                    return FALSE;  // No more buttons.
                }
				break;  // not really necessary, but keep programming discipline
			case TBN_QUERYINSERT:
			case TBN_QUERYDELETE:
				// no need to check the source of the request, as
				// there is only one toolbar in the program,
				// and the answer is always yes
				return true;
				break;
			// case TTN_GETDISPINFO: same as TTN_NEEDTEXT
			case TTN_NEEDTEXT:
				LPTOOLTIPTEXT lpttt;
				UINT idFrom;
				lpttt = (LPTOOLTIPTEXT) lParam;
				//lpttt->hinst = hInst;  // need not set if not using resource strings
				// In case of trackbar, lpttt->hdr.idFrom = hWndTrackBar
				idFrom = lpttt->hdr.idFrom;
				if (idFrom == (UINT) hWndTimeDiv) {
					_stprintf_s(OutString2, OUTSTR_LEN, TEXT("Sweep rate: %s"), TimeParms[SendMessage(hWndTimeDiv,TBM_GETPOS,0,0)].label);
					lpttt->lpszText = OutString2;
				} else if (idFrom == (UINT) hWndVolt1) {
					EngSprint(OutString1, OUTSTR_LEN, Aten1 * VoltParms[Volt1].VoltsPerDiv, TEXT("V/div"));
					_stprintf_s(OutString2, OUTSTR_LEN, TEXT("Ch1: %s"), OutString1);
					lpttt->lpszText = OutString2;
				} else if (idFrom == (UINT) hWndVolt2) {
					EngSprint(OutString1, OUTSTR_LEN, Aten2 * VoltParms[Volt2].VoltsPerDiv, TEXT("V/div"));
					_stprintf_s(OutString2, OUTSTR_LEN, TEXT("Ch2: %s"), OutString1);
					lpttt->lpszText = OutString2;
				} else if (idFrom == (UINT) hWndZero1) {
					EngSprint(OutString1, OUTSTR_LEN, (128-Zero1) * Aten1 * VoltParms[Volt1].VoltsPerDiv / 32.0, TEXT("V"));
					_stprintf_s(OutString2, OUTSTR_LEN, TEXT("Ch1 position: %s"), OutString1);
					lpttt->lpszText = OutString2;
				} else if (idFrom == (UINT) hWndTrig1) {
					EngSprint(OutString1, OUTSTR_LEN, Trig1 * Aten1 * VoltParms[Volt1].VoltsPerDiv / 32.0, TEXT("V"));
					// warn if trig exceeds clipping level of scope
					// this warning only appears on tooltip
					if (-160 < Trig1 && Trig1 < 160) {
						_stprintf_s(OutString2, OUTSTR_LEN, TEXT("Ch1 trigger: %s"), OutString1);
					} else {
						_stprintf_s(OutString2, OUTSTR_LEN, TEXT("Ch1 trigger: %s (OutOfRange)"), OutString1);
					}
					lpttt->lpszText = OutString2;
				} else if (idFrom == (UINT) hWndZero2) {
					EngSprint(OutString1, OUTSTR_LEN, (128-Zero2) * Aten2 * VoltParms[Volt2].VoltsPerDiv / 32.0, TEXT("V"));
					_stprintf_s(OutString2, OUTSTR_LEN, TEXT("Ch2 position: %s"), OutString1);
					lpttt->lpszText = OutString2;
				} else if (idFrom == (UINT) hWndTrig2) {
					EngSprint(OutString1, OUTSTR_LEN, Trig2 * Aten2 * VoltParms[Volt2].VoltsPerDiv / 32.0, TEXT("V"));
					if (-160 < Trig2 && Trig2 < 160) {
						_stprintf_s(OutString2, OUTSTR_LEN, TEXT("Ch2 trigger: %s"), OutString1);
					} else {
						_stprintf_s(OutString2, OUTSTR_LEN, TEXT("Ch2 trigger: %s (OutOfRange)"), OutString1);
					}
					lpttt->lpszText = OutString2;
				} else if (idFrom == (UINT) hWndEna1) {
					lpttt->lpszText = TEXT("Enable channel 1");
				} else if (idFrom == (UINT) hWndEna2) {
					lpttt->lpszText = TEXT("Enable channel 2");
				} else if (idFrom == (UINT) hWndTrigEna1) {
					lpttt->lpszText = TEXT("Select channel 1 for trigger");
				} else if (idFrom == (UINT) hWndTrigEna2) {
					lpttt->lpszText = TEXT("Select channel 2 for trigger");
				} else if (idFrom == (UINT) hWndSlope1 || idFrom == (UINT) hWndSlope2) {
					lpttt->lpszText = TEXT("Which edge(s) to trigger on");
				} else if (idFrom == (UINT) hWndX1Aten1 || idFrom == (UINT) hWndX10Aten1) {
					lpttt->lpszText = TEXT("Channel 1 probe attenuation");
				} else if (idFrom == (UINT) hWndX1Aten2 || idFrom == (UINT) hWndX10Aten2) {
					lpttt->lpszText = TEXT("Channel 2 probe attenuation");
				}
				else {
					// should never hit this
					_stprintf_s(OutString2, OUTSTR_LEN, TEXT("BUG: unknown control, please report"));
					lpttt->lpszText = OutString2;
				}
				break;
			default:
				break;
		}
		break;
	case WM_TIMER:
		// don't need to check which one, as there is only one timer,
		// the one that flashes the "trg" text red for a moment when
		// there is a trigger.  When the timer pops, the text is set back
		// to black.
		KillTimer(hWndMain, IDT_TIMER);
		RecentTrigger = false;
		if (TrigEna1Checked) InvalidateRect(hWndTrigEna1, NULL, false);
		if (TrigEna2Checked) InvalidateRect(hWndTrigEna2, NULL, false);
		break;
	case WM_CTLCOLORSTATIC:
		// Controls are asking what brush to use for background
		switch (GetDlgCtrlID((HWND) lParam)) {
			case ID_TRIGENA1:
				// Flash the trigger label briefly to show that trigger received
				if (RecentTrigger && TrigEna1Checked) SetTextColor((HDC) wParam, RGB(255,0,0));
				//else SetTextColor((HDC) wParam, RGB(0,0,0)); no need, this is default
				// fall though to set background brush
			case ID_ENA1:
			case ID_VLABEL1:
			case ID_ZLABEL1:
			case ID_SLOPE1:
			case ID_ZERO1:
			case ID_VOLT1:
			case ID_TRIG1:
			case ID_BUTTONX1ATEN1:
			case ID_BUTTONX10ATEN1:
				if (Ena1Checked) return (LRESULT) Ch1Brush;
				break;
			case ID_TRIGENA2:
				if (RecentTrigger && TrigEna2Checked) SetTextColor((HDC) wParam, RGB(255,0,0));
				// fall though to set background brush
			case ID_ENA2:
			case ID_VLABEL2:
			case ID_ZLABEL2:
			case ID_SLOPE2:
			case ID_ZERO2:
			case ID_VOLT2:
			case ID_TRIG2:
			case ID_BUTTONX1ATEN2:
			case ID_BUTTONX10ATEN2:
				if (Ena2Checked) return (LRESULT) Ch2Brush;
				break;
			case ID_TIMEDIV:
				return (LRESULT) TimeBrush;
			default:
				break;
		}
		return DefWindowProc(hWnd, message, wParam, lParam);
		break;
	case WM_DESTROY:
		// tell acquisition thread to stop,
		// then wait for it to terminate,
		// but no longer than 10 seconds
		ContinueAcquisitionThread = false;
		WaitForSingleObject(hThreadAcquisition, 10000);
		CloseHandle(hThreadAcquisition);

		SaveSettings(hWnd);
		FreeResources();
		ReleaseMutex(hMutexRunning);
		CloseHandle(hMutexRunning);
		PostQuitMessage(0);
		break;
	default:
		return DefWindowProc(hWnd, message, wParam, lParam);
	}
	return 0;
}

// Windows Procedure for Window showing scope display
LRESULT CALLBACK DisplayWndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
//	int wmId, wmEvent;

	switch (message) {
		case WM_CREATE:
			HDC hdc;
			SIZE s;
			hdc = GetDC(hWnd);
			// Calculate constants we will need for display later
			SelectFont(hdc, Font2);  // font for legend
			GetTextExtentPoint32(hdc, TEXT("⊞"), _tcslen(TEXT("⊞")),&s);  // maybe better than GetTextMetrics()
			LegendLineHeight = s.cy + 2;
			GetTextExtentPoint32(hdc, TEXT("Ch1: 500 mV/div"), _tcslen(TEXT("Ch1: 500 mV/div")),&s);
			MarkerTxtPos1 = 2 + s.cx + 2*txm.tmAveCharWidth;
			GetTextExtentPoint32(hdc, TEXT("⊞: -500mV"), _tcslen(TEXT("⊞: -500mV")),&s);
			MarkerTxtPos2 = MarkerTxtPos1 + s.cx + 2*txm.tmAveCharWidth;
			MarkerTxtPos3 = MarkerTxtPos2 + s.cx + 2*txm.tmAveCharWidth;
			SelectFont(hdc, Font3);  // markers drawn with larger size than legend
			GetTextExtentPoint32(hdc, TEXT("⊞"), _tcslen(TEXT("⊞")),&s);  // maybe better than GetTextMetrics()
			SpriteOffset = s.cy/2 + 1;
			break;
		case WM_NCHITTEST:
			// Set focus to self when mouse enters display window
			// client area.
			// must have focus so that can see mouse wheel
			// TrackMouseEvent() will generate WM_NCMOUSELEAVE when mouse exits
			// Reason for checking focus first is so that won't have  multiple
			// calls to TrackMouseEvent()
			LRESULT res;
			res = DefWindowProc(hWnd, message, wParam, lParam);
			if ((res==HTCLIENT) && (GetFocus() != hWndDisplay)) {
				SetFocus(hWndDisplay);
				TRACKMOUSEEVENT tme = {sizeof(TRACKMOUSEEVENT)};
				tme.dwFlags = TME_LEAVE;
				tme.hwndTrack = hWndDisplay;
				TrackMouseEvent(&tme);
			}
			return res;
			break;
		case WM_MOUSELEAVE:
			SetFocus(NULL);  // give up focus
			break;
		case WM_LBUTTONDOWN:
			if (EnaMarkers) {
				// if the user clicks near a marker, flag it for dragging
				MarkerBeingDragged = ClosestMarker(GET_X_LPARAM(lParam), GET_Y_LPARAM(lParam));
			}
			PanStartX = GET_X_LPARAM(lParam);  // save x coord to determine future drag amount
			PanStartSamples = DelaySamples;
			break;
		case WM_LBUTTONUP:
			MarkerBeingDragged = -1;
			VertDragLineAt = -1;
			HorizDragLineAt = -1;
			InvalidateRect(hWnd, NULL, false);
			break;
		case WM_MOUSEMOVE:
			if (!(wParam & MK_LBUTTON) || !buffer[1-BufToFill].valid)
				// either not dragging, or nothing being displayed
				break;
			else {
				// The mouse is being dragged in the display window.
				if (MarkerBeingDragged >= 0) {
					// it is a marker being dragged, update position
					Marker[MarkerBeingDragged].ScreenX = GET_X_LPARAM(lParam);
					// don't allow dragging marker beyond waveform area into legend area
					if (GET_Y_LPARAM(lParam) < WaveformHeight)
						Marker[MarkerBeingDragged].ScreenY = GET_Y_LPARAM(lParam);
					else
						Marker[MarkerBeingDragged].ScreenY = WaveformHeight;
					// Translate screen pixel values into absolute Measure values
					Marker[MarkerBeingDragged].MeasureX = DelayTicks
						+ (GET_X_LPARAM(lParam) - DisplayWidth/2)
						* TimeParms[TimeDiv].TicksPerSample * TimeParms[TimeDiv].DisLen / DisplayWidth;
					// Round time to nearest multiple of TicksPerSample
					int excess;
					excess = Marker[MarkerBeingDragged].MeasureX % TimeParms[TimeDiv].TicksPerSample;
					if (excess < (TimeParms[TimeDiv].TicksPerSample/2))
						Marker[MarkerBeingDragged].MeasureX = Marker[MarkerBeingDragged].MeasureX - excess;
					else
						Marker[MarkerBeingDragged].MeasureX = Marker[MarkerBeingDragged].MeasureX - excess + TimeParms[TimeDiv].TicksPerSample;
					Marker[MarkerBeingDragged].MeasureY = 
						(*(Marker[MarkerBeingDragged].Zslider) - (Marker[MarkerBeingDragged].ScreenY<<8)/WaveformHeight) * VoltParms[*(Marker[MarkerBeingDragged].Vslider)].VoltsPerDiv / 32.0;
					VertDragLineAt = Marker[MarkerBeingDragged].ScreenX;
					HorizDragLineAt = Marker[MarkerBeingDragged].ScreenY;
				} else {
					// it is the whole window being drag-panned
					si.fMask = SIF_RANGE | SIF_PAGE;
					GetScrollInfo(hWndDisplay, SB_HORZ, &si);  // get scroll bar limits for bounds check
					si.nPos = PanStartSamples -
						(long) ((GET_X_LPARAM(lParam) - PanStartX) * HZoomFactor * TimeParms[DisplayTimeDiv].DisLen / DisplayWidth);
					if (si.nPos < si.nMin) si.nPos = si.nMin;  // bounds checks
					if (si.nPos > (si.nMax - (int) si.nPage + 1)) si.nPos = si.nMax - si.nPage + 1;
					si.fMask = SIF_DISABLENOSCROLL | SIF_POS;
					SetScrollInfo(hWndDisplay, SB_HORZ, &si, true);
					DelaySamples = si.nPos;
					DelayTicks = DelaySamples * TimeParms[DisplayTimeDiv].TicksPerSample;
					RecalcMarkerPositions();
					// Don't allow out-of-range capture to continue
					if (!scope_stopped) CaptureInRange();
				}
				InvalidateRect(hWndDisplay, NULL, false);
			}
			break;
		case WM_MOUSEWHEEL:
			short WheelMovement;
			WheelMovement = (short) HIWORD(wParam);  // wheel movement in high word
			// if buffer is being displayed, re-center it about the cursor in time
			if (buffer[1-BufToFill].valid) {
				POINT p;  // to do screen to client conversion
				si.fMask = SIF_RANGE | SIF_PAGE;
				GetScrollInfo(hWndDisplay, SB_HORZ, &si);  // get scroll bar limits for bounds check
				p.x = GET_X_LPARAM(lParam); p.y = GET_Y_LPARAM(lParam);  // GetCursorPos(&p);
				ScreenToClient(hWndDisplay, &p);
				si.nPos = DelaySamples + (int)((p.x - DisplayWidth/2) *
					HZoomFactor * TimeParms[DisplayTimeDiv].DisLen / DisplayWidth);
				if (si.nPos < si.nMin) si.nPos = si.nMin;  // bounds checks
				if (si.nPos > (si.nMax - (int) si.nPage + 1)) si.nPos = si.nMax - si.nPage + 1;
				si.fMask = SIF_DISABLENOSCROLL | SIF_POS;
				SetScrollInfo(hWndDisplay, SB_HORZ, &si, true);
				DelaySamples = si.nPos;
				DelayTicks = DelaySamples * TimeParms[DisplayTimeDiv].TicksPerSample;
				// force cursor to horizontal middle of screen after zooming
				// to be ready in case the user wanted to zoom multiple clicks
				p.x = DisplayWidth/2;
				ClientToScreen(hWndDisplay, &p);
				SetCursorPos(p.x, p.y);
			}
			if (WheelMovement == 0) break;
			if ((WheelMovement > 0) && (TimeDiv > 0)) {
				// Zoom in
				TimeDiv--;
			} else if ((WheelMovement < 0) && (TimeDiv+1 < nTimeParms)) {  // WheelMovement guaranteed to be < 0 here
				// Zoom out
				TimeDiv++;
			}
			SetTimeDiv(TimeDiv);
			RecalcMarkerPositions();
			InvalidateRect(hWndDisplay, NULL, false);
			// Don't allow out-of-range capture to continue
			if (!scope_stopped) CaptureInRange();
			break;
		case WM_CHAR:
			// The only character input to the Display Window that we care about is zoom in/out
			if ((wParam == TEXT('+')) || (wParam == TEXT('-'))) {
				if (buffer[1-BufToFill].valid) {
					POINT p;  // to do screen to client conversion
					si.fMask = SIF_RANGE | SIF_PAGE;
					GetScrollInfo(hWndDisplay, SB_HORZ, &si);  // get scroll bar limits for bounds check
					GetCursorPos(&p);
					ScreenToClient(hWndDisplay, &p);
					si.nPos = DelaySamples + (int)((p.x - DisplayWidth/2) *
						HZoomFactor * TimeParms[DisplayTimeDiv].DisLen / DisplayWidth);
					if (si.nPos < si.nMin) si.nPos = si.nMin;  // bounds checks
					if (si.nPos > (si.nMax - (int) si.nPage + 1)) si.nPos = si.nMax - si.nPage + 1;
					si.fMask = SIF_DISABLENOSCROLL | SIF_POS;
					SetScrollInfo(hWndDisplay, SB_HORZ, &si, true);
					DelaySamples = si.nPos;
					DelayTicks = DelaySamples * TimeParms[DisplayTimeDiv].TicksPerSample;
					// force cursor to middle of screen horizontally after zooming
					// to be ready in case the user wanted to zoom multiple clicks
					p.x = DisplayWidth/2;
					ClientToScreen(hWndDisplay, &p);
					SetCursorPos(p.x, p.y);
				}
				if ((wParam == TEXT('+')) && (TimeDiv > 0)) {
					// Zoom in
					TimeDiv--;
				} else if ((wParam == TEXT('-')) && (TimeDiv+1 < nTimeParms)) {
					// Zoom out
					TimeDiv++;
				}
				SetTimeDiv(TimeDiv);
				RecalcMarkerPositions();
				InvalidateRect(hWndDisplay, NULL, false);
				// Don't allow out-of-range capture to continue
				if (!scope_stopped) CaptureInRange();
			}
		case WM_HSCROLL:
			// if scroll is coming from Display Window's own scroll bar
			if (lParam == NULL) {
				int ReqType = LOWORD(wParam);
				switch (ReqType) {
					case SB_THUMBTRACK:
					//case SB_THUMBPOSITION:  not needed, SB_THUMBTRACK already covers it
						si.fMask = SIF_TRACKPOS;
						GetScrollInfo(hWndDisplay, SB_HORZ, &si);
						si.fMask = SIF_DISABLENOSCROLL | SIF_POS;
						si.nPos = si.nTrackPos;
						SetScrollInfo(hWndDisplay, SB_HORZ, &si, false);  // can set false, no redraw needed
						DelaySamples = si.nPos;
						DelayTicks = DelaySamples * TimeParms[DisplayTimeDiv].TicksPerSample;
						break;
					case SB_LINELEFT:
						// Scroll left by one pixel, or one sample, whichever is greater
						int SamplesPerPixel;
						si.fMask = SIF_PAGE | SIF_POS | SIF_RANGE;
						GetScrollInfo(hWndDisplay, SB_HORZ, &si);
						SamplesPerPixel = (int) (HZoomFactor * TimeParms[DisplayTimeDiv].DisLen / DisplayWidth);
						if (SamplesPerPixel < 1) SamplesPerPixel = 1;
						si.nPos -= SamplesPerPixel;
						if (si.nPos < si.nMin) si.nPos = si.nMin;
						si.fMask = SIF_DISABLENOSCROLL | SIF_POS;
						SetScrollInfo(hWndDisplay, SB_HORZ, &si, true);
						DelaySamples = si.nPos;
						DelayTicks = DelaySamples * TimeParms[DisplayTimeDiv].TicksPerSample;
						break;
					case SB_LINERIGHT:
						si.fMask = SIF_PAGE | SIF_POS | SIF_RANGE;
						GetScrollInfo(hWndDisplay, SB_HORZ, &si);
						SamplesPerPixel = (int) (HZoomFactor * TimeParms[DisplayTimeDiv].DisLen / DisplayWidth);
						if (SamplesPerPixel < 1) SamplesPerPixel = 1;
						si.nPos += SamplesPerPixel;
						if (si.nPos > (si.nMax - (int) si.nPage + 1)) si.nPos = si.nMax - si.nPage + 1;
						si.fMask = SIF_DISABLENOSCROLL | SIF_POS;
						SetScrollInfo(hWndDisplay, SB_HORZ, &si, true);
						DelaySamples = si.nPos;
						DelayTicks = DelaySamples * TimeParms[DisplayTimeDiv].TicksPerSample;
						break;
					case SB_PAGELEFT:
						si.fMask = SIF_PAGE | SIF_POS | SIF_RANGE;
						GetScrollInfo(hWndDisplay, SB_HORZ, &si);
						si.nPos -= si.nPage;
						if (si.nPos < si.nMin) si.nPos = si.nMin;
						si.fMask = SIF_DISABLENOSCROLL | SIF_POS;
						SetScrollInfo(hWndDisplay, SB_HORZ, &si, true);
						DelaySamples = si.nPos;
						DelayTicks = DelaySamples * TimeParms[DisplayTimeDiv].TicksPerSample;
						break;
					case SB_PAGERIGHT:
						si.fMask = SIF_PAGE | SIF_POS | SIF_RANGE;
						GetScrollInfo(hWndDisplay, SB_HORZ, &si);
						si.nPos += si.nPage;
						if (si.nPos > (si.nMax - (int) si.nPage + 1)) si.nPos = si.nMax - si.nPage + 1;
						si.fMask = SIF_DISABLENOSCROLL | SIF_POS;
						SetScrollInfo(hWndDisplay, SB_HORZ, &si, true);
						DelaySamples = si.nPos;
						DelayTicks = DelaySamples * TimeParms[DisplayTimeDiv].TicksPerSample;
						break;
					default:
						break;
				}
				RecalcMarkerPositions();
				InvalidateRect(hWndDisplay, NULL, false);
				// Don't allow out-of-range capture to continue
				if (!scope_stopped) CaptureInRange();
			}
			break;
		case WM_PAINT:
			DisplayPaint(hWnd);
			break;
		//case WM_DESTROY:
		//	break;
		default:
			return DefWindowProc(hWnd, message, wParam, lParam);
		}
	return 0;
}

// Display paint procedure.  Capable of redrawing entire scope screen at any time.
// A word on the double-buffering control:
// There are two buffer sets, buffer[0] and buffer[1]
// each of these contains all the information gathered in a trace, including
// both channels of data, the capture settings, and a flag
// to say whether the buffer is valid.
// If valid==true, DisplayPaint() owns the buffer, and can read it
// for display.
// If valid==false, AcquisitionThread() owns the buffer, and can write
// it with trace data.
// In addition, there is the variable BufToFill, which is the index of the
// buffer that AcquisitionThread() might potentially fill.  The buffer NOT
// pointed to by BufToFill is potentially available for display.
// Neither DisplayPint() not AcquisitionThread() can forcibly claim a buffer;
// each can only yield it to the other.  AcquisitionThread() can
// only set valid=true on the buffer that is indexed by BufToFill, and
// DisplayPaint() can only set valid=false on the buffer NOT indexed by BufToFill.
void DisplayPaint(HWND hWnd)
{
	PAINTSTRUCT ps;
	HDC hdc;
	RECT Rect, MessageRect;
	short BufToDisplay;
	bool InBounds;
	int TextOutY;  // y-coord for current line being output in Legend area
	int len;  // length of string to print

	// If the non-displayed buffer has valid data, the first duty is to swap buffers so
	// that a new buffer can be gathered.  After that, the buffer can be displayed at
	// our leisure.
	// If the user hits the STOP button, preserve the existing display if there is one.
	if (buffer[BufToFill].valid && !scope_stopped) {
		// programmer's note on why these operations are done in this order:
		// philosophically, DisplayPaint() should only operate on the buffer
		// NOT pointed to by BufToFill.
		buffer[1-BufToFill].valid = false;  // invalidate presently displayed buffer
		BufToFill = 1 - BufToFill;  // swap buffers.  This is the only place buffers can be swapped

		if (scope_oneshot) {
			// slight chance of race condition with user pressing button, but
			// result either way is not devastating
			StopScope();
		}
	}
	BufToDisplay = 1 - BufToFill;  // convenience variable

	hdc = BeginPaint(hWnd, &ps);
	GetClientRect(hWnd, &MessageRect);

	// Leave room for Legend at bottom
	Rect.left = MessageRect.left;
	Rect.top = MessageRect.top;
	Rect.right = MessageRect.right;
	Rect.bottom = MessageRect.bottom - LegendHeight;
	MessageRect.top = Rect.bottom;

	HTDrawGrid(hdc,
		Rect.left, // bouncds of rect
		Rect.top,
		Rect.right,
		Rect.bottom,
		10, // number of horizontal grid divisions
		8, // number of vertical grid divisions
		255, // the brightness of the line
		1 // 1 = draw grid divisions
	);

	// If window is being sized, don't bother repainting, just show dimensions of display
	// Reason for checking if left mouse button is up is in case user clicks on border
	// to size, does not actually drag the border, then lets go of the button.  That would
	// leave the dimensions on the display.
	if (MainWindowIsSizing) {
		if (GetKeyState(VK_LBUTTON) < 0) {
			//len = _stprintf_s(OutString1, OUTSTR_LEN, TEXT("%d x %d"), DisplayWidth, DisplayHeight);
			len = _stprintf_s(OutString1, OUTSTR_LEN, TEXT("%d x %d"), MessageRect.right, MessageRect.bottom);
			TextOut(hdc, 5, 5, OutString1, len);
			EndPaint(hWnd, &ps);
			return;
		} else
			MainWindowIsSizing = false;
	}

	if (buffer[BufToDisplay].valid) {
		// Calculate horizontal zoom factor first,
		// might be used for scroll bar setting
		HZoomFactor = 1.0L;  // default if no scaling
		if (buffer[BufToDisplay].timediv > TimeDiv) {
			// zoom in
			for (i= buffer[BufToDisplay].timediv; i > TimeDiv; i--) {
				HZoomFactor /= TimeParms[i].ScaleOut;
			}
		} else if (buffer[BufToDisplay].timediv < TimeDiv) {
			// zoom out
			for (i= buffer[BufToDisplay].timediv; i < TimeDiv; i++) {
				HZoomFactor *= TimeParms[i+1].ScaleOut;
			}
		}

		// If TimeDiv of this trace does not match the one previously configured for the Display
		// Window's scroll bar, configure the scroll bar now
		// Also recalculate DelaySamples
		// This could be done on every display, but is done only when there
		// is a change, in order to gain a little performance.
		// Note that this scrollbar has a range that goes from a negative
		// number to a positive number.
		// In theory could scroll from -(.ReadLen -1) to +(ReadLen -1),
		// but that would leave no room for an edge trigger, which takes 2 samples.
		// Extra margin of 1 sample required, but make it 3.
		if (DisplayTimeDiv != buffer[BufToDisplay].timediv) {
			DisplayTimeDiv = buffer[BufToDisplay].timediv;
			si.fMask = SIF_DISABLENOSCROLL | SIF_PAGE | SIF_POS | SIF_RANGE;
			si.nPage = (UINT) (TimeParms[DisplayTimeDiv].DisLen * HZoomFactor);  // one page, as zoomed
			if (si.nPage < 1) si.nPage = 1;
			if ((int) si.nPage > TimeParms[DisplayTimeDiv].ReadLen/2) si.nPage = TimeParms[DisplayTimeDiv].ReadLen/2;
			// extra margin of 3 for the trigger
			si.nMin = -(TimeParms[DisplayTimeDiv].ReadLen - 1 - 3);
			// must add one extra page to upper limit to get proper position returned
			// .ReadLen - 1 points to last element in array
			// .nPage - 1 is the way Windows works
			// extra margin of 3 for the trigger
			si.nMax =   TimeParms[DisplayTimeDiv].ReadLen - 1 + si.nPage - 1 - 3;
			DelaySamples = DelayTicks / TimeParms[DisplayTimeDiv].TicksPerSample;
			si.nPos = DelaySamples;
			SetScrollInfo(hWndDisplay, SB_HORZ, &si, true);
		}

		// If the center of the display would be out-of-bounds for the buffer
		// do not display at all.  This is important, because the Hantek
		// routines do not check, and could generate an invalid allocation size
		// (negative, which when cast unsigned becomes huge) on a heap request
		InBounds = (buffer[BufToDisplay].trigpoint+DelaySamples >= 0) && (buffer[BufToDisplay].trigpoint+DelaySamples < TimeParms[DisplayTimeDiv].ReadLen);

		if (Ena1Checked) {
			// Calculate vertical zoom factor
			// Note that scale is opposite sense from time scale,
			// so slightly different code from TimeDiv
			VZoomFactor1 = 1.0L;
			if (buffer[BufToDisplay].volt1 > Volt1) {
				// zoom out
				for (i= buffer[BufToDisplay].volt1; i > Volt1; i--) {
					VZoomFactor1 *= VoltParms[i].ScaleOut;
				}
			} else if (buffer[BufToDisplay].volt1 < Volt1) {
				// zoom in
				for (i= buffer[BufToDisplay].volt1; i < Volt1; i++) {
					VZoomFactor1 /= VoltParms[i+1].ScaleOut;
				}
			}
			if (InBounds) {
				HTDrawWaveInYT(
					hdc, // drawing context
					Rect, // drawing area
					ch1Color, // color of the line
					0, // display type : 0=Line or Dot
					buffer[BufToDisplay].data[CH1], // the source data for drawing
					TimeParms[DisplayTimeDiv].ReadLen, //the source data length
					TimeParms[DisplayTimeDiv].DisLen, // the display length data for drawing
					buffer[BufToDisplay].trigpoint+DelaySamples, // index of center of display
					Zero1, // vertical display position (Zero Level)
					HZoomFactor, //double dbHorizontal,// the horizontal factor of zoom out/in
					VZoomFactor1, //double dbVertical,// the vertical factor of zoom out/in
					0, //nYTFormat, //format: 0=normal or 1=scan
					0 //nScanLen // the scan data length, only invalidate in scan mode
				);
			}
			// Draw markers on top of trace, if any
			if (EnaMarkers) {
				SetTextColor(hdc, ch1Color);
				SetBkMode(hdc, TRANSPARENT);
				SelectFont(hdc, Font3);
				SetTextAlign(hdc, TA_TOP | TA_CENTER | TA_NOUPDATECP);
				TextOut(hdc, Marker[0].ScreenX, Marker[0].ScreenY-SpriteOffset, &(Marker[0].sprite), 1);
				TextOut(hdc, Marker[1].ScreenX, Marker[1].ScreenY-SpriteOffset, &(Marker[1].sprite), 1);
			}
		}
		if (Ena2Checked) {
			VZoomFactor2 = 1.0L;
			if (buffer[BufToDisplay].volt2 > Volt2) {
				// zoom out
				for (i= buffer[BufToDisplay].volt2; i > Volt2; i--) {
					VZoomFactor2 *= VoltParms[i].ScaleOut;
				}
			} else if (buffer[BufToDisplay].volt2 < Volt2) {
				// zoom in
				for (i= buffer[BufToDisplay].volt2; i < Volt2; i++) {
					VZoomFactor2 /= VoltParms[i+1].ScaleOut;
				}
			}

			if (InBounds) {
				HTDrawWaveInYT(
					hdc, // handle
					Rect, // the rect for drawing
					ch2Color,// the color of the line
					0,// display type : Line or Dot
					buffer[BufToDisplay].data[CH2], // the source data for drawing
					TimeParms[DisplayTimeDiv].ReadLen, //the source data length
					TimeParms[DisplayTimeDiv].DisLen,// the display length data for drawing
					buffer[BufToDisplay].trigpoint+DelaySamples,// center of display
					Zero2, //the display position (Zero Level)
					HZoomFactor, //double dbHorizontal,// the horizontal factor of zoom out/in
					VZoomFactor2, //double dbVertical,// the vertical factor of zoom out/in
					0, //nYTFormat,//format: normal or scan
					0 //nScanLen// the scan data length, only invalidate in scan mode
				);
			}
			if (EnaMarkers) {
				SetTextColor(hdc, ch2Color);
				SetBkMode(hdc, TRANSPARENT);
				SelectFont(hdc, Font3);
				SetTextAlign(hdc, TA_TOP | TA_CENTER | TA_NOUPDATECP);
				TextOut(hdc, Marker[2].ScreenX, Marker[2].ScreenY-SpriteOffset, &(Marker[2].sprite), 1);
				TextOut(hdc, Marker[3].ScreenX, Marker[3].ScreenY-SpriteOffset, &(Marker[3].sprite), 1);
			}
		}
	}

	// Legend area
	// The entire Legend region is blanked, then drawn
	// This reduces flicker, as opposed to blanking it, then
	// filling in various lines as the traces are being drawn.
	FillRect(hdc, &MessageRect, (HBRUSH) GetStockObject(BLACK_BRUSH));
	//FillRect(hdc, &MessageRect, (HBRUSH) GetStockObject(WHITE_BRUSH));
	TextOutY = MessageRect.top+2;
	SetTextColor(hdc, TimeColor);
	SetBkMode(hdc, TRANSPARENT);
	SelectFont(hdc, Font2);
	// Time and trigger-related info
	// 1.  Sweep - time/Div
	// 2.  Delay from trigger
	// 3.  Trigger source, edge, level (source indicated by color)
	SetTextAlign(hdc, TA_TOP | TA_LEFT | TA_NOUPDATECP);
	TextOut(hdc, MessageRect.left+2, TextOutY, TimeParms[TimeDiv].label, _tcsnlen(TimeParms[TimeDiv].label, 30));
	EngSprint(OutString1, OUTSTR_LEN, DelayTicks/48e6, TEXT("S"));
	if (DelayTicks >= 0)
		len = _stprintf_s(OutString2, OUTSTR_LEN, TEXT("trig+%s"), OutString1);
	else
		len = _stprintf_s(OutString2, OUTSTR_LEN, TEXT("trig%s"), OutString1);
	SetTextAlign(hdc, TA_TOP | TA_CENTER | TA_NOUPDATECP);
	if (len>0) TextOut(hdc, MessageRect.right/2, TextOutY, OutString2, len);
	SetTextAlign(hdc, TA_TOP | TA_RIGHT | TA_NOUPDATECP);
	if (!TrigEna1Checked && !TrigEna2Checked) {
		// case of no trigger
		TextOut(hdc, MessageRect.right-2, TextOutY, TEXT("Trig: none"), _tcslen(TEXT("Trig: none")));
	} else if (TrigEna1Checked) {
		SetTextColor(hdc, ch1Color);
		EngSprint(OutString1, OUTSTR_LEN, Trig1 * Aten1 * VoltParms[Volt1].VoltsPerDiv / 32.0, TEXT("V"));
		len = _stprintf_s(OutString2, OUTSTR_LEN, TEXT("Trig: %s @ %s"), SlopeName[Slope1], OutString1);
		if (len>0) TextOut(hdc, MessageRect.right-2, TextOutY, OutString2, len);
	} else if (TrigEna2Checked) {
		SetTextColor(hdc, ch2Color);
		EngSprint(OutString1, OUTSTR_LEN, Trig2 * Aten2 * VoltParms[Volt2].VoltsPerDiv / 32.0, TEXT("V"));
		len = _stprintf_s(OutString2, OUTSTR_LEN, TEXT("Trig: %s @ %s"), SlopeName[Slope2], OutString1);
		if (len>0) TextOut(hdc, MessageRect.right-2, TextOutY, OutString2, len);
	}
	TextOutY += LegendLineHeight;  // move to next line
	if (buffer[BufToDisplay].valid) {
		if (Ena1Checked) {
			// Report Channel 1 info in legend area
			// 1. Volts/Div
			// 2. Markers (if enabled)
			SetTextColor(hdc, ch1Color);
			SetTextAlign(hdc, TA_TOP | TA_LEFT | TA_NOUPDATECP);
			EngSprint(OutString2, OUTSTR_LEN, Aten1 * VoltParms[Volt1].VoltsPerDiv, TEXT("V/div"));
			len = _stprintf_s(OutString1, OUTSTR_LEN, TEXT("Ch1: %s"), OutString2);
			if (len>0) TextOut(hdc, 2, TextOutY, OutString1, len);
			if (EnaMarkers) {
				EngSprint(OutString2, OUTSTR_LEN, Aten1 * Marker[0].MeasureY, TEXT("V"));
				len = _stprintf_s(OutString1, OUTSTR_LEN, TEXT("⊕: %s"), OutString2);
				TextOut(hdc, MarkerTxtPos1, TextOutY, OutString1, len);
				EngSprint(OutString2, OUTSTR_LEN, Aten1 * Marker[1].MeasureY, TEXT("V"));
				len = _stprintf_s(OutString1, OUTSTR_LEN, TEXT("⊞: %s"), OutString2);
				TextOut(hdc, MarkerTxtPos2, TextOutY, OutString1, len);
				EngSprint(OutString2, OUTSTR_LEN, Aten1 * (Marker[1].MeasureY - Marker[0].MeasureY), TEXT("V"));
				EngSprint(OutString3, OUTSTR_LEN, (Marker[1].MeasureX - Marker[0].MeasureX) / 48e6, TEXT("S"));
				if (Marker[1].MeasureX != Marker[0].MeasureX) {
					EngSprint(OutString4, OUTSTR_LEN, 48e6 / (Marker[1].MeasureX - Marker[0].MeasureX), TEXT("Hz"));
					len = _stprintf_s(OutString1, OUTSTR_LEN, TEXT("⊕→⊞: %s, %s (%s)"), OutString2, OutString3, OutString4);
				} else {
					len = _stprintf_s(OutString1, OUTSTR_LEN, TEXT("⊕→⊞: %s, %s"), OutString2, OutString3);
				}
				TextOut(hdc, MarkerTxtPos3, TextOutY, OutString1, len);
			}
			TextOutY += LegendLineHeight;  // move to next line
		}
		if (Ena2Checked) {
			// Report Channel 2 info in legend area
			// 1. Volts/Div
			// 2. Markers (if enabled)
			SetTextColor(hdc, ch2Color);
			SetTextAlign(hdc, TA_TOP | TA_LEFT | TA_NOUPDATECP);
			EngSprint(OutString2, OUTSTR_LEN, Aten2 * VoltParms[Volt2].VoltsPerDiv, TEXT("V/div"));
			len = _stprintf_s(OutString1, OUTSTR_LEN, TEXT("Ch2: %s"), OutString2);
			if (len>0) TextOut(hdc, 2, TextOutY, OutString1, len);
			if (EnaMarkers) {
				EngSprint(OutString2, OUTSTR_LEN, Aten2 * Marker[2].MeasureY, TEXT("V"));
				len = _stprintf_s(OutString1, OUTSTR_LEN, TEXT("⊞: %s"), OutString2);
				TextOut(hdc, MarkerTxtPos1, TextOutY, OutString1, len);
				EngSprint(OutString2, OUTSTR_LEN, Aten2 * Marker[3].MeasureY, TEXT("V"));
				len = _stprintf_s(OutString1, OUTSTR_LEN, TEXT("⊕: %s"), OutString2);
				TextOut(hdc, MarkerTxtPos2, TextOutY, OutString1, len);
				EngSprint(OutString2, OUTSTR_LEN, Aten2 * (Marker[3].MeasureY - Marker[2].MeasureY), TEXT("V"));
				EngSprint(OutString3, OUTSTR_LEN, (Marker[3].MeasureX - Marker[2].MeasureX) / 48e6, TEXT("S"));
				if (Marker[3].MeasureX != Marker[2].MeasureX) {
					EngSprint(OutString4, OUTSTR_LEN, 48e6 / (Marker[3].MeasureX - Marker[2].MeasureX), TEXT("Hz"));
					len = _stprintf_s(OutString1, OUTSTR_LEN, TEXT("⊕→⊞: %s, %s (%s)"), OutString2, OutString3, OutString4);
				} else {
					len = _stprintf_s(OutString1, OUTSTR_LEN, TEXT("⊕→⊞: %s, %s"), OutString2, OutString3);
				}
				TextOut(hdc, MarkerTxtPos3, TextOutY, OutString1, len);
			}
			TextOutY += LegendLineHeight;  // move to next line
		}
	}
	if (EnaExtraInfo) {
		// Additional Info Line
		// 1. Version
		// 2a. Sample buffer size and sample rate of captured trace if any
		// 2b. Otherwise, show buffer size and sample rate for present TimeDiv
		SetTextColor(hdc, TimeColor);
		SetTextAlign(hdc, TA_TOP | TA_RIGHT | TA_NOUPDATECP);
		len = _stprintf_s(OutString1, OUTSTR_LEN, TEXT("BasicScope %d.%d http://pididu.com"), (int)BS_MAJORVERSION, (int)BS_MINORVERSION);
		TextOut(hdc, MessageRect.right-2, TextOutY, OutString1, len);
		SetTextAlign(hdc, TA_TOP | TA_LEFT | TA_NOUPDATECP);
		if (buffer[BufToDisplay].valid) {
			len = _stprintf_s(OutString1, OUTSTR_LEN, TEXT("%ld samples @ %s"), TimeParms[buffer[BufToDisplay].timediv].ReadLen, TimeParms[buffer[BufToDisplay].timediv].slabel);
		} else {
			len = _stprintf_s(OutString1, OUTSTR_LEN, TEXT("%ld samples @ %s"), TimeParms[TimeDiv].ReadLen, TimeParms[TimeDiv].slabel);
		}
		if (len>0) TextOut(hdc, 2, TextOutY, OutString1, len);
	}

	if (HorizDragLineAt >= 0) {
		SetDCPenColor(hdc, RGB(100,100,100));
		SelectObject(hdc,GetStockObject(DC_PEN));
		MoveToEx(hdc, 0, HorizDragLineAt, NULL);
		LineTo(hdc, Rect.right, HorizDragLineAt);
	}
	if (VertDragLineAt >= 0) {
		SetDCPenColor(hdc, RGB(100,100,100));
		SelectObject(hdc,GetStockObject(DC_PEN));
		MoveToEx(hdc, VertDragLineAt, 0, NULL);
		LineTo(hdc, VertDragLineAt, Rect.bottom);
	}
	EndPaint(hWnd, &ps);
}

// Thread that acquires data from scope
// Passed parameter is ignored; all control is accomplished through global flags
// See description of DisplayPaint() for comments on double-buffer control
DWORD WINAPI AcquisitionThread( LPVOID lpParam )
{
	short status;  // result of dsoReadHardData call

	while (ContinueAcquisitionThread) {
		if (!scope_stopped && !(buffer[BufToFill].valid)) {
			buffer[BufToFill].volt1 = Volt1;  // save parameters of trace along with buffer
			buffer[BufToFill].volt2 = Volt2;
			buffer[BufToFill].aten1 = Aten1;
			buffer[BufToFill].aten2 = Aten2;
			buffer[BufToFill].timediv = TimeDiv;
			// Don't do dsoSetVoltDIV() here.  Tradeoff:
			// This does open up the possibility that the voltage setting on
			// the captured buffer will be wrong if the slider was moved at just
			// the wrong time before capture, but the error will be for one
			// capture only.  Better to save execution time in this section.
			// debugInt = dsoSetVoltDIV(DeviceIndex, CH1, VoltParms[buffer[BufToFill].volt1].Volt);
#ifdef PerformanceMonitor
LARGE_INTEGER QpcStart, QpcEnd, QpcElapsed;
QueryPerformanceCounter(&QpcStart);
#endif PerformanceMonitor
			status = dsoReadHardData(
				DeviceIndex,
				buffer[BufToFill].data[CH1],
				buffer[BufToFill].data[CH2],
				TimeParms[buffer[BufToFill].timediv].ReadLen, // unsigned long nReadLen
				CalData, // short* pCalLevel,
				VoltParms[buffer[BufToFill].volt1].Volt, // int nCH1VoltDIV - actual voltage set by dsoSetVoltDIV()
				VoltParms[buffer[BufToFill].volt2].Volt, // int nCH2VoltDIV,
				0, // short nTrigSweep: SWPMODE-0: AUTO; 1: Normal; 2: Single
				TrigSrc, // short nTrigSrc
				TrigLevel, // short nTrigLevel
				TrigSlope, // short nSlope: Trigger Slope - 0: Rise; 1: Fall
				TimeParms[buffer[BufToFill].timediv].TimeDiv, //int nTimeDIV,
				50, // short nHTrigPos: Horizontal trigger position 0 ~ 100 *** IGNORED
				TimeParms[buffer[BufToFill].timediv].DisLen, // unsigned long nDisLen, RY - maybe processed into display buffer w/ interpolation
				&TrigPoint, // unsigned long * nTrigPoint, loc of trigger in buffer
				0 // short nInsertMode RY - interpolation method?
				);
#ifdef PerformanceMonitor
QueryPerformanceCounter(&QpcEnd);
QpcElapsed.QuadPart = QpcEnd.QuadPart - QpcStart.QuadPart;
//QueryPerformanceFrequency(&i3);
_stprintf_s(OutString1, OUTSTR_LEN, TEXT("\r\ntrig mode %d, retval %d, elapsed %lld"), debugInt14, debugInt2, QpcElapsed.QuadPart);
AppendToStatus(OutString1);
#endif PerformanceMonitor
			if (status < 0) {
				StopScope();
				AppendToStatus(TEXT("\r\nRead from scope failed. Please make sure scope is connected."));
				if (MessageBox(hWndMain, TEXT("Read from scope failed. Please make sure scope is connected, then click Retry."), TEXT("Hardware read fail"), MB_RETRYCANCEL) == IDRETRY) {
					ConnectScope();
				}
			} else if (!scope_stopped) {
				// fix up status in case of no trigger desired
				if (!TrigEna1Checked && !TrigEna2Checked) status = 2;
				// Got a trace - if software trigger enabled, do additional processing
				if (EnaSwTrig) {
					// The original intent of these next couple lines was
					// to save time, disqualifying a trace because the hardware
					// did not find any trigger.  But the Hantek driver has a problem
					// triggering at a level over 135 when in AUTO mode, so must
					// check software trigger every time
					//if (((TrigEna1Checked && (Slope1==PosEdg || Slope1==NegEdg)) ||
					//	(TrigEna2Checked && (Slope2==PosEdg || Slope2==NegEdg))) &&
					//	status == 1) {
					//	// do nothing, status==1 will cause trace to be rejected
					//} else if (TrigEna1Checked || TrigEna2Checked) {
					if (TrigEna1Checked || TrigEna2Checked) {
						// search for the trigger by software
						status = FindTrig(buffer[BufToFill].data[TrigSrc], TrigScanStart, TrigScanEnd, TrigLevel, TrigEna1Checked ? Slope1 : Slope2, (long *) &TrigPoint);
					}
				}
				if (status == 2) { // status 2 means trig found
					buffer[BufToFill].trigpoint = TrigPoint;
					// If in Data Acquisition Mode, write the trace to the designated file,
					// but ONLY if the file does not already exist.
					if (EnaDaMode) {
						FileHandle = CreateFile(DataAcqfilename,
							GENERIC_WRITE,  // access GENERIC_READ or GENERIC_WRITE
							0,				// 0 = no share (exclusive)
							NULL,			// security descriptor
							CREATE_NEW,		// only create and open the file if it does not already exist
							FILE_ATTRIBUTE_NORMAL,	// not hidden, system, temporary, etc.
							NULL);			// no template
						if (FileHandle != INVALID_HANDLE_VALUE) {
							// write the newly-captured buffer out
							WriteCsv(FileHandle, BufToFill);
							CloseHandle(FileHandle);
						}
					}

					// prepare for display
					buffer[BufToFill].valid = true;
					InvalidateRect(hWndDisplay, NULL, false);  // DisplayWnd paint proc will process
					// Briefly flash trigger text to indicate trigger received
					RecentTrigger = true;
					if (TrigEna1Checked) InvalidateRect(hWndTrigEna1, NULL, false);
					if (TrigEna2Checked) InvalidateRect(hWndTrigEna2, NULL, false);
					SetTimer(hWndMain, IDT_TIMER, 200, NULL);  // this is duration of trigger indicator
				}
			}
		} else {
			Sleep(1);
		}
	}
	return 0;
}

// Message handler for about box.
INT_PTR CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(lParam);
	switch (message)
	{
	case WM_INITDIALOG:
		// set version and build date string
		_stprintf_s(OutString1, OUTSTR_LEN, TEXT("Version %d.%d build: ")TEXT(__DATE__)TEXT(" ")TEXT(__TIME__), (int)BS_MAJORVERSION, (int)BS_MINORVERSION);
		SendMessage(GetDlgItem(hDlg, ID_DLGVERSION), WM_SETTEXT, 0, (LPARAM) OutString1);
		return (INT_PTR)true;

	case WM_COMMAND:
		if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL)
		{
			EndDialog(hDlg, LOWORD(wParam));
			return (INT_PTR)true;
		}
		break;
	}
	return (INT_PTR)false;
}
