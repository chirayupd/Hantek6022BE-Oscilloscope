#pragma once

// Including SDKDDKVer.h defines the highest available Windows platform.

// If you wish to build your application for a previous Windows platform, include WinSDKVer.h and
// set the _WIN32_WINNT macro to the platform you wish to support before including SDKDDKVer.h.

// Roderick: This is so that if someone has IE8 installed on WinXP, program will still display tooltips right
//#define _WIN32_WINNT	0x0500
#define _WIN32_WINNT	_WIN32_WINNT_WIN2K
#include <SDKDDKVer.h>
