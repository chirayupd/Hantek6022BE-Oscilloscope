// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#pragma once

#include "targetver.h"

#define WIN32_LEAN_AND_MEAN             // Exclude rarely-used stuff from Windows headers
// Windows Header Files:
#include <windows.h>
#include <windowsx.h>
#include <CommCtrl.h>  // for common controls like trackbars
#include <CommDlg.h>   // for file open dialog box, this is excluded by WIN32_LEAN_AND_MEAN
// C RunTime Header Files
#include <stdlib.h>

// TODO: reference additional headers your program requires here
#include <stdio.h>
#include <malloc.h>
#include <memory.h>
#include <tchar.h>
#include <time.h>