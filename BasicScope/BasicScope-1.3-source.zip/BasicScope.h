﻿#pragma once

#include "resource.h"

//#define BUILD_DATE_STRING	TEXT("build: ")TEXT(__DATE__)TEXT(" ")TEXT(__TIME__)

// For my convenience
#define SUCCESS ERROR_SUCCESS
#define FAIL	ERROR_SUCCESS+1

#define CALDATA_LEN 32

#define OUTSTR_LEN	254	// do not make this 255, will be problem for FormatMessage()
#define FILENAME_LEN	256

// Registry keys
#define BASICSCOPE_ROOT_KEY		TEXT("Software\\BasicScope")
#define BASICSCOPE_VERSION		TEXT("Version")
#define BASICSCOPE_WINDOWLEFT	TEXT("WindowLeft")
#define BASICSCOPE_WINDOWTOP	TEXT("WindowTop")
#define BASICSCOPE_WINDOWRIGHT	TEXT("WindowRight")
#define BASICSCOPE_WINDOWBOTTOM	TEXT("WindowBottom")
#define BASICSCOPE_ENA1			TEXT("Ena1")
#define BASICSCOPE_TRIGENA1		TEXT("TrigEna1")
#define BASICSCOPE_VOLT1		TEXT("Volt1")
#define BASICSCOPE_ZERO1		TEXT("Zero1")
#define BASICSCOPE_TRIG1		TEXT("Trig1")
#define BASICSCOPE_SLOPE1		TEXT("Slope1")
#define BASICSCOPE_ATEN1		TEXT("Aten1")
#define BASICSCOPE_ENA2			TEXT("Ena2")
#define BASICSCOPE_TRIGENA2		TEXT("TrigEna2")
#define BASICSCOPE_VOLT2		TEXT("Volt2")
#define BASICSCOPE_ZERO2		TEXT("Zero2")
#define BASICSCOPE_TRIG2		TEXT("Trig2")
#define BASICSCOPE_SLOPE2		TEXT("Slope2")
#define BASICSCOPE_ATEN2		TEXT("Aten2")
#define BASICSCOPE_TIMEDIV		TEXT("TimeDiv")
#define BASICSCOPE_ENAEXTRAINFO	TEXT("EnaExtraInfo")
#define BASICSCOPE_ENAMARKERS	TEXT("EnaMarkers")
#define BASICSCOPE_ENASWTRIG	TEXT("EnaSwTrig")
#define BASICSCOPE_TOOLBARBUTTONS TEXT("ToolbarButtons")
#define BASICSCOPE_WINDOWSTATE	TEXT("WindowState")
#define BASICSCOPE_ENADAMODE	TEXT("EnaDataAcquisitionMode")
#define BASICSCOPE_DACQFILENAME	TEXT("DataAcqFilename")

// for dsoSetVoltDIV(unsigned short DeviceIndex,int nCH,int nVoltDIV);
// nCH values
enum CHANNEL {
	CH1 = 0,
	CH2 = 1
};
#define ch1Color	RGB(255,255,0)
#define ch2Color	RGB(0,255,255)
#define TimeColor	RGB(255,0,200)

// Globals
HANDLE hMutexRunning;		// prevent more than 1 copy of program from running
//DWORD Version = MAKELONG(13,0);  // Minor version, Major version

// These relate to Hantek calls: dsoReadHardData(), dsoSetVoltDIV, etc.
short DeviceType = -1;	// 1 == 6022BE, 0 = 6022BL, -1 = unknown
WORD DeviceIndex;		   //USB Device Index for scope, usually 0
short CalData[CALDATA_LEN];	//Proofreading level (reference function dsoGetCalLevel)
ULONG TrigPoint = 0;  // index in buffer where trigger event is.  Must be unsigned for Hantek.
CHANNEL TrigSrc = CH1;
short TrigLevel, TrigSlope;

// These relate to scrolling and panning the display
// SIGNED offset of center of display from trigger point
// in units of 1/(48 MHz).  For example, a value of -48 denotes -1 uS.
long DelayTicks = 0;
// Same as above, but in samples.
long DelaySamples = 0;
long PanStartSamples;  // value when drag-panning first starts
short PanStartX;  // x-coord of mouse when drag-panning first starts
// region in which to look for software trigger
// units are in samples
long TrigScanStart, TrigScanEnd;

// Saved handles for main window, and all its child windows and controls
HWND hWndMain, hWndDisplay,
	hWndEna1, hWndEna2,
	hWndVlabel1, hWndVlabel2,
	hWndZlabel1, hWndZlabel2,
	hWndTrigEna1, hWndTrigEna2,
	hWndSlope1, hWndSlope2,
	hWndZero1, hWndZero2,
	hWndVolt1, hWndVolt2,
	hWndTrig1, hWndTrig2,
	hWndX1Aten1, hWndX1Aten2,
	hWndX10Aten1, hWndX10Aten2,
	hWndTimeDiv, hWndStatus, hWndToolbar, hWndPager,
	hWndIdToolTip;

// For combo boxes with trigger slope type
enum SLOPETYPE {
	PosEdg,
	NegEdg,
	BothEdg
};
#define NUM_SLOPES 3
// Note: the following must line up with the enum above
TCHAR * SlopeName[] = {
	TEXT("↑ edge"),
	TEXT("↓ edge"),
	TEXT("↕ edge")
};

// States of conrols, and default values after fresh install
// default values are set to give a good chance of capturing
// a trace when hooked up to the internal squarewave generator
// of 0 - 2 volts @ 1 kHz, whether the probes are x10 or x1.
bool
	Ena1Checked = true,
	Ena2Checked = false,
	TrigEna1Checked = true,
	TrigEna2Checked = false;
SLOPETYPE
	Slope1 = PosEdg,
	Slope2 = PosEdg;
short
	Volt1 = 2,
	Zero1 = 96,
	Trig1 = 2,
	Aten1 = 1,
	Volt2 = 2,
	Zero2 = 224,
	Trig2 = 2,
	Aten2 = 1;
double TrigVolt1, TrigVolt2;  // trigger level in absolute volts, translated from Trig1 and Trig2
// State of main window - maximized, minimized, normal, etc.
// Only valid at program start and end
int WindowState = SW_NORMAL;

// The TimeDiv for acquisition and zoomed viewing
short TimeDiv = 13;
// The TimeDiv of the trace being displayed, not necessarily same as above.
// This is used to determine whether scroll bar needs to be recalculated, among other things
short DisplayTimeDiv = -1;

// Screen metrics - retrieved/calculated during init for later use
int MainClientWidth, MainClientHeight;  // dimensions of client rect of main window
int CaptionHeight, MenuHeight, FrameHeight, ScrollHeight;
int AveCharWidth, ButtonWidth1, ButtonWidth2, SliderWidth1, SliderWidth2, DisplayMargin;
int TrackbarLeadin, SliderHeight, StatusHeight, ToolbarHeight;
// Calculated upon every resize
int DisplayWidth, DisplayHeight, WaveformHeight;
short HorizDragLineAt = -1;  // location of horizontal line while dragging control or marker
short VertDragLineAt = -1;  // location of vertical line while dragging marker
double HZoomFactor = 1.0L;  // horiz zoom factor for drawing waveform
double VZoomFactor1 = 1.0L;  // vert zoom factor, channel 1
double VZoomFactor2 = 1.0L;  // channel 2
// Color-related
HBRUSH Ch1Brush, Ch2Brush, TimeBrush;
HFONT Font1;  // for Toolbar buttons
HFONT Font2;  // for most other controls
HFONT Font3;  // for drawing the markers (same as Font2, but larger)
// Software Trigger Enable
bool EnaSwTrig = true;
// Related to Legend area at bottom of display Window
int LegendHeight;  // height of legend area in pixels
int LegendLineHeight;    // height of one line in legend area, in pixels
int MarkerTxtPos1, // x-position of ⊕170mV
	MarkerTxtPos2, // x-position of ⊞400mV
	MarkerTxtPos3; // x-position of ⊕→⊞ 230 mV, 347 μS (2.88 kHz)
bool EnaExtraInfo = false;  // if true, add an extra line of information to the legend

// Related to Markers
bool EnaMarkers = false;
// TextOut() is used to draw the markers, but there is no TA_VCENTER alignment available
// Will fake it by drawing text half a character height higher on the screen, to center it
int SpriteOffset;  // half of the height value for the marker characters
// This is the Marker structure.  The Display Paint procedure only looks at the Screen
// coordinates to draw the marker.
// When the marker is dragged Screen coordinates are updated, and the Measure coordinates
// recalculated from that.
// When the time or voltage scale is changed, or the display panned or scrolled, Measure
// coordinates drive recalculation of Screen coordinates.  If the marker would be off screen,
// it is drawn on-screen at the nearest displayable point.
typedef struct {
	int ScreenX, ScreenY;  // screen coordinates of the marker
	long MeasureX;  // units = ticks from trigger
	double MeasureY;  // units = volts above zero point
	short *Zslider;  // zero slider position to use for calculations (&Zero1 or &Zero2)
	short *Vslider;  // volt slider position to use for calculations
	TCHAR sprite;  // char used to draw the marker
//	COLORREF color;  // color of the marker
} MARKERPOINT;
MARKERPOINT Marker[4] = {
	{50, 50, 0, 0, &Zero1, &Volt1, TEXT('⊕')},  // first two markers are channel 1
	{100, 50, 0, 0, &Zero1, &Volt1, TEXT('⊞')},
	{50, 100, 0, 0, &Zero2, &Volt2, TEXT('⊕')}, // next two markers are channel 2
	{100, 100, 0, 0, &Zero2, &Volt2, TEXT('⊞')}
};
int MarkerBeingDragged = -1;  // Index of marker being dragged by user (-1 = none)

// This is the information for each setting of voltage (vertical) or time (horizontal)
// Element 0 corresponds to the top setting on the slider, and it goes down
// from there
typedef struct {
	int   Volt;  // what to send to Hantek API
	double VoltsPerDiv;  // volts per div with 1x probe
	double ScaleOut;    // factor to multiply by to get to next less sensitive range, should be > 1
} VOLTPARM;

const VOLTPARM VoltParms[] = {
	{7, 5.0,  2.0L},
	{6, 2.0,  2.5L},
	{5, 1.0,  2.0L},
	{4, 0.5,  2.0L},
	{3, 0.2,  2.5L},
	{2, 0.1,  2.0L},
	{1, 0.05, 2.0L},
	{0, 0.02, 2.5L}
};
const int nVoltParms = sizeof(VoltParms)/sizeof(VOLTPARM);

typedef struct {
	TCHAR *label;   // human-readable string, convenient to print
	int   TimeDiv;  // what to send to Hantek API
	int   TicksPerSample;  // number of 48 MHz ticks in one sample
	TCHAR *slabel;  // human readable sample rate
	long ReadLen;  // data buffer size for capture
	long DisLen;   // display size for that sample rate
	double ScaleOut; // freq factor to multiply by to get to next lower index range, should be > 1
} TIMEPARM;

const TIMEPARM TimeParms[] = {
	{TEXT("25 nS/Div"),  10,   1, TEXT("48 Msps"),     1016,      12, 2.0L}, /* can't be 20 nS, that would be 9.6 samples */
	{TEXT("50 nS/Div"),  10,   1, TEXT("48 Msps"),     1016,      24, 2.0L},
	{TEXT("100 nS/Div"), 10,   1, TEXT("48 Msps"),     1016,      48, 2.0L},
	{TEXT("200 nS/Div"), 10,   1, TEXT("48 Msps"),     1016,      96, 2.0L},
	{TEXT("500 nS/Div"), 10,   1, TEXT("48 Msps"),     1016,     240, 2.5L},
	{TEXT("1 μS/Div"),   10,   1, TEXT("48 Msps"),     1016,     480, 2.0L},
	{TEXT("2 μS/Div"),   10,   1, TEXT("48 Msps"),     1016,     960, 2.0L},

	{TEXT("5 μS/Div"),   11,   3, TEXT("16 Msps"),   130048,     800, 2.5L},
	{TEXT("10 μS/Div"),  12,   6, TEXT("8 Msps"),    130048,     800, 2.0L},
	{TEXT("20 μS/Div"),  13,  12, TEXT("4 Msps"),    130048,     800, 2.0L},
	{TEXT("50 μS/Div"),  14,  48, TEXT("1 Msps"),    130048,     500, 2.5L},
	{TEXT("100 μS/Div"), 15,  48, TEXT("1 Msps"),    130048,    1000, 2.0L},
	{TEXT("200 μS/Div"), 16,  48, TEXT("1 Msps"),    130048,    2000, 2.0L},
	{TEXT("500 μS/Div"), 17,  48, TEXT("1 Msps"),    130048,    5000, 2.5L},
	{TEXT("1 mS/Div"),   18,  48, TEXT("1 Msps"),    130048,   10000, 2.0L},
	{TEXT("2 mS/Div"),   19,  48, TEXT("1 Msps"),    130048,   20000, 2.0L},

	{TEXT("5 mS/Div"),   20,  48, TEXT("1 Msps"),    523264,   50000, 2.5L},
	{TEXT("10 mS/Div"),  21,  48, TEXT("1 Msps"),    523264,  100000, 2.0L},
	{TEXT("20 mS/Div"),  22,  48, TEXT("1 Msps"),    523264,  200000, 2.0L},

	{TEXT("50 mS/Div"),  23,  48, TEXT("1 Msps"),   1047552,  500000, 2.5L},
	{TEXT("100 mS/Div"), 24,  48, TEXT("1 Msps"),   1047552, 1000000, 2.0L},
	{TEXT("200 mS/Div"), 25,  96, TEXT("500 ksps"), 1047552, 1000000, 2.0L},
	{TEXT("500 mS/Div"), 26, 240, TEXT("200 ksps"), 1047552, 1000000, 2.5L},
	{TEXT("1 S/Div"),    27, 480, TEXT("100 ksps"), 1047552, 1000000, 2.0L}
};
const int nTimeParms = sizeof(TimeParms)/sizeof(TIMEPARM);

// These are the buffers for the trace
// They are big, to hold the largest possible data capture
typedef struct {
	bool valid;  // true if buffer contains valid data
	short data[2][1048576];  // 2 channels of data
	short volt1, volt2;  // voltage slider settings when trace was taken
	short aten1, aten2;  // attenuator settings (1 or 10) when trace was taken
	short timediv;       // time division slider setting when trace was taken
	long trigpoint;      // trigger point when the trace was taken
} TRACE;
TRACE buffer[2];  // two, because we double-buffer
// This points to the buffer to fill, either 0 or 1.
// If that buffer is not valid, the acquisition thread will generally
// attempt to fill it, and then mark it as valid.
// The buffer that this does NOT point to, if valid, is displayed on
// the screen by the Display Window paint procedure.
short BufToFill = 0;

HANDLE hThreadAcquisition = NULL;

// flags to control acquisition thread
bool scope_stopped = true;  // if true, do not take traces
bool scope_oneshot = false;  // if true, single trace is taken.  if false, repeating trigger
bool ContinueAcquisitionThread = true;  // normally true.  if false, exit acquisition thread as program is ending

bool RecentTrigger = false;  // true for the short period of time after a trigger received
bool MainWindowIsSizing = false;  // true while user is dragging border of main window

// Related to data acquisition mode
TCHAR DataAcqfilename [FILENAME_LEN] = TEXT("data.csv");  // name of output file for automatic data acquisition output
bool EnaDaMode = false;  // if true, program will try to save every trace taken to a file

// Utility variables and structures used at various places in the main program thread
// WARNING: do not use in any other threads without some sort of arbitration (interlock, semaphore, ...)
int i;  // general iteration variable
TEXTMETRIC txm;  // can't name it "tm", that is a time structure
SCROLLINFO si = {sizeof(SCROLLINFO)};
// General output strings to use in printing
TCHAR OutString1[OUTSTR_LEN], OutString2[OUTSTR_LEN], OutString3[OUTSTR_LEN], OutString4[OUTSTR_LEN];
// There will never be more than one file open at a time,
// and generally, code will open the file, do its business,
// then close the file within a few lines.  The following
// are shared for this purpose.
TCHAR filename [FILENAME_LEN];
OPENFILENAME ofn;
HANDLE FileHandle;
WINDOWPLACEMENT wpl = {sizeof(WINDOWPLACEMENT)};  // used only for set/detect window maximized
TCHAR debugString[255];  // junk string for utility debug use
int debugInt, debugInt1, debugInt2;  // utility variables for debugging
//int debugInt3, debugInt4, debugInt5, debugInt6;
//int debugInt7, debugInt8, debugInt9, debugInt10;
//int debugInt11, debugInt12, debugInt13, debugInt14;
double debugDouble;

// Toolbar buttons
// The first field is the index of the bitmap for the button, as loaded by LoadToolbarButtons()
// Note that the dwData field is set equal to the index of the element in tbButtonList[]
TBBUTTON tbButtonList[] = {
	{MAKELONG(0,0), IDM_ABOUT, TBSTATE_ENABLED, BTNS_AUTOSIZE, {0}, 0, (INT_PTR) TEXT("About")},
	{MAKELONG(5,0), IDM_RUNNORM, TBSTATE_ENABLED, BTNS_AUTOSIZE | BTNS_CHECK, {0}, 1, (INT_PTR) TEXT("Run Norm")},
	{MAKELONG(2,0), IDM_RUNONCE, TBSTATE_ENABLED, BTNS_AUTOSIZE | BTNS_CHECK, {0}, 2, (INT_PTR) TEXT("Run Oneshot")},
	{MAKELONG(11,0), IDM_MARKERS, TBSTATE_ENABLED, BTNS_AUTOSIZE | BTNS_CHECK, {0}, 3, (INT_PTR) TEXT("Markers")},
	{MAKELONG(12,0), IDM_PARKMARKERS, TBSTATE_ENABLED, BTNS_AUTOSIZE, {0}, 4, (INT_PTR) TEXT("Park Markers")},
	{MAKELONG(14,0), IDM_UNZOOM, TBSTATE_ENABLED, BTNS_AUTOSIZE, {0}, 5, (INT_PTR) TEXT("Unzoom")},
	{MAKELONG(8,0), IDM_LOADBIN, TBSTATE_ENABLED, BTNS_AUTOSIZE, {0}, 6, (INT_PTR) TEXT("Load Trace")},
	{MAKELONG(7,0), IDM_SAVEBIN, TBSTATE_ENABLED, BTNS_AUTOSIZE, {0}, 7, (INT_PTR) TEXT("Save Trace")},
	{MAKELONG(6,0), IDM_SAVEDISPLAY, TBSTATE_ENABLED, BTNS_AUTOSIZE, {0}, 8, (INT_PTR) TEXT("Screen Shot")},
	{MAKELONG(13,0), IDM_EXTRAINFO, TBSTATE_ENABLED, BTNS_AUTOSIZE | BTNS_CHECK, {0}, 9, (INT_PTR) TEXT("Extra Info")},
	{MAKELONG(15,0), IDM_SWTRIG, TBSTATE_ENABLED, BTNS_AUTOSIZE | BTNS_CHECK, {0}, 10, (INT_PTR) TEXT("Software Trig")},
	{MAKELONG(1,0), IDM_EDITBUTTONS, TBSTATE_ENABLED, BTNS_AUTOSIZE, {0}, 11, (INT_PTR) TEXT("Change buttons")},
	{MAKELONG(3,0), IDM_FIRSTTRIG, TBSTATE_ENABLED, BTNS_AUTOSIZE, {0}, 12, (INT_PTR) TEXT("First Trig")},
	{MAKELONG(4,0), IDM_NEXTTRIG, TBSTATE_ENABLED, BTNS_AUTOSIZE, {0}, 13, (INT_PTR) TEXT("Next Trig")},
	{MAKELONG(7,0), IDM_SAVECSV, TBSTATE_ENABLED, BTNS_AUTOSIZE, {0}, 14, (INT_PTR) TEXT("Save CSV")},
	{MAKELONG(16,0), IDM_DAMODE, TBSTATE_ENABLED, BTNS_AUTOSIZE | BTNS_CHECK, {0}, 15, (INT_PTR) TEXT("Data Acq Mode")},
	{MAKELONG(9,0), IDM_DBGBREAK, TBSTATE_ENABLED, BTNS_AUTOSIZE, {0}, 16, (INT_PTR) TEXT("Dbg break")},
	{MAKELONG(10,0), IDM_TEST1, TBSTATE_ENABLED, BTNS_AUTOSIZE, {0}, 17, (INT_PTR) TEXT("Test1")},
	{MAKELONG(10,0), IDM_TEST2, TBSTATE_ENABLED, BTNS_AUTOSIZE, {0}, 18, (INT_PTR) TEXT("Test2")}
}; 
int nButtons = sizeof(tbButtonList)/sizeof(TBBUTTON);
// This is a record of which buttons are actually in the Toolbar.
// nToolbarButtons is the count of those buttons.
// Each element of ToolbarButtons is the index into tbButtonList[] of
// the button in the toolbar.
// Only valid when settings are being loaded or saved - that is,
// program init and close.
#define MAX_TOOLBAR_BUTTONS 256
BYTE ToolbarButtons[MAX_TOOLBAR_BUTTONS];
int nToolbarButtons; // number of populated elements in ToolbarButtons

// Related to loading Hantek DLL
// Handle to the HTMarch.dll that is loaded
HMODULE hLibMarch = 0;
//typedef int (WINAPI * HTDrawGrid_t)(HDC, int, int, int, int, int, int, int, __int16);
//HTDrawGrid_t myDrawGrid;
typedef short (WINAPI * dsoOpenDevice_t)(WORD DeviceIndex);  // not used in BasicScope
dsoOpenDevice_t dsoOpenDevice;
typedef short (WINAPI * dsoSetVoltDIV_t)(WORD DeviceIndex,int nCH,int nVoltDIV);
dsoSetVoltDIV_t dsoSetVoltDIV;
typedef short (WINAPI * dsoSetTimeDIV_t)(WORD DeviceIndex,int nTimeDIV);
dsoSetTimeDIV_t dsoSetTimeDIV;
typedef short (WINAPI * dsoReadHardData_t)(WORD DeviceIndex,short* pCH1Data, short* pCH2Data,ULONG nReadLen,short* pCalLevel,int nCH1VoltDIV,int nCH2VoltDIV,short nTrigSweep,short nTrigSrc,short nTrigLevel,short nSlope,int nTimeDIV,short nHTrigPos,ULONG nDisLen,ULONG* nTrigPoint,short nInsertMode);
dsoReadHardData_t dsoReadHardData;
typedef WORD (WINAPI * dsoGetCalLevel_t)(WORD DeviceIndex,short* level,short nLen);
dsoGetCalLevel_t dsoGetCalLevel;
typedef short (WINAPI * dsoCalibrate_t)(WORD nDeviceIndex,int nTimeDIV,int nCH1VoltDIV,int nCH2VoltDIV,short* pCalLevel);
dsoCalibrate_t dsoCalibrate;
typedef WORD (WINAPI * dsoSetCalLevel_t)(WORD DeviceIndex,short* level,short nLen);
dsoSetCalLevel_t dsoSetCalLevel;
// This one is only in HTMarchBL.dll
typedef short (WINAPI * dsoChooseDevice_t)(WORD DeviceIndex,USHORT deviceType);//0:LA  1:6022D
dsoChooseDevice_t dsoChooseDevice;