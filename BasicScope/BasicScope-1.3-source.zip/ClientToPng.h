// Save client area of supplied hWnd to filename.png
// Warning!  filename is probably a WCHAR string, depending on compiler settings
// when the library was compiled
// Assumptions:
// 1) Compatible bitmap has bottom-up orientation
// 2) Compatible bitmap will return colors in BGR instead of RGB format
// 3) Client Rect has lower bound of 0 in both x and y dimension
// 4) Bitmap it not palletized
// Return value: 0 = success, otherwise return standard WinError number
// writing PNG leverged from http://www.labbookpages.co.uk/software/imgProc/files/libPNG/makePNG.c
long SaveClientAreaToPng(HWND, TCHAR *);