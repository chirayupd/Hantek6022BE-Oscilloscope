//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by BasicScope.rc
//

// For a new version, change these three
#define BS_MAJORVERSION	1
#define BS_MINORVERSION 3
#define BS_VERSION_STR	"1.3"

#define BS_VERSION	BS_MAJORVERSION,BS_MINORVERSION,0,0

// Version info ID must be 1
#define IDV_BASICSCOPE		1

#define IDS_APP_TITLE			103

#define IDD_ABOUTBOX			103

#define IDM_ABOUT				150
#define IDM_RUNNORM				151
#define IDM_RUNONCE				152
#define IDM_PARKMARKERS			153
#define IDM_MARKERS				154
#define IDM_FIRSTTRIG			155
#define IDM_NEXTTRIG			156
#define IDM_SWTRIG				157
#define IDM_LOADBIN				158
#define IDM_SAVEBIN				159
#define IDM_SAVEDISPLAY			160
#define IDM_EXTRAINFO			161
#define IDM_EDITBUTTONS			162
#define IDM_SAVECSV				163
#define IDM_UNZOOM				164
#define IDM_DAMODE				165

#define IDM_DBGBREAK			180
#define IDM_TEST1				181
#define IDM_TEST2				182
#define IDM_TEST3				183
#define IDM_TEST4				184
#define IDM_TEST5				185
#define IDM_TEST6				186
#define IDM_TEST7				187
#define IDM_TEST9				189

#define IDM_CALIBRATE			197
#define IDM_DAFILENAME			198
#define IDM_EXIT				199

// Icon
#define IDI_BASICSCOPE			200

// Window classes
#define IDC_MAINWINDOW			300

// Control IDs
#define ID_TIMEDIV				400
#define ID_ENA1					401
#define ID_ENA2					402
#define ID_TRIGENA1				403
#define ID_TRIGENA2				404
#define ID_VLABEL1				405
#define ID_VLABEL2				406
#define ID_ZLABEL1				407
#define ID_ZLABEL2				408
#define ID_SLOPE1				409
#define ID_SLOPE2				410
#define ID_VOLT1				411
#define ID_VOLT2				412
#define ID_ZERO1				413
#define ID_ZERO2				414
#define ID_TRIG1				415
#define ID_TRIG2				416
#define ID_BUTTONX1ATEN1		417
#define ID_BUTTONX10ATEN1		418
#define ID_BUTTONX1ATEN2		419
#define ID_BUTTONX10ATEN2		420
#define ID_STATUS				421
#define ID_TOOLBAR				422
#define ID_PAGER				423

#define ID_DLGVERSION			450  // in About dialog

// Be sure to put these in sequence with no skips
#define IDB_FIRSTBITMAP			500
#define IDB_DUCK				500
#define IDB_EDITBUTTONS			501
#define IDB_ONCE				502
#define IDB_PREV				503
#define IDB_NEXT				504
#define IDB_RUN					505
#define IDB_SCREENSHOT			506
#define IDB_SAVEBIN				507
#define IDB_LOADBIN				508
#define IDB_BREAK				509
#define IDB_BUG					510
#define IDB_MARKERS				511
#define IDB_PARKMARKERS			512
#define IDB_EXTRAINFO			513
#define IDB_UNZOOM				514
#define IDB_SWTRIG				515
#define IDB_DAMODE				516
#define IDB_LASTBITMAP			516

// For SetTimer()
#define IDT_TIMER				600

//#define IDC_MYICON				2
#ifndef IDC_STATIC
#define IDC_STATIC				-1
#endif
// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS

#define _APS_NO_MFC					130
#define _APS_NEXT_RESOURCE_VALUE	129
#define _APS_NEXT_COMMAND_VALUE		32771
#define _APS_NEXT_CONTROL_VALUE		1000
#define _APS_NEXT_SYMED_VALUE		110
#endif
#endif
