#include "StdAfx.h"
#include "png.h"
#include "ClientToPng.h"

// Save client area of supplied hWnd to filename.png
// Warning!  filename is probably a WCHAR string, depending on compiler settings
// Assumptions:
// 1) Compatible bitmap has bottom-up orientation
// 2) Compatible bitmap will return colors in BGR instead of RGB format
// 3) Client Rect has lower bound of 0 in both x and y dimension
// 4) Bitmap it not palletized
// Return value: 0 = success, others return standard WinError number
// writing PNG leverged from http://www.labbookpages.co.uk/software/imgProc/files/libPNG/makePNG.c
long SaveClientAreaToPng(HWND hWnd, TCHAR *filename) {
	long code;  // return code
	FILE *fp = NULL;
	png_structp png_ptr = NULL;
	png_infop info_ptr = NULL;
	png_bytep row = NULL;
	RECT Rect;
	HDC hdc = NULL;
	HDC hDest = NULL;
	HBITMAP hBitmap = NULL;
	HBITMAP hPrevBitmap = NULL;
	BITMAPINFO bi = {sizeof(BITMAPINFOHEADER)};

	// get dimensions of client area to save
	// note that this is generally smaller than the whole window
	GetClientRect(hWnd, &Rect);

	// Open file for writing (binary mode)
	code = _tfopen_s(&fp, filename, TEXT("wb"));
	if (code != NO_ERROR) {
		goto finalise;
	}

	// Initialize write structure
	png_ptr = png_create_write_struct(PNG_LIBPNG_VER_STRING, NULL, NULL, NULL);
	if (png_ptr == NULL) {
		code = ERROR_NOT_ENOUGH_MEMORY;
		goto finalise;
	}

	// Initialize info structure
	info_ptr = png_create_info_struct(png_ptr);
	if (info_ptr == NULL) {
		code = ERROR_NOT_ENOUGH_MEMORY;
		goto finalise;
	}

	// Setup Exception handling
	// Any subsequent errors in png_xxxx calls will cause this
	// to execute
	if (setjmp(png_jmpbuf(png_ptr))) {
		code = ERROR_INVALID_DATA;  // best match standard error message
		goto finalise;
	}

	png_init_io(png_ptr, fp);

	// Write header (8 bit colour depth)
	png_set_IHDR(png_ptr, info_ptr, Rect.right, Rect.bottom,
			8, PNG_COLOR_TYPE_RGB, PNG_INTERLACE_NONE,
			PNG_COMPRESSION_TYPE_BASE, PNG_FILTER_TYPE_BASE);

	// Set title
	//if (title != NULL) {
	//	png_text title_text;
	//	title_text.compression = PNG_TEXT_COMPRESSION_NONE;
	//	title_text.key = "Title";
	//	title_text.text = title;
	//	png_set_text(png_ptr, info_ptr, &title_text, 1);
	//}

	png_write_info(png_ptr, info_ptr);

	// Now fetch the actual contents of the Window
	hdc = GetDC(hWnd);
	hDest = CreateCompatibleDC(hdc);

	// create a compatible bitmap to store the pixels
	hBitmap = CreateCompatibleBitmap(hdc, Rect.right, Rect.bottom);

	// bits copied to the context will go to the bitmap
	hPrevBitmap = (HBITMAP) SelectObject(hDest, hBitmap);

	//copy from the window's dc to the dc with the bitmap
	BitBlt(hDest, 0, 0, Rect.right, Rect.bottom, hdc, 0, 0, SRCCOPY);
	// MUST unselect hBitmap in order to use GetDIBits() later
	// bssides, restoring previous object is good practice
	SelectObject(hDest, hPrevBitmap);

	// First call with buffer pointer null just retrieves
	// bitmap information into bi structure
    bi.bmiHeader.biBitCount = 0;  // must set to 0 to retrieve infoheader
	GetDIBits(hDest, hBitmap, 0, 0, NULL, &bi, DIB_RGB_COLORS);
	// Modify to the format we want to retrieve:
	// uncompressed, 3-byte RGB format
    bi.bmiHeader.biBitCount = 24;    
    bi.bmiHeader.biCompression = BI_RGB;    

	// Allocate memory for one row of the picture.
	// Format is 3 bytes (24 bits) per pixel.
	// The buffer is filled by GetDIBits().
	// The buffer is output to a file by libpng calls.
	// For sake of GetDIBits(), must round up to whole number of DWORDs (the "stride")
	row = (png_bytep) malloc((Rect.right * bi.bmiHeader.biBitCount / 8 * sizeof(png_byte) + 3) & ~3);
	if (row == NULL) {
		code = ERROR_NOT_ENOUGH_MEMORY;
		goto finalise;
	}

	// Write image data one row at a time
	// Microsoft image is bottom-up, png is top-down, so must go
	// in reverse order for y.
	// Each Microsoft pixel is BGR, must swap bytes for RGB orderof png
	int x, y;
	UCHAR temp;
	for (y=Rect.bottom-1 ; y>=0; y--) {
		GetDIBits(hDest, hBitmap, y, 1, row, &bi, DIB_RGB_COLORS);
		for (x=0 ; x<Rect.right; x++) {
			temp = row[x*3];
			row[x*3] = row[x*3+2];
			//row[x*3+1] = row[x*3+1];  // middle byte unchanged
			row[x*3+2] = temp;
		}
		png_write_row(png_ptr, row);
	}

	// End write
	png_write_end(png_ptr, NULL);

finalise:
	if (fp != NULL) fclose(fp);
	if (info_ptr != NULL) png_free_data(png_ptr, info_ptr, PNG_FREE_ALL, -1);
	if (png_ptr != NULL) png_destroy_write_struct(&png_ptr, (png_infopp)NULL);
	if (row != NULL) free(row);
	if (hdc != NULL) ReleaseDC(NULL, hdc);
	if (hDest != NULL) DeleteDC(hDest);
	if (hBitmap != NULL) DeleteObject(hBitmap);

	return code;
}
